<?php
    session_start();

    if ($_SESSION['user_login'] === false) {
        setcookie("AuthToken", '', -1, '/', '', false, true);
        setcookie('isValidateUrl', '', -1, '/', '', false, true);

        $tenant_url = $_SESSION['tenant_url'];

        $_SESSION['tenant_logout'] = true;

        unset($_SESSION['tenant_name']);
        // unset($_SESSION['tenant_url']);
        unset($_SESSION['tenant_id']);
        unset($_SESSION['AuthToken']);
        unset($_SESSION['license_id']);
        unset($_SESSION['tenant_user_id']);
        // unset($_SESSION['user_login']);
        // session_destroy();
        
        header("Location: $tenant_url");
        exit();
    }
?>