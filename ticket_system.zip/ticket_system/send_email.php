<?php
$to = "rob@electronicpayments.com";
$from = "rob@electronicpayments.com"; 
$subject = "Product inquiry_mail - LR90cS";

$message = "<html><body>";
$message .= "<p>Thank you for your attention to this matter.</p>";
$message .= "</body></html>";

// Set content-type header for sending HTML email
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers
$headers .= 'From: ' . $from . "\r\n";
$headers .= 'Reply-To: ' . $from . "\r\n";
$headers .= 'X-Mailer: PHP/' . phpversion();

// Send the email
if (mail($to, $subject, $message, $headers)) {
    echo "Email sent successfully.";
} else {
    echo "Failed to send email.";
}
