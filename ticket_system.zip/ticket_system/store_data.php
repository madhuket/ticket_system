<?php
include "config.php";

function validatePhoneNumber($phoneNumber)
{
    // Remove any non-digit characters from the phone number
    $phoneNumber = preg_replace('/[^0-9]/', '', $phoneNumber);

    // Check if the length of the phone number is between 10 and 15
    $phoneNumberLength = strlen($phoneNumber);
    if ($phoneNumberLength >= 10 && $phoneNumberLength <= 15) {
        return true; // Valid phone number
    } else {
        return false; // Invalid phone number
    }
}

function validateEmail($email)
{
    if (empty($email)) {
        echo json_encode(array('success' => false, 'message' => 'Email is required.'));
        exit;
    }

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return $email;
    } else {
        echo json_encode(array('success' => false, 'message' => 'Please enter a valid email address.'));
        exit;
    }
}

function validateUsername($username) {
    // Check if the username is empty
    if (empty($username)) {
        echo json_encode(array('success' => false, 'message' => 'Username is required.'));
        exit;
    }

    // Check the length (minimum 5 and maximum 15 characters)
    if (strlen($username) < 5 || strlen($username) > 15) {
        echo json_encode(array('success' => false, 'message' => 'Username must be between 5 and 15 characters long.'));
        exit;
    }

    // Check if it contains only letters and numbers (alphanumeric)
    if (!preg_match("/^[a-zA-Z0-9]+$/", $username)) {
        echo json_encode(array('success' => false, 'message' => 'Username can only contain letters and numbers.'));
        exit;
    }

    // If all checks pass
    return $username;
}

function validate_perm_tag($permission_tag){
    if (empty($permission_tag)) {
        echo json_encode(array('success' => false, 'message' => 'Permission tag is required.'));
        exit;
    }

    // Check for minimum and maximum length (3-20 characters)
    if (strlen($permission_tag) < 3) {
        echo json_encode(array('success' => false, 'message' => 'Permission tag must be at least 3 characters long.'));
        exit;
    }

    if (strlen($permission_tag) > 20) {
        echo json_encode(array('success' => false, 'message' => 'Permission tag cannot be longer than 20 characters.'));
        exit;
    }

    if (!preg_match('/^[A-Z_]+$/', $permission_tag)) {
        echo json_encode(array('success' => false, 'message' => 'Permission tag can only contain uppercase letters and underscores.'));
        exit;
    }

    // If all checks pass
    return $permission_tag;
}

function validatePassword($password) {
    // Check if the password is empty
    if (empty($password)) {
        echo json_encode(array('success' => false, 'message' => 'Password is required.'));
        exit;
    }

    // Check the length (minimum 8 characters)
    if (strlen($password) < 8) {
        echo json_encode(array('success' => false, 'message' => 'Password must be at least 8 characters long.'));
        exit;
    }

    // Check if it contains at least one uppercase letter
    if (!preg_match("/[A-Z]/", $password)) {
        echo json_encode(array('success' => false, 'message' => 'Password must contain at least one uppercase letter.'));
        exit;
    }

    // Check if it contains at least one lowercase letter
    if (!preg_match("/[a-z]/", $password)) {
        echo json_encode(array('success' => false, 'message' => 'Password must contain at least one lowercase letter.'));
        exit;
    }

    // Check if it contains at least one digit
    if (!preg_match("/[0-9]/", $password)) {
        echo json_encode(array('success' => false, 'message' => 'Password must contain at least one number.'));
        exit;
    }

    // Check if it contains at least one special character
    if (!preg_match("/[\W]/", $password)) {  // \W matches any non-word character
        echo json_encode(array('success' => false, 'message' => 'Password must contain at least one special character.'));
        exit;
    }

    // If all checks pass
    return $password;
}

function validate($value)
{
    if (isset($value) && $value !== "") {
        if (preg_match("/\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|OR)\b/i", $value)) {
            echo json_encode(array('success' => false, 'message' => 'SQL keywords are not allowed!'));
            exit;
        } else if (preg_match("/\b(alert|prompt|confirm|script)\b/i", $value)) {
            echo json_encode(array('success' => false, 'message' => 'JavaScript keywords are not allowed!'));
            exit;
        } else {
            return $value;
        }
    } else {
        echo json_encode(array('success' => false, 'message' => "You didn't fill the required fields!"));
        exit;
    }
}
//check value only contain letters and spaces
function validate_reported_by($value)
{
    if ($value != '') {
        if (!preg_match('/^[a-zA-Z\s]+$/', $value)) {
            echo json_encode(array('success' => false, 'message' => 'Only letters and spaces allowed!'));
            exit;
        } else if (strlen($value) > 100) {
            echo json_encode(array('success' => false, 'message' => 'Please enter no more than 100 characters.'));
            exit;
        } else {
            return $value;
        }
    } else {
        return $value;
    }
}

//validate follow up at field
function validate_follow_up_at($value)
{
    if ($value != '') {
        $is_valid_phone = true;
        // Remove any non-digit characters from the phone number
        $mobile = preg_replace('/[^0-9]/', '', $value);

        // Check if the length of the phone number is between 10 and 15
        $phoneNumberLength = strlen($mobile);
        if ($phoneNumberLength >= 10 && $phoneNumberLength <= 15) {
            $is_valid_phone = true; // Valid phone number
        } else {
            $is_valid_phone = false; // Invalid phone number
        }

        $is_valid_email = true;
        if (filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $is_valid_email = true;
        } else {
            $is_valid_email = false;
        }

        if ($is_valid_email || $is_valid_phone) {
            return $value;
        } else {
            echo json_encode(array('success' => false, 'message' => 'Please enter a valid email address or mobile number.'));
            exit;
        }
    }
}

//validate url field
function validateURL($value) {
    if (filter_var($value, FILTER_VALIDATE_URL)) {
        return $value; // The URL is valid
    } else {
        echo json_encode(array('success' => false, 'message' => 'Please enter a valid url.'));
        exit;
    }
}

function validate_textarea($value) {
    if (strlen($value) > 255) {
        echo json_encode(array('success' => false, 'message' => 'Please enter no more than 255 characters.'));
        exit;
    } else {
        return $value;
    }
}

function validate_special_character($value) {
    if (isset($value) && $value !== "") {
        if (preg_match("/\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE)\b/i", $value)) {
            echo json_encode(array('success' => false, 'message' => 'SQL keywords are not allowed!'));
            exit;
        } else if (preg_match("/\b(alert|prompt|confirm|script)\b/i", $value)) {
            echo json_encode(array('success' => false, 'message' => 'JavaScript keywords are not allowed!'));
            exit;
        } else if (!preg_match('/^[a-zA-Z0-9\s]+$/', $value)) {
            echo json_encode(array('success' => false, 'message' => 'Please enter only letters, numbers, and spaces.'));
            exit;
        } else if (strlen($value) > 100) {
            echo json_encode(array('success' => false, 'message' => 'Please enter no more than 100 characters.'));
            exit;
        } else {
            return $value;
        }
    } else {
        echo json_encode(array('success' => false, 'message' => 'You didn\'t fill the required fields!'));
        exit;
    }
}

//validation for check array is empty of not
function validate_permission($value){
    if (empty($value)) {
        echo json_encode(array('success' => false, 'message' => 'Please select at least one permission.'));
        exit();
    } else {
        return $value;
    }
}

$cur_date = date("Y-m-d H:i A");
$ipaddress = '';
if (getenv('HTTP_CLIENT_IP'))
    $ipaddress = getenv('HTTP_CLIENT_IP');
else if (getenv('HTTP_X_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
else if (getenv('HTTP_X_FORWARDED'))
    $ipaddress = getenv('HTTP_X_FORWARDED');
else if (getenv('HTTP_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_FORWARDED_FOR');
else if (getenv('HTTP_FORWARDED'))
    $ipaddress = getenv('HTTP_FORWARDED');
else if (getenv('REMOTE_ADDR'))
    $ipaddress = getenv('REMOTE_ADDR');
else
    $ipaddress = 'UNKNOWN';

$data[] = $ipaddress;
$data_ip = json_encode($data);

if (!$conn) {
    die("Connection failed: " . print_r(sqlsrv_errors(), true));
} elseif ($_POST['type'] == 'Status_of_Tickets') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(array('success' => false, 'message' => "CSRF token validation failed."));
        exit();
    }

    $id = htmlspecialchars(base64_decode(($_POST['id'])));
    $ticket_status = validate_special_character(htmlspecialchars(trim($_POST['Ticket_status'])));
    $base = validate(htmlspecialchars($_POST['base_status']));

    if ($id == '') {
        //check status is already exists
        $is_exist = "SELECT Id FROM Status WHERE Status = ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";
        // Prepare the statement
        $params = array($ticket_status);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);

        // Execute the statement
        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Status already exists.'));
            exit;
        }

        $sql = "INSERT INTO Status (Status,CreatedBy,BaseStatus) VALUES (?,?,?)";
        $stmt = sqlsrv_prepare($conn, $sql, array(&$ticket_status, $user, $base));
        if (sqlsrv_execute($stmt)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => 'Data inserted successfully', 'csrf_token' => $_SESSION['csrf_token']));
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't insert, Try again"));
        }
    } else {
        //check status is already exists
        $is_exist = "SELECT Id FROM Status WHERE Status = ? AND Id <> ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";
        // Prepare the statement
        $params = array($ticket_status, $id);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);

        // Execute the statement
        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Status already exists.'));
            exit;
        }

        $sql = "UPDATE Status SET Status = ?, ModifiedBy = ?,  ModifiedAt = ?, BaseStatus = ?  WHERE Id = ?";
        $stmt = sqlsrv_prepare($conn, $sql, array(&$ticket_status, $user, $cur_date, $base, $id));

        if (sqlsrv_execute($stmt)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => 'Data updated successfully', 'csrf_token' => $_SESSION['csrf_token']));
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't Update, Try again"));
        }
    }
} elseif ($_POST['type'] == 'priority') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(array('success' => false, 'message' => "CSRF token validation failed."));
        exit();
    }

    $id = isset($_POST['id']) ? base64_decode($_POST['id']) : '';
    $priority = validate_special_character(htmlspecialchars(trim($_POST['Priority'])));

    if ($id == '') {
        //check priority already exists
        $is_exist = "SELECT Id FROM Priorities WHERE Priority = ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";

        // Prepare the statement
        $params = array($priority);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);

        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Priority already exists.'));
            exit;
        }

        $sql = "INSERT INTO Priorities(Priority, CreatedBy) VALUES (?, ?);";
        $params = array(&$priority, $user);
        $stmt = sqlsrv_prepare($conn, $sql, $params);

        if (sqlsrv_execute($stmt)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => 'Data inserted successfully.', 'csrf_token' => $_SESSION['csrf_token']));
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't insert, Try again"));
        }
    } else {
        //check priority already exists
        $is_exist = "SELECT Id FROM Priorities WHERE Priority = ? AND Id <> ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";
        // Prepare the statement
        $params = array($priority, $id);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);

        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Priority already exists.'));
            exit;
        }

        $sql = "UPDATE Priorities SET Priority=?, ModifiedBy = ?, ModifiedAt = ? WHERE Id=?";
        $up_params = array(&$priority, $user, $cur_date, $id);
        $stmt = sqlsrv_prepare($conn, $sql, $up_params);

        if (sqlsrv_execute($stmt)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => "Data updated successfully", 'csrf_token' => $_SESSION['csrf_token']));
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't insert, Try again"));
        }
    }
} elseif ($_POST['type'] == 'ticket' && $_POST['ticket_id'] == "") {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(array('success' => false, 'message' => "CSRF token validation failed."));
        exit();
    }

    $select_source = validate(htmlspecialchars(base64_decode($_POST['select_source'])));
    $reported_by = validate_reported_by(htmlspecialchars($_POST['reported_by']));
    $priority = validate(htmlspecialchars(base64_decode($_POST['priority'])));
    $select_status = htmlspecialchars(base64_decode($_POST['select_status']));
    $ticket_title = validate_special_character(htmlspecialchars(trim($_POST['ticket_title'])));
    $case_details = validate_textarea(htmlspecialchars($_POST['case_details']));
    $immediate_action_taken = validate_textarea(htmlspecialchars($_POST['immediate_action_taken']));
    $follow_up_at =  $_POST['follow_up_at'] != '' ? validate_follow_up_at(htmlspecialchars(trim($_POST['follow_up_at']))) : '';
    $next_follow_up_date = $_POST['next_follow_up_date'] != '' ? htmlspecialchars($_POST['next_follow_up_date']) : '';
    $department = validate(htmlspecialchars($_POST['department']));
    $parent = validate(htmlspecialchars($_POST['parent']));
    $child = htmlspecialchars($_POST['child']);
    $sub_child_1 = htmlspecialchars($_POST['sub_child_1']);
    $sub_child_2 = htmlspecialchars($_POST['sub_child_2']);
    $sub_child_3 = htmlspecialchars($_POST['sub_child_3']);
    $sub_child_4 = htmlspecialchars($_POST['sub_child_4']);
    $source_url = htmlspecialchars($_POST['source_url']);

    // fetch category id start
    $category_where = '';
    $params = array();

    if ($department != '') {
        $category_where .= " Department = ?";
        $params[] = $department;
    }
    if ($parent != '') {
        $category_where .= " AND Parent = ?";
        $params[] = $parent;
    }
    if ($child != '') {
        $category_where .= " AND Child = ?";
        $params[] = $child;
    }
    if ($sub_child_1 != '') {
        $category_where .= " AND Sub_Child_1 = ?";
        $params[] = $sub_child_1;
    }
    if ($sub_child_2 != '') {
        $category_where .= " AND Sub_Child_2 = ?";
        $params[] = $sub_child_2;
    }
    if ($sub_child_3 != '') {
        $category_where .= " AND Sub_Child_3 = ?";
        $params[] = $sub_child_3;
    }
    if ($sub_child_4 != '') {
        $category_where .= " AND Sub_Child_4 = ?";
        $params[] = $sub_child_4;
    }

    $category_id = '';
    if ($category_where != '' &&  !empty($params)) {
        $cate_sql = "SELECT ID FROM Ticketing_Categories WHERE " . $category_where;
        $stmt = sqlsrv_prepare($conn, $cate_sql, $params);

        $result = sqlsrv_execute($stmt);

        // Fetch the result
        if ($result && sqlsrv_has_rows($stmt)) {
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            $category_id = $row['ID'];
        }
    }
    // fetch category id end

    $data = [];
    $AttachmentsArr = [];
    $attachments_path = [];

    if (!empty($_FILES['attachments']['name'][0])) {
        $files = $_FILES['attachments'];

        //upload multiple files
        $maxsize = 2097152; //max size 2MB

        $uploadError = [];
        for ($i = 0; $i < count($files['name']); $i++) {
            // Get file details
            $fileName = $files['name'][$i];
            $fileTmpName = $files['tmp_name'][$i];
            $fileSize = $files['size'][$i];
            $fileError = $files['error'][$i];

            //check file extension it must be jpg, jpeg, png, pdf, txt, doc, docx
            $fileExt = explode('.', $fileName);
            $fileActualExt = strtolower(end($fileExt));
            $allowed = array('jpg', 'jpeg', 'png', 'pdf', 'txt', 'doc', 'docx');
            if (!in_array($fileActualExt, $allowed)) {
                echo json_encode(array('success' => false, 'message' => "Only jpg, jpeg, png, pdf, txt, doc, docx files are allowed"));
                exit();
            }

            //check file size it should be upto 2mb
            if ($fileSize > $maxsize) {
                echo json_encode(array('success' => false, 'message' => 'File too large. File must be less than 2 MB.'));
                exit();
            }

            // Check if file has been uploaded successfully
            if ($fileError === UPLOAD_ERR_OK) {
                // Generate a unique filename to avoid conflicts
                $uniqueFilename = uniqid() . '_' . $fileName;

                // Move the file to the upload directory
                $uploadPath = $uploadTicketDir . $uniqueFilename;

                if (move_uploaded_file($fileTmpName, $uploadPath)) {
                    // File uploaded successfully
                    $AttachmentsArr[] = $uniqueFilename;
                    $attachments_path[] = $uploadTicketDir . $uniqueFilename;
                } else {
                    // Error while moving the file
                    echo json_encode(array('success' => false, 'message' => "Error uploading file '$fileName'."));
                    exit();
                }
            } else {
                // Handle upload error
                echo json_encode(array('success' => false, 'message' => "Error uploading file '$fileName': " . $fileError));
                exit();
            }
        }
    }

    //generate email identifier
    $timestamp = time();   // Get the current timestamp and convert it to a string

    // Define the characters to use in the random part
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomLength = 6;

    // Use the timestamp to seed the random number generator for better randomness
    mt_srand($timestamp);

    $randomString = '';
    for ($i = 0; $i < $randomLength; $i++) {
        $randomString .= $characters[mt_rand(0, strlen($characters) - 1)];
    }

    //Check ticket title already exists
    $is_exist = "SELECT Id FROM Tickets WHERE Title = ? AND Source = ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";
    // Prepare the statement
    $params = array($ticket_title, $select_source);
    $stmt = sqlsrv_prepare($conn, $is_exist, $params);
    // Execute the statement
    $result = sqlsrv_execute($stmt);
    // Check if any rows exist
    if ($result && sqlsrv_has_rows($stmt)) {
        echo json_encode(array('success' => false, 'message' => 'Ticket title already exists.'));
        exit;
    }

    $sql_ticket = "INSERT INTO Tickets(Source, ReportedBy, Priority, Status, Title, CaseDetails, ImmediateActionTaken, NextFollowUpDate, FollowUpAt, Attachments, Category, SourceUrl, EmailIdentifier, CreatedBy) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
    $ticket_params = array(&$select_source, $reported_by, $priority, $select_status, $ticket_title, $case_details, $immediate_action_taken, $next_follow_up_date, $follow_up_at, serialize($AttachmentsArr), $category_id, $source_url, $randomString, $user);

    $stmt_ticket = sqlsrv_prepare($conn, $sql_ticket, $ticket_params);
    if (sqlsrv_execute($stmt_ticket)) {
        //get last inserted ticket id
        $sql_last_id = "SELECT TOP 1 Id AS LastInsertedID FROM Tickets ORDER BY Id DESC";
        $stmt_last_id = sqlsrv_prepare($conn, $sql_last_id);
        if (sqlsrv_execute($stmt_last_id)) {
            $row = sqlsrv_fetch_array($stmt_last_id, SQLSRV_FETCH_ASSOC);
            $last_inserted_id = $row['LastInsertedID'];
        }

        $ticket_data_sql = "SELECT 
            ts.Status AS TicketStatus, 
            p.Priority AS TicketPriority, 
            s.Source AS TicketSource
        FROM 
            Tickets t 
        JOIN 
            Status ts ON t.Status = ts.Id 
        JOIN
            Priorities p ON t.Priority = p.Id
        JOIN
            Source s ON t.Source = s.Id       
        WHERE 
            t.Id = ? AND t.IsDeleted = 0";

        // Prepare the statement
        $params = array($last_inserted_id);
        $stmt = sqlsrv_prepare($conn, $ticket_data_sql, $params);   
        
        $ticket_data = sqlsrv_execute($stmt);

        // Fetch the result
        $ticket_data_row = array();
        if ($ticket_data !== false && sqlsrv_has_rows($stmt)) {
            $ticket_data_row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        }

        if ($category_id != '') {
            $cate_sql = "SELECT * FROM Ticketing_Categories WHERE ID = ? AND Active = 1";

            // Prepare the statement
            $params = array($category_id);
            $stmt = sqlsrv_prepare($conn, $cate_sql, $params);

            $cate_result = sqlsrv_execute($stmt);

            // Fetch the result
            if ($cate_result !== false && sqlsrv_has_rows($stmt)) {
                $row_category = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

                $department = $row_category['Department'];
                $parent = $row_category['Parent'];
                $child = $row_category['Child'];
                $sub_child_1 = $row_category['Sub_Child_1'];
                $sub_child_2 = $row_category['Sub_Child_2'];
                $sub_child_3 = $row_category['Sub_Child_3'];
                $sub_child_4 = $row_category['Sub_Child_4'];
            }
        }

        $tmpfilePath = "email_template.php";
        $message = '';
        if (file_exists($tmpfilePath)) {
            $templateContent = file_get_contents($tmpfilePath);

            if (!empty($ticket_data_row) && ($category_id != '')) {
                $template_data = array('select_source' => $ticket_data_row['TicketSource'], 'reported_by' => $reported_by, 'priority' => $ticket_data_row['TicketPriority'], 'select_status' => $ticket_data_row['TicketStatus'], 'ticket_title' => $ticket_title, 'case_details' => $case_details, 'immediate_action_taken' => $immediate_action_taken, 'next_follow_up_date' => $next_follow_up_date, 'follow_up_at' => $follow_up_at, 'department' => $department, 'parent' => $parent, 'child' => $child, 'sub_child_1' => $sub_child_1, 'sub_child_2' => $sub_child_2, 'sub_child_3' => $sub_child_3, 'sub_child_4' => $sub_child_4);

                foreach ($template_data as $key => $value) {
                    $placeholder = '{{' . $key . '}}';
                    if ($value != '') {
                        $templateContent = str_replace($placeholder, htmlspecialchars($value), $templateContent);
                    } else {
                        $templateContent = preg_replace('/<tr {{#'.$key.'}}.*?<\/tr>/s', '', $templateContent);
                        $templateContent = str_replace($placeholder, '', $templateContent);
                    }
                }
            }
            $message = $templateContent;
        }

        $subject = $ticket_title . ' - ' . $randomString;
        $from = 'noreply@electronicpayments.com';
        $to = 'rob@electronicpayments.com';

        //mail send
        $mail_send = send_ticket_mail($from, $to, $subject, $message, $attachments_path);

        if ($mail_send) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => 'Ticket Created and Mail Sent Successfully'));
        } else {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => 'Ticket Created and Mail Not Sent'));
        }
    } else {
        echo json_encode(array('success' => false, 'message' => "Can't insert data" . print_r(sqlsrv_errors())));
    }
}

// For update query
elseif ($_POST['type'] == 'ticket' && $_POST['ticket_id'] != "") {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(array('success' => false, 'message' => "CSRF token validation failed."));
        exit();
    }

    $_POST['follow_up_at'] = $_POST['ed_follow_up_at'];
    $ticket_id = isset($_POST['ticket_id']) ? base64_decode($_POST['ticket_id']) : '';
    $tenant_id = isset($_POST['tenant_id']) ? base64_decode($_POST['tenant_id']) : '';
    // $select_source = validate(htmlspecialchars(base64_decode($_POST['select_source'])));
    $reported_by = validate_reported_by(htmlspecialchars($_POST['reported_by']));
    $department = validate(htmlspecialchars($_POST['department']));
    $parent = validate(htmlspecialchars($_POST['parent']));
    $child = htmlspecialchars($_POST['child']);
    $sub_child_1 = htmlspecialchars($_POST['sub_child_1']);
    $sub_child_2 = htmlspecialchars($_POST['sub_child_2']);
    $sub_child_3 = htmlspecialchars($_POST['sub_child_3']);
    $sub_child_4 = htmlspecialchars($_POST['sub_child_4']);
    $priority = validate(htmlspecialchars(base64_decode($_POST['priority'])));
    $select_status = htmlspecialchars(base64_decode($_POST['select_status']));
    $ticket_title = validate_special_character(htmlspecialchars(trim($_POST['ticket_title'])));
    $case_details = validate_textarea(htmlspecialchars($_POST['case_details']));
    $immediate_action_taken = validate_textarea(htmlspecialchars($_POST['immediate_action_taken']));
    $follow_up_at = $_POST['follow_up_at'] ? validate_follow_up_at(htmlspecialchars(trim($_POST['follow_up_at']))) : '';
    $next_follow_up_date = $_POST['next_follow_up_date'] != '' ? htmlspecialchars($_POST['next_follow_up_date']) : '';
    $data = [];

    // $_POST['select_source'] = base64_decode($_POST['select_source']);
    $_POST['tenant_id'] = base64_decode($_POST['tenant_id']);
    $_POST['priority'] = base64_decode($_POST['priority']);
    $_POST['select_status'] = base64_decode($_POST['select_status']);

    //Check ticket title already exists
    $is_exist = "SELECT Id FROM Tickets WHERE Title = ? AND Source = ? AND Id <> ? AND IsDeleted = 0";

    // Prepare the statement
    $params = array($ticket_title, $_POST['tenant_id'] ,$ticket_id);
    $stmt = sqlsrv_prepare($conn, $is_exist, $params);

    $result = sqlsrv_execute($stmt);

    // Check if any rows exist
    if ($result && sqlsrv_has_rows($stmt)) {
        echo json_encode(array('success' => false, 'message' => 'Ticket title already exists.'));
        exit;
    }

    $category_where = '';
    $params = [];

    if ($department != '') {
        $category_where .= " Department = ?";
        $params[] = $department;
    }
    if ($parent != '') {
        $category_where .= " AND Parent = ?";
        $params[] = $parent;
    }
    if ($child != '') {
        $category_where .= " AND Child = ?";
        $params[] = $child;
    }
    if ($sub_child_1 != '') {
        $category_where .= " AND Sub_Child_1 = ?";
        $params[] = $sub_child_1;
    }
    if ($sub_child_2 != '') {
        $category_where .= " AND Sub_Child_2 = ?";
        $params[] = $sub_child_2;
    }
    if ($sub_child_3 != '') {
        $category_where .= " AND Sub_Child_3 = ?";
        $params[] = $sub_child_3;
    }
    if ($sub_child_4 != '') {
        $category_where .= " AND Sub_Child_4 = ?";
        $params[] = $sub_child_4;
    }

    // fetch category id
    $category_id = '';
    if ($category_where != '' &&  !empty($params)) {
        $cate_sql = "SELECT ID FROM Ticketing_Categories WHERE " . $category_where;
        $stmt = sqlsrv_prepare($conn, $cate_sql, $params);

        $result = sqlsrv_execute($stmt);

        // Fetch the result
        if ($result && sqlsrv_has_rows($stmt)) {
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            $category_id = $row['ID'];
        }
    }

    $_POST['category'] = $category_id;

    //get old ticket data
    $oldTicketData = [];
    $OldTicketFile = [];

    $oldTicketQuery = "SELECT * FROM Tickets WHERE Id = ? AND IsDeleted = 0";

    // Prepare the statement
    $params = array($ticket_id);
    $stmt = sqlsrv_prepare($conn, $oldTicketQuery, $params);

    $oldTktData = sqlsrv_execute($stmt);
    
    $FileArr = [];
    if ($oldTktData !== false && sqlsrv_has_rows($stmt)) {
        $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

        $OldNextFollowUpDate = '';
        if ($row['NextFollowUpDate'] != NULL) {
            $formatted_date = $row['NextFollowUpDate']->format('Y-m-d');
            $OldNextFollowUpDate = ($formatted_date != '1900-01-01') ? $row['NextFollowUpDate'] : '';
        }

        $oldHistoryData = $row;

        $oldTicketData = [
            'ticket_title' => $row['Title'],
            'tenant_id' => $row['Source'],
            'reported_by' => $row['ReportedBy'],
            'select_status' => $row['Status'],
            'category' => $row['Category'],
            'priority' => $row['Priority'],
            'immediate_action_taken' => $row['ImmediateActionTaken'],
            'case_details' => $row['CaseDetails'],
            'follow_up_at' => $row['FollowUpAt'],
            'next_follow_up_date' => ($OldNextFollowUpDate != '') ? $row['NextFollowUpDate']->format('m/d/Y') : NULL
        ];
        $OldTicketFile = unserialize($row['Attachments']);
        $FileArr = $OldTicketFile;
    }

    $historyArray = [];
    $historyData = [];
    $FilenameArr = [];
    $attachments_path = [];

    if (!empty($_FILES['attachments']['name'][0])) {
        $files = $_FILES['attachments'];

        //upload multiple files
        $maxsize = 2097152; //max size 2MB

        $uploadError = [];
        for ($i = 0; $i < count($files['name']); $i++) {
            // Get file details
            $fileName = $files['name'][$i];
            $fileTmpName = $files['tmp_name'][$i];
            $fileSize = $files['size'][$i];
            $fileError = $files['error'][$i];

            //check file extension it must be jpg, jpeg, png, pdf, txt, doc, docx
            $fileExt = explode('.', $fileName);
            $fileActualExt = strtolower(end($fileExt));
            $allowed = array('jpg', 'jpeg', 'png', 'pdf', 'txt', 'doc', 'docx');
            if (!in_array($fileActualExt, $allowed)) {
                echo json_encode(array('success' => false, 'message' => "Only jpg, jpeg, png, pdf, txt, doc, docx files are allowed"));
                exit();
            }

            //check file size it should be upto 2mb
            if ($fileSize > $maxsize) {
                echo json_encode(array('success' => false, 'message' => 'File too large. File must be less than 2 MB.'));
                exit();
            }

            // Check if file has been uploaded successfully
            if ($fileError === UPLOAD_ERR_OK) {
                // Generate a unique filename to avoid conflicts
                $uniqueFilename = uniqid() . '_' . $fileName;

                // Move the file to the upload directory
                $uploadPath = $uploadTicketDir . $uniqueFilename;

                if (move_uploaded_file($fileTmpName, $uploadPath)) {
                    // File uploaded successfully
                    $FilenameArr[] = $uniqueFilename;
                    $attachments_path[] = $uploadTicketDir .$uniqueFilename;
                } else {
                    // Error while moving the file
                    echo json_encode(array('success' => false, 'message' => "Error uploading file '$fileName'."));
                    exit();
                }
            } else {
                // Handle upload error
                echo json_encode(array('success' => false, 'message' => "Error uploading file '$fileName': " . $fileError));
                exit();
            }
        }
        if (!empty($OldTicketFile)) {
            $FileArr = array_merge($OldTicketFile, $FilenameArr);
        } else {
            $FileArr = $FilenameArr;
        }
    }

    $historyDataMerge = [];
    if (!empty($FilenameArr)) {
        $diffFile = [];
        if (!empty($OldTicketFile)) {
            $diffFile['Attachments'] = serialize(array_diff($OldTicketFile, $FilenameArr));
        } else {
            $diffFile['Attachments'] = serialize(array());
        }

        $historyDataMerge = array_merge($historyArray, $diffFile);
    }

    $historyArray = array();
    $historyData = array();

    $diff = array_diff_assoc($oldTicketData, $_POST);
    if (count($diff) > 0) {
        $historyData = array_merge($historyDataMerge, $diff);
    }

    if (empty($historyData)) {
        $historyData = $historyDataMerge;
    }

    $sql_ticket = "UPDATE Tickets SET Title = ?, Source = ?, ReportedBy = ?, Category = ?, Priority = ?, Status = ?, CaseDetails = ?, ImmediateActionTaken = ?, FollowUpAt = ?, NextFollowUpDate = ?, Attachments = ?, ModifiedBy = ?, ModifiedAt = ? WHERE Id = ?;";
    $ticket_params = array(&$ticket_title, $tenant_id, $reported_by, $category_id, $priority, $select_status, $case_details, $immediate_action_taken, $follow_up_at, $next_follow_up_date, serialize($FileArr), $user, $cur_date, $ticket_id);

    $stmt_ticket = sqlsrv_prepare($conn, $sql_ticket, $ticket_params);
    if (sqlsrv_execute($stmt_ticket)) {
        $is_mail_sent = false;

        if (!empty($historyData)) {
            $historyData['Action'] = "Updated";
            $in_history = "INSERT INTO History(TicketId,CreatedBy,UpdatedData,HistoryData,IPAddress) Values (?,?,?,?,?)";
            $history_params = array(&$ticket_id, $user, serialize($historyData), serialize($oldHistoryData), $ipaddress);
            $sql_history = sqlsrv_prepare($conn, $in_history, $history_params);
            if (!sqlsrv_execute($sql_history)) {
                echo json_encode(array('success' => false, 'message' => "Error inserting data into tickets: " . print_r(sqlsrv_errors(), true)));
            }

            $dataArray = array(
                'Title' => $ticket_title,
                'Source' => $tenant_id,
                'ReportedBy' => $reported_by,
                'Category' => $category_id,
                'Priority' => $priority,
                'SelectStatus' => $select_status,
                'CaseDetails' => $case_details,
                'ImmediateActionTaken' => $immediate_action_taken,
                'FollowUpAt' => $follow_up_at,
                'NextFollowUpDate' => $next_follow_up_date,
                'IpAddress' => $ipaddress,
                'UserId' => $user,
                'Attachments' => serialize($FileArr)
            );
            $response = array(
                'Data' => $dataArray
            );
            $serializedResponse = serialize($response);

            //check draft already saved or not
            $exe_update = false;
            $check_draft = "SELECT Id FROM Draft WHERE TicketId = $ticket_id";
            $check_draft_data = sqlsrv_query($conn, $check_draft);
            if (sqlsrv_has_rows($check_draft_data)) {
                $exe_update = true;
            } else {
                $exe_update = false;
            }

            if ($exe_update) {
                $sql_in = "UPDATE Draft SET DraftData = ?, ModifiedAt = ?, ModifiedBy = ? WHERE TicketId = ?;";
                $draft_para = sqlsrv_prepare($conn, $sql_in, array(&$serializedResponse, $cur_date, $user, $ticket_id));
                if (sqlsrv_execute($draft_para)) {
                    $is_mail_sent = true;
                } else {
                    echo json_encode(array('success' => false, 'message' => "Can't insert, Try again."));
                }
            } else {
                $sql_in = "INSERT INTO Draft(TicketId, CreatedBy, DraftData) values (?,?,?);";
                $draft_para = sqlsrv_prepare($conn, $sql_in, array(&$ticket_id, $user, $serializedResponse));
                if (sqlsrv_execute($draft_para)) {
                    $is_mail_sent = true;
                } else {
                    echo json_encode(array('success' => false, 'message' => "Can't insert, Try again."));
                }
            }
        } else {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => 'Data Successfully updated.'));
        }

        //send mail start
        if ($is_mail_sent) {
            $ticket_data_sql = "SELECT 
                        t.EmailIdentifier, 
                        ts.Status AS TicketStatus, 
                        p.Priority AS TicketPriority, 
                        s.Source AS TicketSource
                    FROM 
                        Tickets t 
                    JOIN 
                        Status ts ON t.Status = ts.Id 
                    JOIN
                        Priorities p ON t.Priority = p.Id
                    JOIN
                        Source s ON t.Source = s.Id       
                    WHERE 
                        t.Id = ? AND t.IsDeleted = 0";

            // Prepare the statement
            $params = array($ticket_id);
            $stmt = sqlsrv_prepare($conn, $ticket_data_sql, $params); 
            
            $ticket_data = sqlsrv_execute($stmt);

            $ticket_data_row = array();
            if ($ticket_data !== false && sqlsrv_has_rows($stmt)) {
                $ticket_data_row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            }

            if ($category_id != '') {
                $cate_sql = "SELECT * FROM Ticketing_Categories WHERE ID = ? AND Active = 1";

                // Prepare the statement
                $params = array($category_id);
                $stmt = sqlsrv_prepare($conn, $cate_sql, $params);

                $cate_result = sqlsrv_execute($stmt);

                // Fetch the result
                if ($cate_result !== false && sqlsrv_has_rows($stmt)) {
                    $row_category = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

                    $department = $row_category['Department'];
                    $parent = $row_category['Parent'];
                    $child = $row_category['Child'];
                    $sub_child_1 = $row_category['Sub_Child_1'];
                    $sub_child_2 = $row_category['Sub_Child_2'];
                    $sub_child_3 = $row_category['Sub_Child_3'];
                    $sub_child_4 = $row_category['Sub_Child_4'];
                }
            }

            $tmpfilePath = "email_template.php";
            $message = '';
            if (file_exists($tmpfilePath)) {
                $templateContent = file_get_contents($tmpfilePath);

                if (!empty($ticket_data_row) && ($category_id != '')) {
                    $template_data = array('select_source' => $ticket_data_row['TicketSource'], 'reported_by' => $reported_by, 'priority' => $ticket_data_row['TicketPriority'], 'select_status' => $ticket_data_row['TicketStatus'], 'ticket_title' => $ticket_title, 'case_details' => $case_details, 'immediate_action_taken' => $immediate_action_taken, 'next_follow_up_date' => $next_follow_up_date, 'follow_up_at' => $follow_up_at, 'department' => $department, 'parent' => $parent, 'child' => $child, 'sub_child_1' => $sub_child_1, 'sub_child_2' => $sub_child_2, 'sub_child_3' => $sub_child_3, 'sub_child_4' => $sub_child_4);

                    foreach ($template_data as $key => $value) {
                        $placeholder = '{{' . $key . '}}';
                        if ($value != '') {
                            $templateContent = str_replace($placeholder, htmlspecialchars($value), $templateContent);
                        } else {
                            $templateContent = preg_replace('/<tr {{#'.$key.'}}.*?<\/tr>/s', '', $templateContent);
                            $templateContent = str_replace($placeholder, '', $templateContent);
                        }
                    }
                }
                $message = $templateContent;
            }

            if($ticket_data_row['TicketStatus'] == 'Closed'){
                $subject = 'Ticket closed '.$ticket_title . ' - ' . $ticket_data_row['EmailIdentifier'];
            } else {
                $subject = 'Ticket updated '.$ticket_title . ' - ' . $ticket_data_row['EmailIdentifier'];
            }

            $from = 'noreply@electronicpayments.com';
            $to = 'rob@electronicpayments.com';
            
            $mail_send = send_ticket_mail($from, $to, $subject, $message, $attachments_path);

            if ($mail_send) {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                echo json_encode(array('success' => true, 'message' => 'Data Updated and Mail Sent Successfully.'));
            } else {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                echo json_encode(array('success' => true, 'message' => 'Data Updated Successfully.'));
            }
        }
        //send mail end
    } else {
        echo json_encode(array('success' => false, 'message' => "Can't update, Try again"  . print_r(sqlsrv_errors(), true)));
    }
} elseif ($_POST['type'] == 'source') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(array('success' => false, 'message' => "CSRF token validation failed."));
        exit();
    }

    $id = htmlspecialchars(base64_decode($_POST['id']));
    $source = validate_special_character(htmlspecialchars(trim($_POST['source'])));
    $source_details = validate_textarea(htmlspecialchars($_POST['source_details']));

    if ($id == '') {
        //check source already exists
        $is_exist = "SELECT Id FROM Source WHERE Source = ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";

        $params = array($source);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);

        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Source already exists'));
            exit;
        }

        $sql = "INSERT INTO Source (Source, SourceDetails, CreatedBy) VALUES (?,?,?)";
        $stmt = sqlsrv_prepare($conn, $sql, array(&$source, &$source_details, $user));

        if (sqlsrv_execute($stmt)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => "Data inserted successfully", 'csrf_token' => $_SESSION['csrf_token']));
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't insert, Try again"));
        }
    } else {
        //check source already exists
        $is_exist = "SELECT Id FROM Source WHERE Source = ? AND Id <> ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";

        // Prepare the statement
        $params = array($source, $id);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);

        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Source already exists'));
            exit;
        }

        $sql = "UPDATE Source SET Source = ?, SourceDetails = ?, ModifiedBy=?, ModifiedAt=? WHERE Id = ?";
        $stmt = sqlsrv_prepare($conn, $sql, array(&$source, &$source_details, $user, $cur_date, &$id));

        if (sqlsrv_execute($stmt)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => "Data updated successfully", 'csrf_token' => $_SESSION['csrf_token']));
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't insert, Try again"));
        }
    }
} elseif ($_POST['type'] == 'ticket_license') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(array('success' => false, 'message' => "CSRF token validation failed."));
        exit();
    }

    $id = isset($_POST['id']) ? base64_decode($_POST['id']) : '';
    $tenant_id = isset($_POST['tenant_id']) ? base64_decode($_POST['tenant_id']) : '';
    $tenant_url = validateURL(htmlspecialchars(trim($_POST['tenant_url'])));
    $license_key = htmlspecialchars($_POST['license_key']);
    $issue_date = htmlspecialchars($_POST['issue_date']);
    $expiry_date = htmlspecialchars($_POST['expiry_date']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    //fetch tenant name
    $tenant_name_sql = "SELECT Source FROM Source WHERE Id = ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";

    // Prepare the statement
    $params = array($tenant_id);
    $stmt = sqlsrv_prepare($conn, $tenant_name_sql, $params);

    $tenant_name_result = sqlsrv_execute($stmt);
    $tenant_name = '';
    if ($tenant_name_result !== false && sqlsrv_has_rows($stmt)) {
        $tenant_name_row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        $tenant_name = $tenant_name_row['Source'];
    }

    //css content fetch start
    $css_content = '';
    if (!empty($_FILES['source_css']['name'])) {
        $file = $_FILES['source_css'];
        
        $maxsize = 5242880; // Max size 5MB
    
        // Get file details
        $fileName = $file['name'];
        $fileTmpName = $file['tmp_name'];
        $fileSize = $file['size'];
        $fileError = $file['error'];
    
        // Check file extension: must be css
        $fileExt = explode('.', $fileName);
        $fileActualExt = strtolower(end($fileExt));
        $allowed = array('css');
    
        if (!in_array($fileActualExt, $allowed)) {
            echo json_encode(array('success' => false, 'message' => "Only CSS files are allowed."));
            exit();
        }
    
        // Check file size: should be up to 2MB
        if ($fileSize > $maxsize) {
            echo json_encode(array('success' => false, 'message' => 'File too large. File must be less than 5 MB.'));
            exit();
        }

        // Read the file content
        $css_content = file_get_contents($fileTmpName);
    }
    //css content fetch end

    if ($id == '') {
        //check tenant and license key already exists
        $is_exist = "SELECT TenantID FROM License WHERE (IsDeleted = 0 OR IsDeleted IS NULL) AND (TenantID = ? OR LicenseKey = ?)";
        // Prepare the statement
        $params = array($tenant_id, $license_key);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);

        $result = sqlsrv_execute($stmt);
        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Tenant or license key already exists.'));
            exit;
        }

        $sql = "INSERT INTO License(TenantName, TenantID, TenantURL, LicenseKey, IssueDate, ExpiryDate, CreatedBy, IsActive, CssContent) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
        $params = array($tenant_name, $tenant_id, $tenant_url, $license_key, $issue_date, $expiry_date, $user, $is_active, $css_content);

        $stmt = sqlsrv_prepare($conn, $sql, $params);

        if (sqlsrv_execute($stmt)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => 'Data inserted successfully.', 'csrf_token' => $_SESSION['csrf_token']));
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't insert, Try again"));
        }
    } else {
        //check tenant already exists
        $is_exist = "SELECT TenantID FROM License 
             WHERE (TenantID = ? OR LicenseKey = ?) 
             AND Id <> ? 
             AND (IsDeleted = 0 OR IsDeleted IS NULL)";

        // Prepare the statement
        $params = array($tenant_id, $license_key, $id);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);  
        
        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Tenant or license key already exists.'));
            exit;
        }
        
        if($css_content !== ''){
            $sql = "UPDATE License SET TenantName=?, TenantID=?, TenantURL=?, LicenseKey=?, IssueDate=?, ExpiryDate=?, IsActive=?, ModifiedBy = ?, ModifiedAt = ?, CssContent = ? WHERE Id=?";
            $up_params = array($tenant_name, $tenant_id, $tenant_url, $license_key, $issue_date, $expiry_date, $is_active, $user, $cur_date, $css_content, $id);
        } else {
            $sql = "UPDATE License SET TenantName=?, TenantID=?, TenantURL=?, LicenseKey=?, IssueDate=?, ExpiryDate=?, IsActive=?, ModifiedBy = ?, ModifiedAt = ? WHERE Id=?";
            $up_params = array($tenant_name, $tenant_id, $tenant_url, $license_key, $issue_date, $expiry_date, $is_active, $user, $cur_date, $id);
        }

        $stmt = sqlsrv_prepare($conn, $sql, $up_params);

        if (sqlsrv_execute($stmt)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => "Data updated successfully", 'csrf_token' => $_SESSION['csrf_token']));
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't insert, Try again"));
        }
    }
} elseif ($_POST['type'] == 'permission') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(array('success' => false, 'message' => "CSRF token validation failed."));
        exit();
    }

    $id = isset($_POST['id']) ? base64_decode($_POST['id']) : '';
    $permission = validate_special_character(htmlspecialchars(trim($_POST['Permission'])));
    $permission_tag = validate_perm_tag(htmlspecialchars(trim($_POST['PermissionTag'])));

    if ($id == '') {
        //check priority already exists
        $is_exist = "SELECT Id FROM Permissions WHERE (Permission = ? OR PermissionTag = ?) AND (IsDeleted = 0 OR IsDeleted IS NULL)";

        // Prepare the statement
        $params = array($permission, $permission_tag);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);

        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Permission already exists.'));
            exit;
        }

        $sql = "INSERT INTO Permissions(Permission, PermissionTag, CreatedBy) VALUES (?, ?, ?);";
        $params = array(&$permission, $permission_tag, $user);
        $stmt = sqlsrv_prepare($conn, $sql, $params);

        if (sqlsrv_execute($stmt)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => 'Data inserted successfully.', 'csrf_token' => $_SESSION['csrf_token']));
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't insert, Try again"));
        }
    } else {
        //check priority already exists
        $is_exist = "SELECT Id FROM Permissions WHERE (Permission = ? OR PermissionTag = ?) AND Id <> ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";
        // Prepare the statement
        $params = array($permission, $permission_tag, $id); 
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);

        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Permission already exists.'));
            exit;
        }

        $sql = "UPDATE Permissions SET Permission=?, PermissionTag = ?, ModifiedBy = ?, ModifiedAt = ? WHERE Id=?";
        $up_params = array(&$permission, $permission_tag, $user, $cur_date, $id);

        $stmt = sqlsrv_prepare($conn, $sql, $up_params);

        if (sqlsrv_execute($stmt)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => "Data updated successfully", 'csrf_token' => $_SESSION['csrf_token']));
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't Update, Try again"));
        }
    }
} elseif ($_POST['type'] == 'role') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(array('success' => false, 'message' => "CSRF token validation failed."));
        exit();
    }

    $id = isset($_POST['id']) ? base64_decode($_POST['id']) : '';
    $role = validate_special_character(htmlspecialchars(trim($_POST['role'])));
    $permission_post = isset($_POST['permission']) ? $_POST['permission'] : array();
    $permission = validate_permission($permission_post);
    $is_superadmin = isset($_POST['is_superadmin']) ? 1 : 0;

    if ($id == '') {
        //check priority already exists
        $is_exist = "SELECT Id FROM Roles WHERE Role = ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";  

        // Prepare the statement
        $params = array($role);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);

        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Role already exists.'));
            exit;
        }

        $sql = "INSERT INTO Roles(Role, CreatedBy, IsSuperAdmin) VALUES (?, ?, ?);";
        $params = array(&$role, $user, $is_superadmin);
        $stmt = sqlsrv_prepare($conn, $sql, $params);

        if (sqlsrv_execute($stmt)) {
            //get role id
            $sql = "SELECT TOP 1 Id FROM Roles ORDER BY Id DESC";
            // $params = array($role);
            $stmt = sqlsrv_prepare($conn, $sql);
            sqlsrv_execute($stmt);
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

            $role_id = $row['Id'];
            
            //delete and insert
            $sql = "DELETE FROM RolePermissions WHERE Role = ?;";
            $params = array($role_id);
            $stmt = sqlsrv_prepare($conn, $sql, $params);
            sqlsrv_execute($stmt);

            $is_error = 0;
            $sql = "INSERT INTO RolePermissions(Role, Permission, CreatedBy) VALUES (?, ?, ?);";
            foreach ($permission as $key => $value) {
                $params = array(&$role_id, base64_decode($value), $user);
                $stmt = sqlsrv_prepare($conn, $sql, $params);
                if(!sqlsrv_execute($stmt)){
                    $is_error++;
                }
            }

            if($is_error == 0){
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                echo json_encode(array('success' => true, 'message' => 'Data inserted successfully.', 'csrf_token' => $_SESSION['csrf_token']));
            } else {
                //delete inserted role
                $sql = "DELETE FROM Roles WHERE Id = ?;";
                $params = array($role_id);
                $stmt = sqlsrv_prepare($conn, $sql, $params);
                sqlsrv_execute($stmt);

                echo json_encode(array('success' => false, 'message' => "Can't insert, Try again"));
            }
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't insert, Try again"));
        }
    } else {
        //check priority already exists
        $is_exist = "SELECT Id FROM Roles WHERE Role = ? AND Id <> ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";
        // Prepare the statement
        $params = array($role, $id);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);
        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Role already exists.'));
            exit;
        }

        $sql = "UPDATE Roles SET Role= ?, IsSuperAdmin = ?, ModifiedBy = ?, ModifiedAt = ? WHERE Id=?";
        $up_params = array(&$role, $is_superadmin, $user, $cur_date, $id);
        $stmt = sqlsrv_prepare($conn, $sql, $up_params);

        if (sqlsrv_execute($stmt)) {

            $sql = "DELETE FROM RolePermissions WHERE Role = ?;";
            $params = array($id);
            $stmt = sqlsrv_prepare($conn, $sql, $params);
            sqlsrv_execute($stmt);

            $is_error = 0;
            $sql = "INSERT INTO RolePermissions(Role, Permission, CreatedBy) VALUES (?, ?, ?);";
            foreach ($permission as $key => $value) {
                $params = array(&$id, base64_decode($value), $user);
                $stmt = sqlsrv_prepare($conn, $sql, $params);
                if(!sqlsrv_execute($stmt)){
                    $is_error++;
                }
            }

            if($is_error == 0){
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                echo json_encode(array('success' => true, 'message' => 'Data updated successfully.', 'csrf_token' => $_SESSION['csrf_token']));
            }
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't insert, Try again"));
        }
    }
} elseif ($_POST['type'] == 'user') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(array('success' => false, 'message' => "CSRF token validation failed."));
        exit();
    }

    $id = isset($_POST['id']) ? base64_decode($_POST['id']) : '';
    $username = validateUsername(htmlspecialchars(trim($_POST['username'])));
    $email = validateEmail(htmlspecialchars(trim($_POST['email'])));
    $password = validatePassword($_POST['password']);
    $select_role = validate(htmlspecialchars(base64_decode($_POST['select_role'])));
    $select_source = validate(htmlspecialchars(base64_decode($_POST['select_source'])));
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    if ($id == '') {
        //check user already exists
        $is_exist = "SELECT Id FROM Users WHERE Username = ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";  

        // Prepare the statement
        $params = array($username);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);

        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'User already exists.'));
            exit;
        }

        //check email already exists
        $is_exist_email = "SELECT Id FROM Users WHERE Email = ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";  

        // Prepare the statement
        $params = array($email);
        $stmt = sqlsrv_prepare($conn, $is_exist_email, $params);

        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Email already exists.'));
            exit;
        }

        //insert data
        $sql = "INSERT INTO Users(Username, Email, Password, Role, Source, IsActive, CreatedBy) VALUES (?, ?, ?, ?, ?, ?, ?);";
        $params = array($username, $email, $password, $select_role, $select_source, $is_active, $user);
        $stmt = sqlsrv_prepare($conn, $sql, $params);   

        if (sqlsrv_execute($stmt)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => 'Data inserted successfully.', 'csrf_token' => $_SESSION['csrf_token']));
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't insert, Try again"));
        }
    } else {
        //check user already exists
        $is_exist = "SELECT Id FROM Users WHERE Username = ? AND Id <> ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";  

        // Prepare the statement
        $params = array($username, $id);
        $stmt = sqlsrv_prepare($conn, $is_exist, $params);
        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'User already exists.'));
            exit;
        }

        //check email already exists
        $is_exist_email = "SELECT Id FROM Users WHERE Email = ? AND Id <> ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";  

        // Prepare the statement
        $params = array($email, $id);
        $stmt = sqlsrv_prepare($conn, $is_exist_email, $params);
        $result = sqlsrv_execute($stmt);

        // Check if any rows exist
        if ($result && sqlsrv_has_rows($stmt)) {
            echo json_encode(array('success' => false, 'message' => 'Email already exists.'));
            exit;
        }

        //update data
        $sql = "UPDATE Users SET Username= ?, Email = ?, Password = ?, Role = ?, Source = ?, IsActive = ?, ModifiedBy = ?, ModifiedAt = ? WHERE Id=?";
        $up_params = array($username, $email, $password, $select_role, $select_source, $is_active, $user, $cur_date, $id);
        $stmt = sqlsrv_prepare($conn, $sql, $up_params);

        if (sqlsrv_execute($stmt)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            echo json_encode(array('success' => true, 'message' => 'Data updated successfully.', 'csrf_token' => $_SESSION['csrf_token']));
        } else {
            echo json_encode(array('success' => false, 'message' => "Can't update, Try again"));
        }
    }
}
