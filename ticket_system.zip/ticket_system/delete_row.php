<?php
include "config.php";

if (!$conn) {
    die("Connection failed: " . print_r(sqlsrv_errors(), true));
} elseif ($_POST['type'] == 'category') {
    if (isset($_POST['id'])) {
        //check category mapped with ticket
        $sql_check = "SELECT Id FROM Tickets WHERE Category =? AND IsDeleted = ?";
        $stmt_check = sqlsrv_prepare($conn, $sql_check, array(base64_decode($_POST['id']), 0));

        $row_ticket_check = array();
        if ($stmt_check) {
            $result_check = sqlsrv_execute($stmt_check);

            if ($result_check) {
                $row_ticket_check = sqlsrv_fetch_array($stmt_check, SQLSRV_FETCH_ASSOC);
            }
        }

        //check category mapped with subcategory
        $sql_subcheck = "SELECT Id FROM SubCategory WHERE Category =? AND IsDeleted = ?";
        $stmt_subcheck = sqlsrv_prepare($conn, $sql_subcheck, array(base64_decode($_POST['id']), 0));

        $row_subcat_check = array();
        if ($stmt_subcheck) {
            $result_subcheck = sqlsrv_execute($stmt_subcheck);

            if ($result_subcheck) {
                $row_subcat_check = sqlsrv_fetch_array($stmt_subcheck, SQLSRV_FETCH_ASSOC);
            }
        }

        if ($row_ticket_check) {
            echo json_encode(array('success' => false, 'message' => 'Category is mapped with Ticket.'));
        } else if ($row_subcat_check) {
            echo json_encode(array('success' => false, 'message' => 'Category is mapped with Sub Category.'));
        } else {
            $sql = "UPDATE Category SET IsDeleted = 1, DeletedAt = GETDATE() WHERE Id = ?;";
            try {

                $stmt = sqlsrv_prepare($conn, $sql, array(base64_decode($_POST['id'])));

                if (sqlsrv_execute($stmt)) {
                    echo json_encode(array('success' => true, 'message' => 'Record has been deleted.'));
                } else {
                    echo json_encode(array('success' => false, 'message' => 'No rows deleted.'));
                }
            } catch (Exception $e) {
                echo json_encode(array('success' => false, 'message' => $e->getMessage()));
            };
        }
    } else {

        echo json_encode(array('success' => false, 'message' => 'ID parameter not set.'));
    }
} elseif ($_POST['type'] == 'types_of_refund') {
    if (isset($_POST['id'])) {
        $sql = "UPDATE RefundTypes SET IsDeleted = 1, DeletedAt = GETDATE() WHERE Id = ?;";

        try {
            $stmt = sqlsrv_prepare($conn, $sql, array(base64_decode($_POST['id'])));

            $result = sqlsrv_execute($stmt);

            if ($result) {
                echo json_encode(array('success' => true, 'message' => 'Record has been deleted.'));
            } else {
                echo json_encode(array('success' => false, 'message' => 'No rows deleted.'));
            }
        } catch (Exception $e) {
            echo json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
    } else {
        echo json_encode(array('success' => false, 'message' => 'ID parameter not set.'));
    }
} elseif ($_POST['type'] == 'Status_of_Tickets') {
    if (isset($_POST['id'])) {
        //check status mapped with ticket
        $sql_check = "SELECT Id FROM Tickets WHERE Status =? AND IsDeleted = ?";
        $stmt_check = sqlsrv_prepare($conn, $sql_check, array(base64_decode($_POST['id']), 0));

        $row_check = array();
        if ($stmt_check) {
            $result_check = sqlsrv_execute($stmt_check);

            if ($result_check) {
                $row_check = sqlsrv_fetch_array($stmt_check, SQLSRV_FETCH_ASSOC);
            }
        }

        if ($row_check) {
            echo json_encode(array('success' => false, 'message' => 'Status is mapped with ticket.'));
        } else {
            $sql = "UPDATE Status SET IsDeleted = 1, DeletedAt = GETDATE() WHERE id = ?;";
            try {
                $stmt = sqlsrv_prepare($conn, $sql, array(base64_decode($_POST['id'])));

                if (sqlsrv_execute($stmt)) {
                    echo json_encode(array('success' => true, 'message' => 'Record has been deleted.'));
                } else {
                    echo json_encode(array('success' => false, 'message' => 'No rows deleted.'));
                }
            } catch (Exception $e) {
                echo json_encode(array('success' => false, 'message' => $e->getMessage()));
            }
        }
    } else {
        echo json_encode(array('success' => false, 'message' => 'ID parameter not set.'));
    }
} elseif ($_POST['type'] == 'priority') {
    if (isset($_POST['id'])) {
        //check priority mapped with ticket
        $sql_check = "SELECT Id FROM Tickets WHERE Priority =? AND IsDeleted = ?";
        $stmt_check = sqlsrv_prepare($conn, $sql_check, array(base64_decode($_POST['id']), 0));

        $row_check = array();
        if ($stmt_check) {
            $result_check = sqlsrv_execute($stmt_check);

            if ($result_check) {
                $row_check = sqlsrv_fetch_array($stmt_check, SQLSRV_FETCH_ASSOC);
            }
        }

        if ($row_check) {
            echo json_encode(array('success' => false, 'message' => 'Priority is mapped with ticket.'));
        } else {
            $sql = "UPDATE Priorities SET IsDeleted = 1, DeletedAt = GETDATE() WHERE id = ?;";
            try {
                $stmt = sqlsrv_prepare($conn, $sql, array(base64_decode($_POST['id'])));
                $result = sqlsrv_execute($stmt);

                if ($result) {
                    echo json_encode(array('success' => true, 'message' => 'Record has been deleted.'));
                } else {
                    echo json_encode(array('success' => false, 'message' => 'No rows deleted.'));
                }
            } catch (Exception $e) {
                echo json_encode(array('success' => false, 'message' => $e->getMessage()));
            }
        }
    } else {
        echo json_encode(array('success' => false, 'message' => 'ID parameter not set.'));
    }
} elseif ($_POST['type'] == 'ticket_and_particular') {
    if (isset($_POST['id'])) {
        $data = [];
        $ipaddress = '';
        if (getenv('HTTP_CLIENT_IP'))
            $ipaddress = getenv('HTTP_CLIENT_IP');
        else if (getenv('HTTP_X_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
        else if (getenv('HTTP_X_FORWARDED'))
            $ipaddress = getenv('HTTP_X_FORWARDED');
        else if (getenv('HTTP_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_FORWARDED_FOR');
        else if (getenv('HTTP_FORWARDED'))
            $ipaddress = getenv('HTTP_FORWARDED');
        else if (getenv('REMOTE_ADDR'))
            $ipaddress = getenv('REMOTE_ADDR');
        else
            $ipaddress = 'UNKNOWN';

        $data[] = $ipaddress;
        $data_ip = json_encode($data);

        try {
            $ticket_id = array(base64_decode($_POST['id']));
           
            //get files from ticket table and unlink it
            $sql_files = "SELECT Attachments FROM Tickets WHERE Id = ? AND IsDeleted = 0 OR IsDeleted IS NULL;";
            $stmt_files = sqlsrv_prepare($conn, $sql_files, $ticket_id);

            $files = array();
            if (sqlsrv_execute($stmt_files)) {
                while ($row_files = sqlsrv_fetch_array($stmt_files, SQLSRV_FETCH_ASSOC)) {
                    $files = unserialize($row_files['Attachments']);
                }

                if(!empty($files)) {
                    foreach ($files as $file) {
                        $file_path = $uploadTicketDir . $file;
                        unlink($file_path);
                    }
                }
            }

            $sql = "UPDATE Tickets SET IsDeleted = 1, DeletedAt = GETDATE() WHERE Id = ?;";
            $stmt = sqlsrv_prepare($conn, $sql, $ticket_id);
            $result = sqlsrv_execute($stmt);

            $call_draft_sql = "UPDATE Draft SET IsDeleted = 1, DeletedAt = GETDATE() WHERE TicketId = ?;";
            $call_draft_stmt = sqlsrv_prepare($conn, $call_draft_sql, $ticket_id);
            $call_draft_result = sqlsrv_execute($call_draft_stmt);

            $history_sql = "UPDATE History SET IsDeleted = 1, DeletedAt = GETDATE() WHERE TicketId = ?;";
            $history_stmt = sqlsrv_prepare($conn, $history_sql, $ticket_id);
            $history_result = sqlsrv_execute($history_stmt);

            $comment_sql = "UPDATE Comments SET IsDeleted = 1, DeletedAt = GETDATE() WHERE TicketId = ?;";
            $comment_stmt = sqlsrv_prepare($conn, $comment_sql, $ticket_id);
            $comment_result = sqlsrv_execute($comment_stmt);

            if ($result && $call_draft_result && $history_result && $comment_result) {
                echo json_encode(array('success' => true, 'message' => 'Ticket deleted successfully'));
            } else {
                echo json_encode(array('success' => false, 'message' => 'No rows deleted.'));
            }
        } catch (Exception $e) {
            echo json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
    } else {
        echo json_encode(array('success' => false, 'message' => 'ID parameter not set.'));
    }
} elseif ($_POST['type'] == 'subcategory') {
    if (isset($_POST['id'])) {
        //check subcategory mapped with ticket
        $sql_check = "SELECT Id FROM Tickets WHERE SubCategory =? AND IsDeleted = ?";
        $stmt_check = sqlsrv_prepare($conn, $sql_check, array(base64_decode($_POST['id']), 0));

        $row_check = array();
        if ($stmt_check) {
            $result_check = sqlsrv_execute($stmt_check);

            if ($result_check) {
                $row_check = sqlsrv_fetch_array($stmt_check, SQLSRV_FETCH_ASSOC);
            }
        }

        if ($row_check) {
            echo json_encode(array('success' => false, 'message' => 'Sub Category is mapped with Ticket.'));
        } else {
            $sql = "UPDATE SubCategory SET IsDeleted = 1, DeletedAt = GETDATE() WHERE Id = ?;";
            try {
                $stmt = sqlsrv_prepare($conn, $sql, array(base64_decode($_POST['id'])));

                if (sqlsrv_execute($stmt)) {
                    echo json_encode(array('success' => true, 'message' => 'Record has been deleted.'));
                } else {
                    echo json_encode(array('success' => false, 'message' => 'No rows deleted.'));
                }
            } catch (Exception $e) {
                echo json_encode(array('success' => false, 'message' => $e->getMessage()));
            };
        }
    } else {

        echo json_encode(array('success' => false, 'message' => 'ID parameter not set.'));
    }
} elseif ($_POST['type'] == 'source') {
    if (isset($_POST['id'])) {
        //check source map with ticket and license
        $sql_license = "SELECT Id FROM License WHERE TenantID =? AND IsDeleted = ?";
        $stmt_license = sqlsrv_prepare($conn, $sql_license, array(base64_decode($_POST['id']), 0));
        $row_license = array();
        if ($stmt_license) {
            $result_license = sqlsrv_execute($stmt_license);
            if ($result_license) {
                $row_license = sqlsrv_fetch_array($stmt_license, SQLSRV_FETCH_ASSOC);
            }
        }

        //check source mapped with ticket
        $sql_check = "SELECT Id FROM Tickets WHERE Source =? AND IsDeleted = ?";
        $stmt_check = sqlsrv_prepare($conn, $sql_check, array(base64_decode($_POST['id']), 0));

        $row_ticket = array();
        if ($stmt_check) {
            $result_check = sqlsrv_execute($stmt_check);

            if ($result_check) {
                $row_ticket = sqlsrv_fetch_array($stmt_check, SQLSRV_FETCH_ASSOC);
            }
        }

        if (!empty($row_ticket) || !empty($row_license)) {
            echo json_encode(array('success' => false, 'message' => 'Source is mapped with Ticket or License.'));
        } else {
            $sql = "UPDATE Source SET IsDeleted = 1, DeletedAt = GETDATE() WHERE Id = ?;";

            try {
                $stmt = sqlsrv_prepare($conn, $sql, array(base64_decode($_POST['id'])));

                if (sqlsrv_execute($stmt)) {
                    echo json_encode(array('success' => true, 'message' => 'Record has been deleted.'));
                } else {
                    echo json_encode(array('success' => false, 'message' => 'No rows deleted.'));
                }
            } catch (Exception $e) {
                echo json_encode(array('success' => false, 'message' => $e->getMessage()));
            };
        }
    } else {

        echo json_encode(array('success' => false, 'message' => 'ID parameter not set.'));
    }
} elseif ($_POST['type'] == 'ticket_license') {
    if (isset($_POST['id'])) {
        //check license mapped with ticket
        $sql_check = "SELECT t.Id FROM Tickets t JOIN License l ON t.Source = l.TenantId WHERE l.Id = ? AND t.IsDeleted = ?";
        $stmt_check = sqlsrv_prepare($conn, $sql_check, array(base64_decode($_POST['id']), 0));

        $row_ticket = array();
        if ($stmt_check) {
            $result_check = sqlsrv_execute($stmt_check);

            if ($result_check) {
                $row_ticket = sqlsrv_fetch_array($stmt_check, SQLSRV_FETCH_ASSOC);
            }
        }

        if (!empty($row_ticket) || !empty($row_license)) {
            echo json_encode(array('success' => false, 'message' => 'License is mapped with Ticket.'));
        } else {
            $sql = "UPDATE License SET IsDeleted = 1, DeletedAt = GETDATE() WHERE Id = ?;";
            try {
                $stmt = sqlsrv_prepare($conn, $sql, array(base64_decode($_POST['id'])));
                if (sqlsrv_execute($stmt)) {
                    echo json_encode(array('success' => true, 'message' => 'Record has been deleted.'));
                } else {
                    echo json_encode(array('success' => false, 'message' => 'No rows deleted.'));
                }
            } catch (Exception $e) {
                echo json_encode(array('success' => false, 'message' => $e->getMessage()));
            };
        }
    } else {
        echo json_encode(array('success' => false, 'message' => 'ID parameter not set.'));
    }
} elseif ($_POST['type'] == 'permission') {
    if (isset($_POST['id'])) {
        //check permission mapped with ticket
        $sql_check = "SELECT Id FROM Permissions WHERE Permission =? AND IsDeleted = ?";
        $stmt_check = sqlsrv_prepare($conn, $sql_check, array(base64_decode($_POST['id']), 0));

        $row_check = array();
        if ($stmt_check) {
            $result_check = sqlsrv_execute($stmt_check);

            if ($result_check) {
                $row_check = sqlsrv_fetch_array($stmt_check, SQLSRV_FETCH_ASSOC);
            }
        }

        if ($row_check) {
            echo json_encode(array('success' => false, 'message' => 'Permission is mapped with role.'));
        } else {
            $sql = "UPDATE Permissions SET IsDeleted = 1, DeletedAt = GETDATE() WHERE id = ?;";
            try {
                $stmt = sqlsrv_prepare($conn, $sql, array(base64_decode($_POST['id'])));
                $result = sqlsrv_execute($stmt);

                if ($result) {
                    echo json_encode(array('success' => true, 'message' => 'Record has been deleted.'));
                } else {
                    echo json_encode(array('success' => false, 'message' => 'No rows deleted.'));
                }
            } catch (Exception $e) {
                echo json_encode(array('success' => false, 'message' => $e->getMessage()));
            }
        }
    } else {
        echo json_encode(array('success' => false, 'message' => 'ID parameter not set.'));
    }
} elseif ($_POST['type'] == 'role') {
    if (isset($_POST['id'])) {
        //check user mapped with role
        $sql_check = "SELECT Id FROM Users WHERE Role =? AND IsDeleted = ?";
        $stmt_check = sqlsrv_prepare($conn, $sql_check, array(base64_decode($_POST['id']), 0));

        $row_check = array();
        if ($stmt_check) {
            $result_check = sqlsrv_execute($stmt_check);

            if ($result_check) {
                $row_check = sqlsrv_fetch_array($stmt_check, SQLSRV_FETCH_ASSOC);
            }
        }

        if ($row_check) {
            echo json_encode(array('success' => false, 'message' => 'Role is mapped with user.'));
        } else {
            $sql = "UPDATE Roles SET IsDeleted = 1, DeletedAt = GETDATE() WHERE id = ?;";
            try {
                $stmt = sqlsrv_prepare($conn, $sql, array(base64_decode($_POST['id'])));
                $result = sqlsrv_execute($stmt);

                if ($result) {
                    //delete permission assigned to role
                    $sql_del = "DELETE FROM RolePermissions WHERE Role = ?;";

                    $stmt_del = sqlsrv_prepare($conn, $sql_del, array(base64_decode($_POST['id'])));
                    $result_del = sqlsrv_execute($stmt_del);

                    if ($result_del) {
                        echo json_encode(array('success' => true, 'message' => 'Record has been deleted.'));
                    } else {
                        echo json_encode(array('success' => false, 'message' => 'No rows deleted.'));
                    }
                } else {
                    echo json_encode(array('success' => false, 'message' => 'No rows deleted.'));
                }
            } catch (Exception $e) {
                echo json_encode(array('success' => false, 'message' => $e->getMessage()));
            }
        }
    } else {
        echo json_encode(array('success' => false, 'message' => 'ID parameter not set.'));
    }
} elseif ($_POST['type'] == 'user') {
    if (isset($_POST['id'])) {
        $sql = "UPDATE Users SET IsDeleted = 1, DeletedAt = GETDATE() WHERE id = ?;";
        try {
            $stmt = sqlsrv_prepare($conn, $sql, array(base64_decode($_POST['id'])));
            $result = sqlsrv_execute($stmt);

            if ($result) {
                echo json_encode(array('success' => true, 'message' => 'Record has been deleted.'));
            } else {
                echo json_encode(array('success' => false, 'message' => 'No rows deleted.'));
            }
        } catch (Exception $e) {
            echo json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
    } else {
        echo json_encode(array('success' => false, 'message' => 'ID parameter not set.'));
    }
}

