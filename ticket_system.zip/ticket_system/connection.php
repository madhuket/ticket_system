<?php
$serverName = "";
$connectionOptions = array(
    "Database" => "",
    "Uid" => "",
    "PWD" => ""
);

$conn = sqlsrv_connect($serverName, $connectionOptions);


if ($conn === false) {
    // Get detailed errors
    $errors = sqlsrv_errors();
    if ($errors !== null) {
        foreach ($errors as $error) {
            echo "SQLSTATE: " . $error['SQLSTATE'] . "<br />";
            echo "Code: " . $error['code'] . "<br />";
            echo "Message: " . $error['message'] . "<br />";
        }
    } else {
        echo "Unknown error occurred during connection.";
    }
    die(); // Stop execution
}
