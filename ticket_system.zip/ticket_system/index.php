<?php
include "header.php";

$total_tickets = $total_open_tickets = $average_age_open_ticket = $longest_open_ticket = 0;
$table_row = '';

if (isset($_SESSION['tenant_id'])) {
    //get the count of total tickets
    $sql_count = "SELECT COUNT(Id) AS TotalTickets FROM Tickets WHERE Source = ? AND (DATEDIFF(WEEK, CreatedAt, GETDATE()) = 0) AND (IsDeleted = 0 OR IsDeleted IS NULL)";
    $params = array($_SESSION['tenant_id']);
    $stmt_count = sqlsrv_prepare($conn, $sql_count, $params);
    if (sqlsrv_execute($stmt_count)) {
        $row = sqlsrv_fetch_array($stmt_count, SQLSRV_FETCH_ASSOC);
        $total_tickets = $row['TotalTickets'];
    }

    //get count of open tickets 
    $sql_open_count = "SELECT COUNT(t.Id) AS TotalOpenTickets FROM Tickets t
        LEFT JOIN Status s ON s.Id = t.Status
        WHERE t.Source =? AND s.BaseStatus = ? AND (DATEDIFF(WEEK, t.CreatedAt, GETDATE()) = 0) AND (t.IsDeleted = 0 OR t.IsDeleted IS NULL)";

    $params = array($_SESSION['tenant_id'], 0);
    $stmt_open_count = sqlsrv_prepare($conn, $sql_open_count, $params);
    if (sqlsrv_execute($stmt_open_count)) {
        $row = sqlsrv_fetch_array($stmt_open_count, SQLSRV_FETCH_ASSOC);
        $total_open_tickets = $row['TotalOpenTickets'];
    }

    //get Average Age (in days) of open tickets
    $sql_average_age = "SELECT AVG(DATEDIFF(DAY, t.CreatedAt, GETDATE())) AS AverageAgeOpenTickets FROM Tickets t
        LEFT JOIN Status s ON s.Id = t.Status
        WHERE t.Source =? AND s.BaseStatus = ? AND (DATEDIFF(WEEK, t.CreatedAt, GETDATE()) = 0) AND (t.IsDeleted = 0 OR t.IsDeleted IS NULL)";

    $params = array($_SESSION['tenant_id'], 0);
    $stmt_average_age = sqlsrv_prepare($conn, $sql_average_age, $params);
    if (sqlsrv_execute($stmt_average_age)) {
        $row = sqlsrv_fetch_array($stmt_average_age, SQLSRV_FETCH_ASSOC);
        $average_age_open_ticket = $row['AverageAgeOpenTickets'];
    }

    //get Longest (in days) Open ticket 
    $sql_longest_open_ticket = "SELECT MAX(DATEDIFF(DAY, t.CreatedAt, GETDATE())) AS LongestOpenTicket FROM Tickets t
        LEFT JOIN Status s ON s.Id = t.Status
        WHERE t.Source =? AND s.BaseStatus =? AND (DATEDIFF(WEEK, t.CreatedAt, GETDATE()) = 0) AND (t.IsDeleted = 0 OR t.IsDeleted IS NULL)";

    $params = array($_SESSION['tenant_id'], 0);
    $stmt_longest_open_ticket = sqlsrv_prepare($conn, $sql_longest_open_ticket, $params);
    if (sqlsrv_execute($stmt_longest_open_ticket)) {
        $row = sqlsrv_fetch_array($stmt_longest_open_ticket, SQLSRV_FETCH_ASSOC);
        $longest_open_ticket = $row['LongestOpenTicket'];
    }

    $sql_latest_open_tickets = "SELECT TOP 10 t.Id AS TicketId,t.Title, t.CreatedAt, t.CreatedBy, t.ReportedBy, t.Category,
        ts.Id AS StatusId, 
        ts.Status AS Status,
        sr.Source,
        p.Priority,
        c.Department,
        c.Parent 
    FROM 
        Tickets t 
    LEFT JOIN 
        Status ts ON t.Status = ts.Id
    LEFT JOIN 
        Source sr ON t.Source = sr.Id    
    LEFT JOIN
        Priorities p ON p.Id = t.Priority
    LEFT JOIN 
        Ticketing_Categories c ON t.Category = c.ID      
    WHERE c.Active = ? AND t.Source = ? AND ts.BaseStatus = ? AND (DATEDIFF(WEEK, t.CreatedAt, GETDATE()) = 0) AND (t.IsDeleted = 0 OR t.IsDeleted IS NULL) ORDER BY t.Id DESC;";

    $params = array(1, $_SESSION['tenant_id'], 0);
    $stmt_latest_open_tickets = sqlsrv_prepare($conn, $sql_latest_open_tickets, $params);
    
    if (sqlsrv_execute($stmt_latest_open_tickets) && sqlsrv_has_rows($stmt_latest_open_tickets)) {
        while ($row = sqlsrv_fetch_array($stmt_latest_open_tickets, SQLSRV_FETCH_ASSOC)) {
            $row = stdToArray($row);

            $sts_class = $edit_class = '';
            if ($row['Status'] == 'Closed') {
                $sts_class = 'bg-secondary';
                $edit_class = 'd-none';
            } else 
                if ($row['Status'] == 'Open') {
                $sts_class = 'bg-success';
            } else {
                $sts_class = 'bg-secondary';
            }

            //show title upto 30 characters
            $title_str = '';
            if (strlen($row['Title']) > 30) {
                $title_str = substr($row['Title'], 0, 15) . '..';
                $title = '<span data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="' . $row['Title'] . '">' . $title_str . '</span>';
            } else {
                $title = $row['Title'];
            }

            $reported_by_str = '';
            if (strlen($row['ReportedBy']) > 30) {
                $reported_by_str = substr($row['ReportedBy'], 0, 15) . '..';
                $ReportedBy = '<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . $row['ReportedBy'] . '">' . $reported_by_str . '</span>';
            } else {
                $ReportedBy = $row['ReportedBy'];
            }

            $priority_class = '';
            if ($row['Priority'] == 'High') { 
                $priority_class = 'bg-soft-danger text-danger';
            } else 
                if ($row['Priority'] == 'Medium') {
                $priority_class = 'bg-soft-warning text-warning';
            } else 
                if ($row['Priority'] == 'Low') {
                $priority_class = 'bg-soft-secondary text-secondary';
            } else {
                $priority_class = 'bg-soft-secondary text-secondary';
            }

            $TicketStatus = '<span class="badge ' . $sts_class . ' text-light">' . $row['Status'] . '</span>';
            $TicketPriority = '<span class="badge ' . $priority_class . '">' . $row['Priority'] . '</span>';

            $table_row .= '<tr class="cursor-pointer tkt_tbl_row" data-ticketid="' . base64_encode($row['TicketId']) . '" title="Ticket Details"> 
            <td>' . $title . '</td>
            <td>' . $TicketStatus . '</td>
            <td>'. $TicketPriority . '</td>
            <td>'. $row['Source']. '</td>
            <td>'. $ReportedBy. '</td>
            <td>'. $row['Department']. '</td>
            <td>'. $row['Parent']. '</td>
            </tr>';
        }
    }
} else {
    $sql_count = "SELECT COUNT(Id) AS TotalTickets FROM Tickets WHERE (IsDeleted = 0 OR IsDeleted IS NULL)";
    $stmt_count = sqlsrv_prepare($conn, $sql_count);
    if (sqlsrv_execute($stmt_count)) {
        $row = sqlsrv_fetch_array($stmt_count, SQLSRV_FETCH_ASSOC);
        $total_tickets = $row['TotalTickets'];
    }

    //get count of open tickets 
    $sql_open_count = "SELECT COUNT(Id) AS TotalOpenTickets FROM Tickets t
        LEFT JOIN Status s ON s.Id = t.Status
        WHERE s.BaseStatus = ? AND (t.IsDeleted = 0 OR t.IsDeleted IS NULL)";
    $params = array(0);
    $stmt_open_count = sqlsrv_prepare($conn, $sql_open_count, $params);
    if (sqlsrv_execute($stmt_open_count)) {
        $row = sqlsrv_fetch_array($stmt_open_count, SQLSRV_FETCH_ASSOC);
        $total_open_tickets = $row['TotalOpenTickets'];
    }

    //get Average Age (in days) of open tickets
    $sql_average_age = "SELECT AVG(DATEDIFF(DAY, t.CreatedAt, GETDATE())) AS AverageAgeOpenTickets FROM Tickets t
        LEFT JOIN Status s ON s.Id = t.Status
        WHERE s.BaseStatus = ? AND (t.IsDeleted = 0 OR t.IsDeleted IS NULL)";

    $params = array(0);
    $stmt_average_age = sqlsrv_prepare($conn, $sql_average_age, $params);
    if (sqlsrv_execute($stmt_average_age)) {
        $row = sqlsrv_fetch_array($stmt_average_age, SQLSRV_FETCH_ASSOC);
        $average_age_open_ticket = $row['AverageAgeOpenTickets'];
    }

    $sql_longest_open_ticket = "SELECT MAX(DATEDIFF(DAY, t.CreatedAt, GETDATE())) AS LongestOpenTicket FROM Tickets t
        LEFT JOIN Status s ON s.Id = t.Status
        WHERE s.BaseStatus =? AND (t.IsDeleted = 0 OR t.IsDeleted IS NULL)";

    $params = array(0);
    $stmt_longest_open_ticket = sqlsrv_prepare($conn, $sql_longest_open_ticket, $params);
    if (sqlsrv_execute($stmt_longest_open_ticket)) {
        $row = sqlsrv_fetch_array($stmt_longest_open_ticket, SQLSRV_FETCH_ASSOC);
        $longest_open_ticket = $row['LongestOpenTicket'];
    }
}
?>

<body>
    <?php include "sider.php" ?>

    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
        
            <div class="row">
                <div class="col-3">
                    <div class="mb-3">
                        <label class="form-label" for="week-picker">Select Week</label>
                        <input type="text" id="week-picker" class="form-control" placeholder="Select Week">
                    </div>
                </div>

                <div class="col-3">
                    <div class="mb-3">
                        <label class="form-label" for="month-picker">Select Month</label>
                        <input type="text" id="month-picker" class="form-control" placeholder="Select Month">
                    </div>
                </div>

                <div class="col-3">
                    <div class="mb-3">
                        <label class="form-label">Select Year</label>
                        <select class="form-control" data-toggle="select2" id="year-dropdown" data-placeholder="Select Year">
                            <option value="">Select Year</option>
                        </select>
                    </div>
                </div>

                <div class="col-3">
                    <div class="mb-3">  
                        <label class="form-label" for="range-datepicker">Range Calendar</label>
                        <input type="text" id="range-datepicker" class="form-control" placeholder="Select Date">
                    </div>
                </div>
            </div>
        
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right me-4">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>">Ticket Management</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/view_ticket.php">Tickets</a></li>
                                <li class="breadcrumb-item active">Dashboard</li>
                            </ol>
                        </div>
                        <h4 class="page-title ps-5">Dashboard</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-md-6 col-xl-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <div class="avatar-sm bg-primary rounded">
                                        <i class="mdi mdi-ticket avatar-title font-22 text-white"></i>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="text-end">
                                        <h3 class="text-dark my-1"><span data-plugin="counterup" class="total_tickets_cnt_spn"><?php echo $total_tickets; ?></span></h3>
                                        <a href="<?php echo $base_url; ?>/view_ticket.php">
                                            <p class="text-muted mb-1 text-truncate">Total Tickets</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- end card-->
                </div> <!-- end col -->

                <div class="col-md-6 col-xl-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <div class="avatar-sm bg-info rounded">
                                        <i class="mdi mdi-ticket avatar-title font-22 text-white"></i>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="text-end">
                                        <h3 class="text-dark my-1"><span data-plugin="counterup" class="open_tickets_cnt_spn"><?php echo $total_open_tickets; ?></span></h3>
                                        <a href="<?php echo $base_url; ?>/view_ticket.php">
                                            <p class="text-muted mb-1 text-truncate">Open Tickets</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div> <!-- end card-->
                </div> <!-- end col -->

                <div class="col-md-6 col-xl-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <div class="avatar-sm bg-warning rounded">
                                        <i class="mdi mdi-timeline-check avatar-title font-22 text-white"></i>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="text-end">
                                        <h3 class="text-dark my-1"><span data-plugin="counterup" class="avg_age_tickets_cnt_spn"><?php echo $average_age_open_ticket; ?></span></h3>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo $base_url; ?>/view_ticket.php">
                                <p class="text-muted mb-1 text-end">Average Age (days) of open tickets</p>
                            </a>
                        </div>
                    </div> <!-- end card-->
                </div> <!-- end col -->

                <div class="col-md-6 col-xl-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <div class="avatar-sm bg-primary rounded">
                                        <i class="mdi mdi-timeline-check avatar-title font-22 text-white"></i>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="text-end">
                                        <h3 class="text-dark my-1"><span data-plugin="counterup" class="longest_age_tickets_cnt_spn"><?php echo $longest_open_ticket; ?></span></h3>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo $base_url; ?>/view_ticket.php">
                                <p class="text-muted mb-1 text-end">Longest (in days) Open ticket</p>
                            </a>
                        </div>
                    </div> <!-- end card-->
                </div> <!-- end col -->


            </div>
            <!-- end row -->

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title mb-3">Latest 10 open tickets</h4>

                            <div class="table-responsive">
                                <table class="table table-borderless table-hover table-nowrap table-centered m-0">

                                    <thead class="table-light">
                                        <tr>
                                            <th>Title</th>
                                            <th>Status</th>
                                            <th>Priority</th>
                                            <th>Source</th>
                                            <th>Reported By</th>
                                            <th>Department</th>
                                            <th>Parent</th>
                                        </tr>
                                    </thead>
                                    <tbody id="table_row">

                                        <?php echo $table_row; ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div> <!-- end col -->

            </div>
            <!-- end row -->


        </div>

        <?php include "footer.php" ?>

        <script>
            $(document).ready(function() {
                $("#range-datepicker").flatpickr({
                    mode:"range",
                    onChange: function(selectedDates, dateStr, instance) {
                        if (selectedDates.length === 2) {  // Check if two dates are selected
                            var startDate = selectedDates[0];  // First date (start date)
                            var endDate = selectedDates[1];    // Second date (end date)
                            
                            $('#week-picker').val('');
                            $('#month-picker').val('');
                            $('#year-dropdown').val('').trigger('change');

                            $.ajax({
                                url: "fetch/fetch_last_ten_open_tickets.php",
                                type: "POST",
                                datatype: "json",
                                data: {
                                    startDate: startDate.toISOString(),
                                    endDate: endDate.toISOString()
                                },
                                success: function (response) {
                                    // table_row
                                    if(response.table_row != null) {
                                        $("#table_row").html(response.table_row);
                                    }
                                },
                                error: function (xhr, status, error) {
                                    alert("Error occurred while fetching data");
                                    console.error(xhr, status, error);
                                },
                            });

                            $.ajax({
                                url: "fetch/fetch_count_total_tickets.php",
                                type: "POST",
                                datatype: "json",
                                data: {
                                    startDate: startDate.toISOString(),
                                    endDate: endDate.toISOString()
                                },
                                success: function (response) {
                                    if(response.success) {
                                        $(".total_tickets_cnt_spn").text(response.total_ticket_count);
                                        $(".open_tickets_cnt_spn").text(response.total_open_tickets);
                                        $(".avg_age_tickets_cnt_spn").text(response.average_age_open_ticket);
                                        $(".longest_age_tickets_cnt_spn").text(response.longest_open_ticket);
                                    }
                                },
                                error: function (xhr, status, error) {
                                    alert("Error occurred while fetching data");
                                    console.error(xhr, status, error);
                                },
                            });
                        }
                    }
                });

                const today = new Date();

                $("#week-picker").flatpickr({
                    weekNumbers: true, // show week numbers in the calendar
                    dateFormat: "Y-m-d",  // set output format as Year-Month-Day
                    mode: "range",  // range mode for picking start and end of the week
                    defaultDate: [new Date(today.setDate(today.getDate() - today.getDay())), new Date(today.setDate(today.getDate() - today.getDay() + 6))], // set default date to first and last day of the week
                    onChange: function(selectedDates, dateStr, instance) {
                        if (selectedDates.length === 2) {
                            // Custom logic to round to start and end of the week
                            let start = selectedDates[0];
                            let end = selectedDates[1];
                            start.setDate(start.getDate() - start.getDay() + 1); // start of the week (Monday)
                            end.setDate(end.getDate() - end.getDay() + 7); // end of the week (Sunday)
                            instance.setDate([start, end]);

                            $('#month-picker').val('');
                            $('#year-dropdown').val('').trigger('change');
                            $('#range-datepicker').val('');

                            $.ajax({
                                url: "fetch/fetch_last_ten_open_tickets.php",
                                type: "POST",
                                datatype: "json",
                                data: {
                                    startDate: selectedDates[0].toISOString(),
                                    endDate: selectedDates[1].toISOString()
                                },
                                success: function (response) {
                                    // table_row
                                    if(response.table_row != null) {
                                        $("#table_row").html(response.table_row);
                                    }
                                },
                                error: function (xhr, status, error) {
                                    alert("Error occurred while fetching data");
                                    console.error(xhr, status, error);
                                },
                            });

                            $.ajax({
                                url: "fetch/fetch_count_total_tickets.php",
                                type: "POST",
                                datatype: "json",
                                data: {
                                    startDate: selectedDates[0].toISOString(),
                                    endDate: selectedDates[1].toISOString()
                                },
                                success: function (response) {
                                    if(response.success) {
                                        $(".total_tickets_cnt_spn").text(response.total_ticket_count);
                                        $(".open_tickets_cnt_spn").text(response.total_open_tickets);
                                        $(".avg_age_tickets_cnt_spn").text(response.average_age_open_ticket);
                                        $(".longest_age_tickets_cnt_spn").text(response.longest_open_ticket);
                                    }
                                },
                                error: function (xhr, status, error) {
                                    alert("Error occurred while fetching data");
                                    console.error(xhr, status, error);
                                },
                            });
                        }
                    }
                });

                $("#month-picker").flatpickr({
                    plugins: [
                        new monthSelectPlugin({
                            shorthand: true, // display months in shorthand format (e.g., "Jan", "Feb")
                            dateFormat: "Y-M", // set output format as Year-Month
                            altFormat: "F Y",  // set alternative display format (e.g., "January 2024")
                            theme: "light" // custom theme for the plugin
                        })
                    ],
                    onChange: function(selectedDates, dateStr, instance) {
                        if (selectedDates.length === 1) {  // Ensure that one month is selected
                            var selectedMonth = selectedDates[0];  // Get the selected month

                            // Get the start and end dates of the selected month
                            var { startDate, endDate } = getMonthStartAndEndDates(selectedMonth);

                            $('#week-picker').val('');
                            $('#year-dropdown').val('').trigger('change');
                            $('#range-datepicker').val('');

                            $.ajax({
                                url: "fetch/fetch_last_ten_open_tickets.php",
                                type: "POST",
                                datatype: "json",
                                data: {
                                    startDate: startDate.toISOString(),
                                    endDate: endDate.toISOString()
                                },
                                success: function (response) {
                                    // table_row
                                    if(response.table_row != null) {
                                        $("#table_row").html(response.table_row);
                                    }
                                },
                                error: function (xhr, status, error) {
                                    alert("Error occurred while fetching data");
                                    console.error(xhr, status, error);
                                },
                            });

                            $.ajax({
                                url: "fetch/fetch_count_total_tickets.php",
                                type: "POST",
                                datatype: "json",
                                data: {
                                    startDate: startDate.toISOString(),
                                    endDate: endDate.toISOString()
                                },
                                success: function (response) {
                                    if(response.success) {
                                        $(".total_tickets_cnt_spn").text(response.total_ticket_count);
                                        $(".open_tickets_cnt_spn").text(response.total_open_tickets);
                                        $(".avg_age_tickets_cnt_spn").text(response.average_age_open_ticket);
                                        $(".longest_age_tickets_cnt_spn").text(response.longest_open_ticket);
                                    }
                                },
                                error: function (xhr, status, error) {
                                    alert("Error occurred while fetching data");
                                    console.error(xhr, status, error);
                                },
                            });
                        }
                    }
                });

                // Function to calculate the start and end date of a given month
                function getMonthStartAndEndDates(selectedMonth) {
                    const year = selectedMonth.getFullYear();          // Get the year
                    const month = selectedMonth.getMonth();            // Get the month (0-based)

                    // Start date: 1st of the selected month
                    const startDate = new Date(year, month, 2);
                    // End date: Last day of the selected month
                    const endDate = new Date(year, month + 1, 1);      // Month+1 and day 0 gives last day of the current month

                    return { startDate, endDate };
                }

                // Show ticket details on click
                $(document).on("click", ".tkt_tbl_row", function () {
                    validNavigation = true; 
                    var TicketId = $(this).data("ticketid");
                    sessionStorage.setItem('TicketId', TicketId);
                    window.location.href = "<?php echo $base_url;?>/view_ticket.php";
                });

                $(document).on("change", "#year-dropdown", function () {
                    var selectedYear = $(this).val();

                    if (selectedYear != '') {
                        var startDate = new Date(selectedYear, 0, 1, 0, 0, 0, 0);
                        var endDate = new Date(selectedYear, 11, 31, 23, 59, 59, 999);

                        $.ajax({
                            url: "fetch/fetch_last_ten_open_tickets.php",
                            type: "POST",
                            datatype: "json",
                            data: {
                                startDate: startDate.toISOString(),
                                endDate: endDate.toISOString()
                            },
                            success: function (response) {
                                $('#week-picker').val('');
                                $('#month-picker').val('');
                                $('#range-datepicker').val('');
                                
                                // table_row
                                if(response.table_row != null) {
                                    $("#table_row").html(response.table_row);
                                }
                            },
                            error: function (xhr, status, error) {
                                alert("Error occurred while fetching data");
                                console.error(xhr, status, error);
                            },
                        });

                        $.ajax({
                            url: "fetch/fetch_count_total_tickets.php",
                            type: "POST",
                            datatype: "json",
                            data: {
                                startDate: startDate.toISOString(),
                                endDate: endDate.toISOString()
                            },
                            success: function (response) {
                                if(response.success) {
                                    $(".total_tickets_cnt_spn").text(response.total_ticket_count);
                                    $(".open_tickets_cnt_spn").text(response.total_open_tickets);
                                    $(".avg_age_tickets_cnt_spn").text(response.average_age_open_ticket);
                                    $(".longest_age_tickets_cnt_spn").text(response.longest_open_ticket);
                                }
                            },
                            error: function (xhr, status, error) {
                                alert("Error occurred while fetching data");
                                console.error(xhr, status, error);
                            },
                        });
                    }
                });

                // Function to populate the year dropdown using jQuery
                function populateYearDropdown(startYear, endYear) {
                    var $yearDropdown = $('#year-dropdown');

                    // Loop through the years and add them as options
                    for (var year = startYear; year >= endYear; year--) {
                        $yearDropdown.append($('<option>', {
                            value: year,
                            text: year
                        }));
                    }
                }

                // Get the current year
                var currentYear = new Date().getFullYear();

                // Populate the dropdown with years from 1900 to the current year
                populateYearDropdown(currentYear, 1900);
            });
        </script>
</body>

</html>