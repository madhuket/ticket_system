<?php

$sql = "SELECT TOP 1 Id, Status FROM Status WHERE Status = ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";
$params = array('Open');

$result = sqlsrv_query($conn, $sql, $params);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$data = array();
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
    $data[] = [
        'Id' => $row['Id'],
        'Status' => $row['Status'],
    ];
}

sqlsrv_free_stmt($result);

foreach ($data as $row) {
    $ticketStatus = $row['Status'];
    $statusId = base64_encode($row['Id']);
    $output =  htmlspecialchars($ticketStatus, ENT_QUOTES, 'UTF-8');
    echo "<option value='$statusId'>" . $output . "</option>";
}
