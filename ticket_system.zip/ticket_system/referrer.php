<a href="validate_license.php?license_key=098f6bcd4621d373cade4e832627b4f6">Validate License</a>
