<?php
include "header.php";
?>

<body>
    <?php include "sider.php"; ?>

    <div class="content" id="ticket_list">
        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right me-4">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>">Ticket Management</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/view_ticket.php">Tickets</a></li>
                                <li class="breadcrumb-item active">View Ticket</li>
                            </ol>
                        </div>
                        <h4 class="page-title ps-5">View Ticket</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <!-- end row -->
            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive custom-table-responsive">
                                <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tickets-table">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Title</th>
                                            <th>Status</th>
                                            <th>Priority</th>
                                            <th>Source</th>
                                            <th>Reported By</th>
                                            <th>Department</th>
                                            <th>Parent</th>
                                            <th class="hidden-sm">Action</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div><!-- end col -->
            </div>
            <!-- end row -->

        </div> <!-- container -->

    </div>

    <?php include "ticket_details.php"; ?>

    <?php include "edit_ticket.php"; ?>

    <?php include "ticket_history.php"; ?>

    <script src="assets/js/pages/ticket_list.js"></script>

    <?php include "footer.php" ?>

    
</body>

</html>