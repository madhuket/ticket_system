<?php
include "connection.php";

// $query = "ALTER TABLE License ADD CssContent VARCHAR(MAX) DEFAULT '' NOT NULL;";

// if (sqlsrv_query($conn, $query)) { 
//     echo "Query executed successfully.<br>";
// } else {
//     echo "Error: <pre>" . print_r(sqlsrv_errors(), true) . "<br>";
// }





// $query = "ALTER TABLE License DROP CONSTRAINT DF_License_FolderName;";
// if (sqlsrv_query($conn, $query)) { 
//     echo "Query executed successfully.<br>";
// } else {
//     echo "Error: <pre>" . print_r(sqlsrv_errors(), true) . "<br>";
// }


// $query = "ALTER TABLE License DROP COLUMN FolderName;";
// if (sqlsrv_query($conn, $query)) { 
//     echo "Query executed successfully.<br>";
// } else {
//     echo "Error: <pre>" . print_r(sqlsrv_errors(), true) . "<br>";
// }
