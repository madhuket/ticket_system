<!DOCTYPE html>
<html>
<head>
    <title>Ticket Information</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        h2 {
            color: #333;
        }
    </style>
</head>
<body>
    <h2>Ticket Details</h2>
    <table>
        <tr>
            <th>Title</th>
            <td>{{ticket_title}}</td>
        </tr>
        <tr>
            <th>Reported By</th>
            <td>{{reported_by}}</td>
        </tr>
        <tr>
            <th>Status</th>
            <td>{{select_status}}</td>
        </tr>
        <tr>
            <th>Priority</th>
            <td>{{priority}}</td>
        </tr>
        <tr>
            <th>Department</th>
            <td>{{department}}</td>
        </tr>
        <tr>
            <th>Parent</th>
            <td>{{parent}}</td>
        </tr>
        <tr {{#child}}>
            <th>Child</th>
            <td>{{child}}</td>
        </tr>
        <tr {{#sub_child_1}}>
            <th>Sub Child 1</th>
            <td>{{sub_child_1}}</td>
        </tr>
        <tr {{#sub_child_2}}>
            <th>Sub Child 2</th>
            <td>{{sub_child_2}}</td>
        </tr>
        <tr {{#sub_child_3}}>
            <th>Sub Child 3</th>
            <td>{{sub_child_3}}</td>
        </tr>
        <tr {{#sub_child_4}}>
            <th>Sub Child 4</th>
            <td>{{sub_child_4}}</td>
        </tr>
        <tr>
            <th>Source</th>
            <td>{{select_source}}</td>
        </tr>
        <tr>
            <th>Follow Up At</th>
            <td>{{follow_up_at}}</td>
        </tr>
        <tr>
            <th>Next Follow Up Date</th>
            <td>{{next_follow_up_date}}</td>
        </tr>
        <tr>
            <th>Case Details</th>
            <td>{{case_details}}</td>
        </tr>
        <tr>
            <th>Immediate Action Taken</th>
            <td>{{immediate_action_taken}}</td>
        </tr>
    </table>
    <p>Thank you for your attention to this matter.</p>
</body>
</html>
