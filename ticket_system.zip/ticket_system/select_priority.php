<?php
$sql = "SELECT Id,Priority FROM Priorities WHERE (IsDeleted = 0 OR IsDeleted IS NULL) ORDER BY Id DESC";
$result = sqlsrv_query($conn, $sql);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$data = array();
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {

    $data[] = [
        'Id' => $row['Id'],
        'Priority' => $row['Priority']
    ];
}

sqlsrv_free_stmt($result);

foreach ($data as $row) {
    $TicketPriority =htmlspecialchars_decode($row['Priority']);
    $PriorityId = base64_encode($row['Id']);
    $output =  htmlspecialchars($TicketPriority, ENT_QUOTES, 'UTF-8');
    echo "<option value='$PriorityId'>" . $output . "</option>";
}
