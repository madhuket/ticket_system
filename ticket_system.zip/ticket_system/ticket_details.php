<style>
    .comment_scroll {
        height: 280px;
        overflow-y: scroll;
    }
</style>

<div class="content d-none" id="ticket_detail">
    <!-- Start Content-->
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right me-4">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Ticket Management</a></li>
                            <li class="breadcrumb-item"><a href="view_ticket.php">Tickets</a></li>
                            <li class="breadcrumb-item active">Ticket Details</li>
                        </ol>
                    </div>
                    <h4 class="page-title ps-5">Ticket Details</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-xl-8 col-lg-7 ps-0">
                <!-- project card -->
                <div class="card d-block">
                    <div class="card-body">

                        <div class="d-flex justify-content-end mb-2 mb-sm-0">
                            <div class="row g-1">
                                <div class="col-auto">
                                    <a href="view_ticket.php" class="btn btn-sm btn-link"><i class="mdi mdi-keyboard-backspace"></i> Back</a>
                                </div>
                                <div class="col-auto">
                                    <a href="javascript:void(0);" class="btn btn-sm btn-link text-muted edit_tkt edit_tkt_lnk" data-ticketid="" id="back_ticket_list"><i class="mdi mdi-pencil"></i> Edit Ticket</a>
                                </div>
                            </div>
                        </div> <!-- end dropdown-->

                        <div class="clerfix"></div>

                        <div class="row">
                            <div class="col-md-6">
                                <!-- Ticket type -->
                                <label class="mt-2 mb-1">Source :</label>
                                <p id="tenant_source">
                                    <i class="mdi mdi-ticket font-18 text-success me-1 align-middle"></i>
                                </p>
                                <!-- end Ticket Type -->

                                <!-- Ticket type -->
                                <label class="mt-2 mb-1">Title :</label>
                                <p id="title">
                                    <i class="mdi mdi-ticket font-18 text-success me-1 align-middle"></i>
                                </p>
                                <!-- end Ticket Type -->

                                <label class="mt-2 mb-1">Priority :</label>
                                <div class="d-flex align-items-start">
                                    <i class="mdi mdi-filter-variant font-18 text-success me-1 align-middle"></i>
                                    <div class="w-100">
                                        <p id="priority"></p>
                                    </div>
                                </div>

                                <label class="mt-2 mb-1">Department :</label>
                                <div class="d-flex align-items-start">
                                    <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                                    <div class="w-100">
                                        <p id="ticket_department"></p>
                                    </div>
                                </div>

                                <label class="mt-2 mb-1">Parent :</label>
                                <div class="d-flex align-items-start">
                                    <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                                    <div class="w-100">
                                        <p id="ticket_parent"></p>
                                    </div>
                                </div>

                                <div class="de_child_div">
                                    <label class="mt-2 mb-1">Child :</label>
                                    <div class="d-flex align-items-start">
                                        <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                                        <div class="w-100">
                                            <p id="ticket_child"></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="de_sub_child_1_div">
                                    <label class="mt-2 mb-1">Sub Child 1 :</label>
                                    <div class="d-flex align-items-start">
                                        <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                                        <div class="w-100">
                                            <p id="ticket_sub_child_1"></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="de_sub_child_2_div">
                                    <label class="mt-2 mb-1">Sub Child 2 :</label>
                                    <div class="d-flex align-items-start">
                                        <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                                        <div class="w-100">
                                            <p id="ticket_sub_child_2"></p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="de_sub_child_3_div">
                                    <label class="mt-2 mb-1">Sub Child 3 :</label>
                                    <div class="d-flex align-items-start">
                                        <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                                        <div class="w-100">
                                            <p id="ticket_sub_child_3"></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="de_sub_child_4_div">
                                    <label class="mt-2 mb-1">Sub Child 4 :</label>
                                    <div class="d-flex align-items-start">
                                        <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                                        <div class="w-100">
                                            <p id="ticket_sub_child_4"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <!-- Reported by -->
                                <label class="mt-2 mb-1">Source URL :</label>
                                <p id="tenant_source_url">
                                    <!-- <i class="mdi mdi-ticket font-18 text-success me-1 align-middle"></i> -->
                                </p>
                                <!-- end Reported by -->

                                <!-- Reported by -->
                                <!-- <label class="mt-2 mb-1">Source :</label>
                                <div class="d-flex align-items-start">
                                    <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                                    <div class="w-100">
                                        <p id="source"></p>
                                    </div>
                                </div> -->
                                <!-- end Reported by -->

                                <label class="mt-2 mb-1">Reported By :</label>
                                <div class="d-flex align-items-start">
                                    <i class="mdi mdi-account font-18 text-success me-1 align-middle"></i>
                                    <div class="w-100">
                                        <p id="reported_by"></p>
                                    </div>
                                </div>
                                
                                <label class="mt-2 mb-1">Status :</label>
                                <div class="d-flex align-items-start">
                                    <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                                    <div class="w-100">
                                        <p id="ticket_status"></p>
                                    </div>
                                </div>

                                <label class="mt-2 mb-1">Follow Up At :</label>
                                <div class="d-flex align-items-start">
                                    <i class="mdi mdi-email font-18 text-success me-1 align-middle"></i>
                                    <div class="w-100">
                                        <p id="follow_up_at"></p>
                                    </div>
                                </div>

                                <label class="mt-2 mb-1">Next Follow Up Date :</label>
                                <div class="d-flex align-items-start">
                                    <i class="mdi mdi-calendar-range font-18 text-success me-1 align-middle"></i>
                                    <div class="w-100">
                                        <p id="next_follow_up_date"></p>
                                    </div>
                                </div>

                                <label class="mt-4 mb-1">Case Details :</label>

                                <p class="text-muted mb-0" id="case_details"></p>

                                <label class="mt-4 mb-1">Immediate Action Taken :</label>

                                <p class="text-muted mb-0" id="immediate_action_taken"></p>
                            </div> <!-- end col -->
                        </div> <!-- end row -->



                        <div class="row">
                            <div class="col-md-6">
                                <!-- assignee -->
                                <label class="mt-2 mb-1">Created On :</label>
                                <p id="created_at"></p>
                                <!-- end assignee -->
                            </div> <!-- end col -->

                            <div class="col-md-6">
                                <!-- assignee -->
                                <label class="mt-2 mb-1">Updated On :</label>
                                <p id="modified_at"></p>
                                <!-- end assignee -->
                            </div> <!-- end col -->
                        </div> <!-- end row -->
                    </div> <!-- end card-body-->
                </div> <!-- end card-->

                <div class="card">
                    <div class="card-body">
                        <div class="float-end">
                            <select class="form-select form-select-sm comment_sort">
                                <option value="1" selected="">Recent</option>
                                <option value="0">Old</option>
                            </select>
                        </div> <!-- end dropdown-->

                        <h4 class="mb-4 mt-0 font-16 comment_count" id="">Comment</h4>

                        <div class="clerfix"></div>

                        <div class="comment_area"> </div>

                        <div class="text-center mt-2"></div>

                        <div class="border rounded mt-4">
                            <form class="comment-area-box" id="comment-form">
                                <input type="hidden" id="cmt_csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                                <textarea rows="3" class="form-control border-0 resize-none" placeholder="Your comment..." id="comment" name="comment" required></textarea>
                                <div class="p-2 bg-light d-flex justify-content-between align-items-center">
                                    <input type="hidden" id="ticket_id" name="ticket_id" value="">

                                    <button type="submit" class="btn btn-sm btn-primary add-comment"><i class="mdi mdi-send me-1"></i>Submit</button>
                                </div>
                            </form>
                        </div> <!-- end .border-->

                    </div> <!-- end card-body-->
                </div>
                <!-- end card-->
            </div> <!-- end col -->

            <div class="col-xl-4 col-lg-5 px-0">

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title font-16 mb-3">Attachments</h5>

                        <div class="ticket_file_list"></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->

    </div> <!-- container -->

</div>