<?php
$sql = "SELECT Id, Role FROM Roles WHERE (IsDeleted = 0 OR IsDeleted IS NULL) ORDER BY Role";
$result = sqlsrv_query($conn, $sql);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

// $data = array();
$option_html = '';
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {

    $option_html .= "<option value='" . base64_encode($row['Id']) . "'>" . htmlspecialchars($row['Role'], ENT_QUOTES, 'UTF-8') . "</option>";

    // $data[] = [
    //     'id' => $row['Id'],
    //     'source' => $row['Source'],
    //     'source_details' => $row['SourceDetails'],
    // ];
}

sqlsrv_free_stmt($result);

echo $option_html;

// foreach ($data as $row) {
//     $ticketSource = htmlspecialchars_decode($row['source']);
//     $sourceid = base64_encode($row['id']);
//     $output =  htmlspecialchars($ticketSource, ENT_QUOTES, 'UTF-8');
//     echo "<option value='$sourceid'>" . $output . "</option>";
// }
