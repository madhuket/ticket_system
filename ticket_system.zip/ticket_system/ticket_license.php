<?php
include "header.php";

function generateLicenseKey($length = 16) {
    // Define a character set
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $charactersLength = strlen($characters);
    $licenseKey = '';

    // Generate a random string
    for ($i = 0; $i < $length; $i++) {
        $licenseKey .= $characters[rand(0, $charactersLength - 1)];
    }

    // Optionally, format the license key with hyphens
    return implode('-', str_split($licenseKey, 4));
}

// Generate the license key
$licenseKey = generateLicenseKey(16);
?>

<style>
    .file-drop-area {
        position: relative;
        display: flex;
        align-items: center;
        /* width: 450px; */
        width: 100%;
        padding: 15px;
        border: 1px dashed rgba(0, 0, 0, 0.4);
        border-radius: 3px;
        transition: 0.2s;
    }

    .choose-file-button {
        flex-shrink: 0;
        background-color: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 3px;
        padding: 8px 15px;
        margin-right: 10px;
        font-size: 12px;
        text-transform: uppercase;
    }

    .file-message {
        font-size: small;
        font-weight: 300;
        line-height: 1.4;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .file-input {
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
        width: 100%;
        cursor: pointer;
        opacity: 0;
    }
</style>

<body>
    <?php include "sider.php"; ?>

    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right me-4">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>">Ticket Management</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/view_ticket.php">Tickets</a></li>
                                <li class="breadcrumb-item active">Ticket License</li>
                            </ol>
                        </div>
                        <h4 class="page-title ps-5">Ticket License</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->


            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" id="TicketLicense" enctype="multipart/form-data">
                                <input type='hidden' name="type" value="ticket_license">
                                <input type='hidden' name="id" id="id" value="">
                                <input type="hidden" name="csrf_token" id="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="tenant_id" class="form-label">Tenant Name<span class="req_star"> *</span></label>
                                            <select class="form-select" id="tenant_id" name="tenant_id" required>
                                                <option value="" selected>Select Source</option>
                                                <?php include 'select_source.php'; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="tenant_url" class="form-label">Tenant URL<span class="req_star"> *</span></label>
                                            <input type="text" id="tenant_url" class="form-control" name="tenant_url" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="issue_date" class="form-label">Issue Date<span class="req_star"> *</span></label>
                                            <input type="text" id="issue_date" class="form-control" name="issue_date" data-provide="datepicker" placeholder="Select issue date" required>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="expiry_date" class="form-label">Expiry Date<span class="req_star"> *</span></label>
                                            <input type="text" id="expiry_date" class="form-control" name="expiry_date" data-provide="datepicker" placeholder="Select expiry date" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="license_key" class="form-label">License Key<span class="req_star"> *</span></label>
                                            <input type="text" id="license_key" class="form-control" name="license_key" value="<?php echo $licenseKey; ?>" required readonly>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="mb-3 mb-md-0 mt-0 mt-md-4">
                                            <div class="form-check form-switch">
                                                <input type="checkbox" class="form-check-input" id="is_active" name="is_active" value="1" checked>
                                                <label class="form-check-label" for="is_active">Is Active</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label class="col-sm-2 form-label">Upload CSS</label>
                                            <div class="file-drop-area">
                                                <span class="choose-file-button">Choose files</span>
                                                <span class="file-message">or drag and drop file here</span>
                                                <input class="file-input" name="source_css" type="file">
                                            </div>
                                            <label id="source_css-error" class="text-danger d-none"></label>
                                        </div>
                                    </div>      
                                </div>
                                
                                <div class="mb-3">
                                    <div class="text-center d-flex justify-content-center">
                                        <div class="mt-3">
                                            <button type="submit" class="btn btn-primary" id="submit_form">Submit</button>
                                        </div>

                                        <div class="mt-3 ms-2">
                                            <button type="reset" class="btn btn-danger" id="reset_form">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">

                            <div class="table-responsive">
                                <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="ticket_license-table">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Tenant Name</th>
                                            <th>License Key</th>
                                            <th>Issue Date</th>
                                            <th>Expiry Date</th>
                                            <th>Is Active</th>
                                            <th class="hidden-sm">Action</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div><!-- end col -->
            </div>
            <!-- end row -->
        </div> <!-- container -->
    </div>

    <script>
        $(document).ready(function() {
            $("#reset_form").on("click", function () {
                $('#id').val('');

                $("#TicketLicense").find("label.error").remove();
                $("#TicketLicense").find(".error").removeClass("error");
                $(".file-drop-area").find(".file-message").text("or drag and drop files here");
            });

            $("#issue_date, #expiry_date").datepicker({
                autoclose: true, // Automatically close the datepicker after date selection
                todayHighlight: true, // Highlight today's date
            }).on("changeDate", function (e) {
                var issueDate = $('#issue_date').datepicker('getDate');
                var expiryDate = $('#expiry_date').datepicker('getDate');

                if (issueDate && expiryDate) {
                    if (issueDate > expiryDate) {
                        // alert("Issue date must be before the expiry date.");
                        $('#issue_date').datepicker('update', ''); // Clear the issue date
                    }
                }
            });

            $('#TicketLicense').submit(function(e) {
                e.preventDefault();

                // Select the file input element
                var fileInput = $(".file-input")[0];

                // Check if a file has been selected
                if (fileInput.files.length > 0) {
                    var file = fileInput.files[0];
                    var error_cnt = 0;

                    // Check if the file size exceeds 5 MB (5242880 bytes)
                    if (file.size > 5242880) {
                        error_cnt++;
                        $("#source_css-error").removeClass("d-none");
                        $("#source_css-error").text("File too large. File must be less than 5 MB.");
                    } else {
                        $("#source_css-error").addClass("d-none");
                    }

                    // Check if the file type is allowed
                    var allowedExtensions = /\.(css)$/i;
                    if (!allowedExtensions.exec(file.name)) {
                        error_cnt++;
                        $("#source_css-error").removeClass("d-none");
                        $("#source_css-error").text("Only CSS file allowed.");
                    } else if (error_cnt === 0) {
                        $("#source_css-error").addClass("d-none");
                    }

                    // Prevent form submission if there are errors
                    if (error_cnt > 0) {
                        return false;
                    }
                }

                var isvalidForm = $(this).valid();
                if (isvalidForm) {
                    //disable button
                    $('#submit_form').attr('disabled', true);

                    var formData = new FormData(this);
                    $.ajax({
                        type: 'POST',
                        url: 'store_data.php',
                        data: formData,
                        contentType: false,
                        processData: false,
                        cache: false,
                        dataType: 'json',
                        success: function(response) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            if (response.success) {
                                Swal.fire({
                                    title: "Good job!",
                                    text: response.message,
                                    icon: "success"
                                });
                                $("#csrf_token").val(response.csrf_token);   
                                $('#id').val('');
                                $('#tenant_id').val('');
                                $('#tenant_url').val('');
                                $('#license_key').val('');
                                $('#issue_date').val('');
                                $('#expiry_date').val('');
                                $('.file-input').val('');
                                $('.file-message').text('or drag and drop file here');
                                $("#ticket_license-table").DataTable().ajax.reload();
                            } else {
                                Swal.fire({
                                    title: "Can't insert data",
                                    text: response.message,
                                    icon: "warning"
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            console.error("Error saving status:", error);
                        },
                    });
                }
            });

            $("#ticket_license-table").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                },
                ajax: {
                    url: "fetch/fetch_license.php"
                }
            });

            $(document).on("click", ".edit_license", function() {
                var license_id = $(this).data('licenseid');
                $.ajax({
                    type: 'POST',
                    url: 'fetch/fetch_license_particular.php',
                    data: {
                        'license_id': license_id
                    },
                    dataType: 'json',
                    success: function(response) {
                        $('.file-input').val('');
                        $('.file-message').text('or drag and drop file here');
                        $("#source_css-error").addClass("d-none");
                        $("#TicketLicense").find("label.error").remove();
                        $("#TicketLicense").find(".error").removeClass("error");

                        scrollToTop();
                        $('#tenant_id').val(response.TenantID);
                        $('#tenant_url').val(response.TenantURL);
                        $('#license_key').val(response.LicenseKey);
                        $('#issue_date').val(response.IssueDate).datepicker('update', response.IssueDate);
                        $('#expiry_date').val(response.ExpiryDate).datepicker('update', response.ExpiryDate);
                        response.IsActive == 1 ? $('#is_active').prop('checked', true): $('#is_active').prop('checked', false);
                        $('#id').val(response.Id);
                        $('#csrf_token').val(response.CsrfToken);
                    }
                });
            });

            $(document).on("click", ".remove_license", function() {
                var license_id = $(this).data('licenseid');

                if(license_id !== '' && license_id !== null && license_id !== undefined) {
                    Swal.fire({
                        title: "Are you sure?",
                        text: "You won't be able to revert this!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#3085d6",
                        cancelButtonColor: "#d33",
                        confirmButtonText: "Yes, delete it!"
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: 'delete_row.php',
                                type: 'POST',
                                data: {
                                    type: "ticket_license",
                                    id: license_id
                                },
                                dataType: "json",
                                success: function(response) {
                                    if (response.success) {
                                        $('#tenant_id').val('');
                                        $('#tenant_url').val('');
                                        $('#issue_date').val('');
                                        $('#expiry_date').val('');
                                        $("#ticket_license-table").DataTable().ajax.reload();
                                        Swal.fire({
                                            title: "Deleted!",
                                            text: response.message,
                                            icon: "success"
                                        });
                                    } else {
                                        Swal.fire({
                                            title: "Error!",
                                            text: response.message,
                                            icon: "warning"
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    alert("Error occurred while deleting row");
                                    console.error(xhr, status, error);
                                }
                            });
                        }
                    });
                } else {
                    Swal.fire({
                        title: "Error!",
                        text: "Ticket Id is required",
                        icon: "warning",
                    });
                }
            });

            $("#TicketLicense").validate({
                rules: {
                    tenant_url: {
                        required: true,
                        url: true
                    }
                }
            });

            $(document).on("change", "#tenant_id", function() {
                var tenant_id = $(this).val();
                if(tenant_id != ''){
                    $.ajax({
                        type: 'POST',
                        url: 'fetch/fetch_license_key.php',
                        data: {
                            'tenant_id': tenant_id
                        },
                        dataType: 'json',
                        success: function(response) {
                            if(response.LicenseKey != ''){
                                $('#license_key').val(response.LicenseKey);
                            }
                        }
                    });
                }
                
            });

            // File upload start
            $(document).on("change", ".file-input", function () {
                var filesCount = $(this)[0].files.length;
                var textbox = $(this).prev();

                if (filesCount === 1) {
                var fileName = $(this).val().split("\\").pop();
                textbox.text(fileName);
                } else {
                textbox.text(filesCount + " files selected");
                }
            });
            // File upload end
        });
    </script>

    <?php include "footer.php" ?>

</body>

</html>