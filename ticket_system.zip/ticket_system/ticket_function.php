<?php
function send_ticket_mail($from, $to, $subject, $message, $attachments_path)
{
    $boundary = md5(uniqid(time()));

    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "From: $from\r\n";
    // $headers .= "Reply-To: $from\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";

    // Message Body
    $body = "--$boundary\r\n";
    $body .= "Content-Type: text/html; charset=iso-8859-1\r\n";
    $body .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
    $body .= $message . "\r\n\r\n";

    foreach ($attachments_path as $file_path) {
        if (file_exists($file_path)) {
            $file_name = basename($file_path);
            $file_size = filesize($file_path);
            $handle = fopen($file_path, "r");
            $content = fread($handle, $file_size);
            fclose($handle);
            $content = chunk_split(base64_encode($content));

            // Detect the MIME type
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime_type = finfo_file($finfo, $file_path);
            finfo_close($finfo);

            $body .= "--$boundary\r\n";
            $body .= "Content-Type: $mime_type; name=\"$file_name\"\r\n";
            $body .= "Content-Transfer-Encoding: base64\r\n";
            $body .= "Content-Disposition: attachment; filename=\"$file_name\"\r\n\r\n";
            $body .= $content . "\r\n\r\n";
        }
    }
    $body .= "--$boundary--";

    return mail($to, $subject, $body, $headers);
}

/**
 * Recursively converts an object to an array
 * @param object $obj object to convert
 * @return array the converted array
 */
function stdToArray($obj)
{
    $reaged = (array)$obj;
    foreach ($reaged as $key => &$field) {
        if (is_object($field)) $field = stdToArray($field);
    }
    return $reaged;
}
