<?php
    session_start();

    unset($_SESSION['tenant_name']);
    unset($_SESSION['tenant_url']);
    unset($_SESSION['user_login']);
    unset($_SESSION['userid']);
    unset($_SESSION['roleid']);
    unset($_SESSION['user_permissions']);
    unset($_SESSION['tenant_id']);
    unset($_SESSION['license_id']);
    unset($_SESSION['tenant_logout']);
    
    header("Location: admin_login.php");
    exit();
?>