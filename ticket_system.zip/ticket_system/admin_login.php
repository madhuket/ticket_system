<?php
include "connection.php";

header("Content-Security-Policy: base-uri https://core.isointerface.com/");
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('X-Content-Type-Options: nosniff');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
header('Permissions-Policy: fullscreen=(self "https://core.isointerface.com/"), geolocation=*, camera=()');
header('Referrer-Policy: origin-when-cross-origin');

session_start();

// Set the base URL for the application
$_SERVER['REQUEST_URI_PATH'] = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$segments = explode('/', $_SERVER['REQUEST_URI_PATH']);
$base_url = implode('/', array_slice($segments, 0, -1));

if (isset($_SESSION['user_login']) && $_SESSION['user_login'] === true) {
    // Redirect to the index page
    header("Location: index.php");
    exit();
}

function validate($value)
{
    if (isset($value) && $value !== "") {
        if (preg_match("/\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|OR)\b/i", $value)) {
            return false;
        } else if (preg_match("/\b(alert|prompt|confirm|script)\b/i", $value)) {
            return false;
        } else {
            return $value;
        }
    } else {
        return false;
    }
}


// Generate a unique CSRF token if one doesn't exist
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Generate a random token
}

//login with username or email and password
$login_error = false;
$csrf_token_error = false;
$username = true;
if (isset($_POST['btn_login'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $csrf_token_error = true;
    } else if($csrf_token_error === false) {
        $username = validate(htmlspecialchars($_POST['username']));
        // $password = md5($_POST['password']);
        $password = $_POST['password'];

        if($username){
            $query = "SELECT u.*, r.IsSuperAdmin FROM Users u JOIN Roles r ON u.Role = r.Id WHERE (u.Username = ? OR u.Email = ?) AND u.Password = ? AND u.IsActive = ?";
            $params = array($username, $username, $password, 1);
            $result = sqlsrv_query($conn, $query, $params);

            if ($result === false) {
                die(print_r(sqlsrv_errors(), true));  // Debugging SQL errors
            }

            if ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
                unset($_SESSION['tenant_url']);
                // $_SESSION['admin_login'] = true;
                $_SESSION['user_login'] = true;
                $_SESSION['userid'] = $row['Id'];
                $_SESSION['roleid'] = $row['Role'];
                $_SESSION['tenant_id'] = $row['Source'];
                $_SESSION['tenant_logout'] = false;
                $_SESSION['is_superadmin'] = $row['IsSuperAdmin'] == 1 ? true : false;
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                header('Location: index.php');
            } else {
                $login_error = true;
                unset($_SESSION['user_login']);
                unset($_SESSION['userid']);
                unset($_SESSION['roleid']);
                unset($_SESSION['tenant_id']);
                unset($_SESSION['tenant_logout']);
                unset($_SESSION['is_superadmin']);
                // session_unset();
                // session_destroy();
            }

            //get source name and source url from license table
            if(isset($_SESSION['tenant_id']) && $_SESSION['tenant_id'] != '' && $login_error === false){
                $query = "SELECT Id, TenantName, TenantURL FROM License WHERE TenantId =? AND (IsDeleted = 0 OR IsDeleted = NULL)";
                $params = array($_SESSION['tenant_id']);
                $result = sqlsrv_query($conn, $query, $params);
                if ($result && sqlsrv_has_rows($result)) {
                    $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
                    $_SESSION['tenant_name'] = $row['TenantName'];
                    $_SESSION['tenant_url'] =$row['TenantURL'];
                    $_SESSION['license_id'] =$row['Id'];
                }
            }
        }  
    }
}  
?>

<!DOCTYPE html>
<html lang="en" data-layout-mode="detached" data-topbar-color="dark" data-sidenav-user="true">

<head>
    <meta charset="utf-8" />
    <title>Ticket Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Ticket Management" name="description" />
    <meta content="TicketManagement" name="author" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo $base_url ?>/assets/images/customer-support.png">

    <!-- jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Theme Config Js -->
    <script src="<?php echo $base_url ?>/assets/js/head.js"></script>

    <!-- Bootstrap css -->
    <link href="<?php echo $base_url ?>/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="app-style" />

    <!-- App css -->
    <link href="<?php echo $base_url ?>/assets/css/app.min.css" rel="stylesheet" type="text/css" />

    <!-- Icons css -->
    <link href="<?php echo $base_url ?>/assets/css/icons.min.css" rel="stylesheet" type="text/css" />

    <style>
        .error {
            color: #f1556c;
        }
        .footer_link{
            color: #0d6efd;
        }
        button.btn.btn-primary{
            background-color: #0d6efd;
            border: #0d6efd;
        }
        button.btn.btn-primary:hover {
            background-color: #0d6efd;
        }
    </style>
</head>

<!-- <body class="authentication-bg authentication-bg-pattern"> -->
<body class="">

    <div class="account-pages mt-5 mb-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-4">
                    <div class="card bg-pattern">

                        <div class="card-body p-4">

                            <div class="text-center w-75 m-auto">
                                <div class="auth-brand">
                                    <h4>Admin Login</h4>
                                </div>
                            </div>

                            <form method="post" id="AdminLogin">
                                

                                <?php
                                    if($login_error){
                                        ?>
                                        <div class="alert alert-danger" role="alert">
                                            Invalid Username or Password. Please try again.
                                        </div>
                                        <?php
                                    } else if($csrf_token_error){
                                        ?>
                                        <div class="alert alert-danger" role="alert">
                                            CSRF token validation failed. Please try again.
                                        </div>
                                        <?php
                                    } else if(!$username){
                                        ?>
                                        <div class="alert alert-danger" role="alert">
                                            Please enter valid input
                                        </div>
                                        <?php
                                    }
                                ?>

                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>" />

                                <div class="mb-3">
                                    <label for="username" class="form-label">Username / Email address</label>
                                    <input class="form-control" type="text" id="username" name="username" required="" placeholder="Enter your username or email">
                                </div>

                                <div class="mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <div class="input-group input-group-merge">
                                        <input type="password" id="password" class="form-control" name="password" placeholder="Enter your password" required="">
                                        <div class="input-group-text" data-password="false">
                                            <span class="password-eye"></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="text-center d-grid">
                                    <button class="btn btn-primary" type="submit" name="btn_login"> Log In </button>
                                </div>

                            </form>
                        </div> <!-- end card-body -->
                    </div>
                    <!-- end card -->

                </div> <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end page -->

    <footer class="footer footer-alt">
        <?php echo date("Y"); ?> © Ticket Management System - <a href="https://www.electronicpayments.com/" target="_blank" class="footer_link">ISOInterface</a>
    </footer>

    <!-- Authentication js -->
    <script src="<?php echo $base_url ?>/assets/js/authentication.init.js"></script>

    <!-- For jQuery Validator -->
    <script src="<?php echo $base_url ?>/assets/js/jquery.validate.min.js"></script>
    <script src="<?php echo $base_url ?>/assets/js/additional-methods.min.js"></script>

    <script>
        $(document).ready(function() {
            setTimeout(function() {   
            $('.alert').fadeOut('slow', function() {
                    $(this).remove();
                });
            }, 5000);

            $("#AdminLogin").validate({
                errorPlacement: function(error, element) {
                    if (element.attr("name") == "password") {
                        error.insertAfter(element.closest('.input-group'));
                    } else {
                        error.insertAfter(element);
                    }
                }
            });
        });
    </script>
</body>

</html>