<?php
include "header.php";
?>

<body>
    <?php include "sider.php"; ?>

    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right me-4">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>">Ticket Management</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/view_ticket.php">Tickets</a></li>
                                <li class="breadcrumb-item active">Ticket Source</li>
                            </ol>
                        </div>
                        <h4 class="page-title ps-5">Ticket Source</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->


            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" id="TicketSource">
                                <input type='hidden' id="type" name="type" value="source">
                                <input type="hidden" id="id" name="id" value="">
                                <input type="hidden" name="csrf_token" id="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label for="source" class="form-label">Source<span style="color: red;"> *</span></label>
                                            <input type="text" id="source" class="form-control" name="source" required>
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label for="source_details" class="form-label">Source Detail</label>
                                            <textarea class="form-control" id="source_details" name="source_details" rows="5"></textarea>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="text-center d-flex justify-content-center">
                                        <div class="mt-3">
                                            <button type="submit" class="btn btn-primary" id="submit_form">Submit</button>
                                        </div>

                                        <div class="mt-3 ms-2">
                                            <button type="reset" class="btn btn-danger" id="reset_form">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">

                            <div class="table-responsive">
                                <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="ticket_source">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Source</th>
                                            <th>Source Details</th>
                                            <th class="hidden-sm">Action</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div><!-- end col -->
            </div>
            <!-- end row -->
        </div> <!-- container -->
    </div>

    <script>
        $(document).ready(function() {
            $("#reset_form").on("click", function () {
                $('#id').val('');

                $("#TicketSource").find("label.error").remove();
                $("#TicketSource").find(".error").removeClass("error");
            });

            $("#ticket_source").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                },
                ajax: {
                    url: "fetch/fetch_source.php"
                }
            });

            $('#TicketSource').submit(function(e) {
                e.preventDefault();

                var isvalidForm = $(this).valid();
                if (isvalidForm) {
                    //disable button
                    $('#submit_form').attr('disabled', true);

                    var formData = $(this).serialize();
                    $.ajax({
                        type: 'POST',
                        url: 'store_data.php',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            if (response.success) {
                                $("#ticket_source").DataTable().ajax.reload();
                                Swal.fire({
                                    title: "Good job!",
                                    text: response.message,
                                    icon: "success"
                                });
                                $('#csrf_token').val(response.csrf_token);
                                $('#source').val('');
                                $('#source_details').val('');
                            } else {
                                Swal.fire({
                                    title: "Can't insert data",
                                    text: response.message,
                                    icon: "warning"
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            console.error("Error saving status:", error);
                        },
                    });
                }
            });

            $(document).on("click", ".edit_source", function() {
                var source_id = $(this).data('sourceid');

                $.ajax({
                    type: 'POST',
                    url: 'fetch/fetch_source_particular.php',
                    data: {
                        'source_id': source_id
                    },
                    dataType: 'json',
                    success: function(response) {
                        $("#TicketSource").find("label.error").remove();
                        $("#TicketSource").find(".error").removeClass("error");

                        scrollToTop();
                        $('#source').val(response.Source);
                        $('#source_details').val(response.SourceDetails);
                        $('#id').val(response.Id);
                        $('#csrf_token').val(response.CsrfToken);
                    }
                });
            });

            $(document).on("click", ".remove_source", function() {
                var source_id = $(this).data('sourceid');

                if(source_id !== '' && source_id !== null && source_id !== undefined) {
                    Swal.fire({
                        title: "Are you sure?",
                        text: "You won't be able to revert this!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#3085d6",
                        cancelButtonColor: "#d33",
                        confirmButtonText: "Yes, delete it!"
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: 'delete_row.php',
                                type: 'POST',
                                data: {
                                    type: "source",
                                    id: source_id
                                },
                                dataType: "json",
                                success: function(response) {
                                    if (response.success) {
                                        $('#source').val('');
                                        $('#source_details').val('');
                                        $('#id').val('');
                                        $("#ticket_source").DataTable().ajax.reload();
                                        Swal.fire({
                                            title: "Deleted!",
                                            text: response.message,
                                            icon: "success"
                                        });
                                    } else {
                                        Swal.fire({
                                            title: "Error!",
                                            text: response.message,
                                            icon: "warning"
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    alert("Error occurred while deleting row");
                                    console.error(xhr, status, error);
                                }
                            });
                        }
                    });
                } else {
                    Swal.fire({
                        title: "Error!",
                        text: "Source Id is required",
                        icon: "warning",
                    });
                }
            });

            $("#TicketSource").validate({
                rules: {
                    source: {
                        noSpecialChars: true,
                        maxlength: 50          // Max length rule
                    },
                    source_details: {
                        maxlength: 255          // Max length rule
                    }
                }
            });

            // Custom validation method to check for special characters
            $.validator.addMethod("noSpecialChars", function(value, element) {
                return this.optional(element) || /^[^!@#$%^&*()]+$/.test(value);
            }, "Special characters (!@#$%^&*()) are not allowed.");
            
        });
    </script>

    <?php include "footer.php" ?>
</body>
</html>