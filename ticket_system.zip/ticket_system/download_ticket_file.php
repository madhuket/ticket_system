<?php
    include "config.php";

    if (isset($_GET['file'])) {
        $fileName = basename($_GET['file']);  // Sanitize the file name to prevent directory traversal
        $filePath = $uploadTicketDir . DIRECTORY_SEPARATOR . $fileName;
    
        // Check if the file exists in the attachments folder
        if (file_exists($filePath)) {
            // Set headers to force download
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $fileName . '"');
            header('Content-Length: ' . filesize($filePath));
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Expires: 0');
    
            // Output the file content
            readfile($filePath);
            exit;
        }
         else {
            // File doesn't exist
            echo "File not found.";
        }
    } else {
        // No file specified
        echo "No file specified.";
    }
?>