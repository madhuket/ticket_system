<?php
include "header.php";
?>

<body>
    <?php include "sider.php"; ?>

    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right me-4">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>">Ticket Management</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/view_ticket.php">Tickets</a></li>
                                <li class="breadcrumb-item active">Ticket Priority</li>
                            </ol>
                        </div>
                        <h4 class="page-title ps-5">Ticket Priority</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" id="TicketPriorityForm">
                                <input type='hidden' id="type" name="type" value="priority">
                                <input type="hidden" id="id" name="id" value="">
                                <input type="hidden" name="csrf_token" id="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label for="Priority" class="form-label">Priority<span style="color: red;"> *</span></label>
                                            <input type="text" id="Priority" class="form-control" name="Priority" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="text-center d-flex justify-content-center">
                                        <div class="mt-3">
                                            <button type="submit" class="btn btn-primary" id="submit_form">Submit</button>
                                        </div>

                                        <div class="mt-3 ms-2">
                                            <button type="reset" class="btn btn-danger" id="reset_form">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="ticket_priority">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Priority</th>
                                            <th class="hidden-sm">Action</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div><!-- end col -->
            </div>
            <!-- end row -->
        </div> <!-- container -->
    </div>

    

    <script>
        $(document).ready(function() {
            $("#reset_form").on("click", function () {
                $('#id').val('');

                $("#TicketPriorityForm").find("label.error").remove();
                $("#TicketPriorityForm").find(".error").removeClass("error");
            });

            $("#ticket_priority").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                },
                ajax: {
                    url: "fetch/fetch_priority.php"
                }
            });

            $('#TicketPriorityForm').submit(function(e) {
                e.preventDefault();

                var isvalidForm = $(this).valid();
                if (isvalidForm) {
                    //disable button
                    $('#submit_form').attr('disabled', true);

                    var formData = $(this).serialize();
                    $.ajax({
                        type: 'POST',
                        url: 'store_data.php',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            if (response.success) {
                                $("#ticket_priority").DataTable().ajax.reload();
                                Swal.fire({
                                    title: "Priority added!",
                                    text: response.message,
                                    icon: "success"
                                });
                                $('#csrf_token').val(response.csrf_token);
                                $('#Priority').val('');
                                $('#id').val('');
                            } else {
                                Swal.fire({
                                    title: "Can't insert data",
                                    text: response.message,
                                    icon: "warning"
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            console.error("Error :", error);
                        },
                    });
                }


            });

            $(document).on("click", ".edit_priority", function() {
                var priority_id = $(this).data('priorityid');

                $.ajax({
                    type: 'POST',
                    url: 'fetch/fetch_priority_particular.php',
                    data: {
                        'priority_id': priority_id
                    },
                    dataType: 'json',
                    success: function(response) {
                        $("#TicketPriorityForm").find("label.error").remove();
                        $("#TicketPriorityForm").find(".error").removeClass("error");

                        scrollToTop();
                        $('#csrf_token').val(response.csrf_token);
                        $('#Priority').val(response.Priority);
                        $('#id').val(response.Id);
                    }
                });
            });

            $(document).on("click", ".remove_priority", function() {
                var priority_id = $(this).data('priorityid');

                if(priority_id !== '' && priority_id !== null && priority_id !== undefined) {
                    Swal.fire({
                        title: "Are you sure?",
                        text: "You won't be able to revert this!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#3085d6",
                        cancelButtonColor: "#d33",
                        confirmButtonText: "Yes, delete it!"
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: 'delete_row.php',
                                type: 'POST',
                                data: {
                                    type: "priority",
                                    id: priority_id
                                },
                                dataType: "json",
                                success: function(response) {
                                    if (response.success) {
                                        $('#Priority').val('');
                                        $('#id').val('');
                                        $("#ticket_priority").DataTable().ajax.reload();
                                        Swal.fire({
                                            title: "Deleted!",
                                            text: response.message,
                                            icon: "success"
                                        });
                                    } else {
                                        Swal.fire({
                                            title: "Error!",
                                            text: response.message,
                                            icon: "warning"
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    alert("Error occurred while deleting row");
                                    console.error(xhr, status, error);
                                }
                            });
                        }
                    });
                } else{
                    Swal.fire({
                        title: "Error!",
                        text: "Ticket Id is required",
                        icon: "warning",
                    });
                }
            });

            $("#TicketPriorityForm").validate({
                rules: {
                    Priority: {
                        noSpecialChars: true,
                        maxlength: 100          // Max length rule
                    }
                }
            });

            // Custom validation method to check for special characters
            $.validator.addMethod("noSpecialChars", function(value, element) {
                return this.optional(element) || /^[a-zA-Z0-9\s]+$/.test(value);
            }, "Please enter only letters, numbers, and spaces.");
        });
    </script>

<?php include "footer.php" ?>

</body>

</html>