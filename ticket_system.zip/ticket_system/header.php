<?php
//include the file
include_once("config.php");
?>

<!DOCTYPE html>
<html lang="en" data-layout-mode="detached" data-topbar-color="dark" data-sidenav-user="true">

<head>
  <meta charset="utf-8" />
  <title>Ticket Management</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta content="Ticket Management" name="description" />
  <meta content="TicketManagement" name="author" />

  <!-- App favicon -->
  <link rel="shortcut icon" href="<?php echo $base_url ?>/assets/images/customer-support.png">

  <!-- Theme Config Js -->
  <script src="<?php echo $base_url ?>/assets/js/head.js"></script>

  <!-- Bootstrap css -->
  <link href="<?php echo $base_url ?>/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="app-style" />

  <!-- Icons css -->
  <link href="<?php echo $base_url ?>/assets/css/icons.min.css" rel="stylesheet" type="text/css" />

  <!-- jQuery CDN -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <!-- For Toaster -->
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

  <!-- For Flatpicker -->
  <link href="<?php echo $base_url ?>/assets/css/flatpickr.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base_url ?>/assets/css/flatpickr-master/plugins/monthSelect/style.css" rel="stylesheet" type="text/css" />

  <!-- For Datepicker -->
  <link href="<?php echo $base_url ?>/assets/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />

  <!-- Plugins css -->
  <link href="<?php echo $base_url ?>/assets/css/selectize.bootstrap3.css" rel="stylesheet" type="text/css" />

  <!-- Datatable css -->
  <link href="<?php echo $base_url ?>/assets/css/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base_url ?>/assets/css/responsive.bootstrap5.min.css" rel="stylesheet" type="text/css" />

  <!-- Select2 CSS -->
  <link href="<?php echo $base_url ?>/assets/css/multi-select.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base_url ?>/assets/css/select2.min.css" rel="stylesheet" type="text/css" />
  
    <!-- App css -->
  <link href="<?php echo $base_url ?>/assets/css/app.min.css" rel="stylesheet" type="text/css" />

  <!-- Custom CSS -->
  <link href="<?php echo $base_url ?>/assets/css/custom.css" rel="stylesheet" type="text/css" />
  <!-- Source CSS -->
  <?php
    if($css_content !== ''){
      ?>
      <style><?php echo $css_content; ?></style>
      <?php
    } else {
      ?>
        <link href="<?php echo $base_url ?>/assets/css/isointerface/style.css" rel="stylesheet" type="text/css" />
      <?php
    }
  ?>

  <script>
    var ticketDir = "<?php echo $ticketDir ?>";
    var uploadTicketDir = "<?php echo $uploadTicketDir ?>";

    var validNavigation = false;
    function endSession() {
      $.ajax({
        url: 'destroy_session.php'
      });
    }

    function wireUpEvents() {
      window.onbeforeunload = function() {
        if (!validNavigation) {
          endSession();
        }
      }

      // Attach the event click for all links in the page
      $("a").bind("click", function() {
        validNavigation = true;
      });

      // Attach the event submit for all forms in the page
      $("form").bind("submit", function() {
        validNavigation = true;
      });
    }

    document.onkeydown = checkKeycode
    function checkKeycode(e) {
      var keycode;
      if (window.event)
        keycode = window.event.keyCode;
      else if (e)
        keycode = e.which;

      // Detect F5 key (keycode 116)
      if(keycode == 116) {
        validNavigation = true;
      }

      // Detect Ctrl+R key combination
      if (e.ctrlKey && keycode == 82) {
        validNavigation = true;
      }

      if(keycode == 91 && window.event.ctrlKey) {
       validNavigation = true;
      }
    }
      
    // Wire up the events as soon as the DOM tree is ready
    $(document).ready(function() {
      wireUpEvents();
    });
  </script>

</head>