<?php
$sql = "SELECT Id, Permission FROM Permissions WHERE (IsDeleted = 0 OR IsDeleted IS NULL)";
$result = sqlsrv_query($conn, $sql);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$checkbox_html = '';
$i = 1;
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
    $checkbox_html .= "<div class='form-check form-check-pink mb-1'>
        <input type='checkbox' name='permission[]' id='permission".$i."' value='" . base64_encode($row['Id']) . "' class='form-check-input perm-class' />
        <label for='permission".$i."'>" . htmlspecialchars($row['Permission'], ENT_QUOTES, 'UTF-8') . "</label>
    </div>";
    
    $i++;
}

sqlsrv_free_stmt($result);

echo $checkbox_html;
