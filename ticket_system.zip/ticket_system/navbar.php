<?php include "header.php"; ?>


<!-- <body> -->


<!-- Vendor js -->
<script src="assets/js/vendor.min.js"></script>

<!-- App js -->
<script src="assets/js/app.min.js"></script>

<!-- Plugins js-->

<script src="assets/js/apexcharts.min.js"></script>
<script src="assets/js/selectize.min.js"></script>

<!-- Dashboar 1 init js-->
<script src="assets/js/dashboard-1.init.js"></script>

<!-- </body>

</html> -->