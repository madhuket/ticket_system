<?php
session_start();

$license_error = $_COOKIE['isValidateUrl'] ?? '';
$cookieAuthToken = $_COOKIE['AuthToken'] ?? '';
$sessionAuthToken = $_SESSION['AuthToken'] ?? '';
$tenant_url = $_SESSION['tenant_url'] ?? '';
$tenant_id = isset($_SESSION['tenant_id']) ? base64_encode($_SESSION['tenant_id']) : '';

$validate_auth_token = false;
if($cookieAuthToken != '' && $sessionAuthToken != ''){
    if($cookieAuthToken == $sessionAuthToken){
        $validate_auth_token = true;
    }
}

//check is admin logged in
if (isset($_SESSION['user_login']) && $_SESSION['user_login'] === true) {
    $user_login = true;
} else {
    $user_login = false;
}

header('Content-Type: application/json');
if(($license_error != 1) || ($validate_auth_token != 1)) { 
    echo json_encode(array('isvalid_license' => false, 'user_login' => $user_login, 'tenant_url' => $tenant_url, 'tenant_id' => $tenant_id));
} else {
    echo json_encode(array('isvalid_license' => true, 'user_login' => $user_login, 'tenant_url' => $tenant_url, 'tenant_id' => $tenant_id));
}
