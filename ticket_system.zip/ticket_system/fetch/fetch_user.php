<?php
include "../config.php";

$sql = "SELECT u.Id, u.Username, u.Email, u.IsActive, s.Source, r.Role
        FROM Users u 
        LEFT JOIN Source s ON u.Source = s.Id
        LEFT JOIN Roles r ON u.Role = r.Id
        WHERE u.IsDeleted = 0 OR u.IsDeleted IS NULL ORDER BY u.Id DESC;";
$result = sqlsrv_query($conn, $sql);
if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$dataArray = array();
$i = 1;
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
    $action = '<div class="btn-group dropdown">
        <a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-bs-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-dots-horizontal"></i></a>
        <div class="dropdown-menu dropdown-menu-end">
        <a class="dropdown-item edit_user" href="javascript:void(0)" data-userid="' . base64_encode($row['Id']) . '"><i class="mdi mdi-pencil me-2 text-muted font-18 vertical-middle"></i>Edit User</a>
        <a class="dropdown-item remove_user" href="javascript:void(0)" data-userid="' . base64_encode($row['Id']) . '"><i class="mdi mdi-delete me-2 text-muted font-18 vertical-middle"></i>Remove User</a> 
        </div>
    </div>';

    $IsActive = $row['IsActive'] == 1 ? 'Active' : 'InActive';

    $dataArray[] = array($i, $row['Username'], $row['Email'], $row['Role'], $row['Source'], $IsActive, $action);
    $i++;
}

sqlsrv_free_stmt($result);

$tbldata = array(
    "draw" => '',
    "recordsTotal" => '',
    "recordsFiltered" => '',
    "data" => $dataArray
);

header('Content-Type: application/json');
echo json_encode($tbldata);
