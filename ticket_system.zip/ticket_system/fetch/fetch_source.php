<?php

include "../config.php";

$sql = "SELECT Id,Source,SourceDetails FROM Source WHERE IsDeleted = 0 OR IsDeleted IS NULL ORDER BY Id DESC;";
$result = sqlsrv_query($conn, $sql);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$dataArray = array();
$i = 1;
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
    $action = '<div class="btn-group dropdown">
    <a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-bs-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-dots-horizontal"></i></a>
    <div class="dropdown-menu dropdown-menu-end">
      <a class="dropdown-item edit_source" href="javascript:void(0)" data-sourceid="' . base64_encode($row['Id']) . '"><i class="mdi mdi-pencil me-2 text-muted font-18 vertical-middle"></i>Edit Source</a>
      <a class="dropdown-item remove_source" href="javascript:void(0)" data-sourceid="' . base64_encode($row['Id']) . '"><i class="mdi mdi-delete me-2 text-muted font-18 vertical-middle"></i>Remove Source</a> 
    </div>
  </div>';

    //Shown initial 100 characters of content
    $startContent = substr($row['SourceDetails'], 0, 100);
    if (strlen($row['SourceDetails']) > 100) {
        $startContent .= '...';
    }
    $dataArray[] = array($i, $row['Source'], $startContent, $action);
    $i++;
}
sqlsrv_free_stmt($result);

$tbldata = array(
    "draw" => '',
    "recordsTotal" => '',
    "recordsFiltered" => '',
    "data" => $dataArray
);

header('Content-Type: application/json');
echo json_encode($tbldata);
