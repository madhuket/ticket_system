<?php
include "../config.php";


$TicketId = base64_decode($_POST['TicketId']) ?? '';
if ($TicketId != '') {
    $sql = "SELECT t.Id AS TicketId,t.Title, t.CreatedAt, t.CreatedBy, t.ModifiedAt as TktModifiedAt, t.Attachments, t.FollowUpAt, t.NextFollowUpDate,t.CaseDetails, t.ImmediateActionTaken, t.ReportedBy, t.Category, t.Source,
        ts.Id AS StatusId, 
        ts.Status AS TicketStatus, 
        p.Priority AS TicketPriority,
        s.Source AS TicketSource
    FROM 
        Tickets t 
    JOIN 
        Status ts ON t.Status = ts.Id 
    JOIN
        Priorities p ON t.Priority = p.Id
    JOIN
        Source s ON t.Source = s.Id       
    WHERE t.Id = ? AND t.IsDeleted = 0";

    $params = array($TicketId);

    $result = sqlsrv_query($conn, $sql, $params);

    $data = array();
    if ($result !== false) {
        while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
            $row = stdToArray($row);

            $Department = $Parent = $Child = $Sub_Child_1 = $Sub_Child_2 = $Sub_Child_3 = $currSub_Child_4 = '';
            if ($row['Category'] != '' || $row['Category'] != NULL) {
                //fetch ticket categories
                $category_id = $row['Category'];

                if ($category_id != '') {
                    $cate_sql = "SELECT * FROM Ticketing_Categories WHERE ID = ? AND Active = ?";
                    $params = array($category_id, 1); 
                    $cate_result = sqlsrv_query($conn, $cate_sql, $params);

                    if (sqlsrv_has_rows($cate_result)) {
                        $row_category = sqlsrv_fetch_array($cate_result, SQLSRV_FETCH_ASSOC);
                        $Department = $row_category['Department'];
                        $Parent = $row_category['Parent'];
                        $Child = $row_category['Child'];
                        $Sub_Child_1 = $row_category['Sub_Child_1'];
                        $Sub_Child_2 = $row_category['Sub_Child_2'];
                        $Sub_Child_3 = $row_category['Sub_Child_3'];
                        $Sub_Child_4 = $row_category['Sub_Child_4'];
                    }
                }
            }

            //fetch license details
            $source = $source_url = '';
            $tenant_id = $row['Source'];
            if ($tenant_id != '' || $tenant_id != NULL) {
                $license_sql = "SELECT * FROM License WHERE TenantID = ? AND IsActive = ?";
                $params = array($tenant_id, 1);
                $license_result = sqlsrv_query($conn, $license_sql, $params);
                if (sqlsrv_has_rows($license_result)) {
                    $license_row = sqlsrv_fetch_array($license_result, SQLSRV_FETCH_ASSOC);
                    $source = $license_row['TenantName'];
                    $source_url = $license_row['TenantURL'];
                }
            }

            $CreatedAt = new DateTime($row['CreatedAt']['date']);
            $CreatedAtDate = $CreatedAt->format('j M Y');
            $CreatedAtTime = $CreatedAt->format('g:i A');

            $ModifiedAt = '';
            if ($row['TktModifiedAt'] != NULL) {
                $dateObject = new DateTime($row['TktModifiedAt']['date']);
                $formatted_date = $dateObject->format('Y-m-d');

                $ModifiedAt = ($formatted_date != '1900-01-01') ? $dateObject : '';
            }

            if ($ModifiedAt != '') {
                $ModifiedAtDate = $ModifiedAt->format('j M Y');
                $ModifiedAtTime = $ModifiedAt->format('g:i A');
            } else {
                $ModifiedAtDate = '';
                $ModifiedAtTime = '';
            }

            $AttachmentsArr = unserialize($row['Attachments']);

            $NextFollowUpDate = '';
            if ($row['NextFollowUpDate'] != NULL) {
                $dateObject = new DateTime($row['NextFollowUpDate']['date']);
                $formatted_date = $dateObject->format('Y-m-d');

                $NextFollowUpDate = ($formatted_date != '1900-01-01') ? $dateObject : '';
            }

            if ($NextFollowUpDate != '') {
                $NextFollowUpDate = $NextFollowUpDate->format('j M Y');
            }

            $data = [
                'TicketId' => base64_encode($row['TicketId']),
                'TicketTitle' => $row['Title'],
                'CreatedBy' => $row['CreatedBy'],
                'CreatedAtDate' => $CreatedAtDate,
                'CreatedAtTime' => $CreatedAtTime,
                'ModifiedAtDate' => $ModifiedAtDate,
                'ModifiedAtTime' => $ModifiedAtTime,
                'StatusId' => $row['StatusId'],
                'SelectStatus' => $row['TicketStatus'],
                'FollowUpAt' => $row['FollowUpAt'],
                'NextFollowUpDate' => $NextFollowUpDate,
                'ReportedBy' => $row['ReportedBy'],
                'Source' => $row['TicketSource'],
                'CaseDetails' => $row['CaseDetails'],
                'ImmediateActionTaken' => $row['ImmediateActionTaken'],
                'Priority' => $row['TicketPriority'],
                'Attachments' => $AttachmentsArr,
                'Department' => $Department,
                'Parent' => $Parent,
                'Child' => $Child,
                'Sub_Child_1' => $Sub_Child_1,
                'Sub_Child_2' => $Sub_Child_2,
                'Sub_Child_3' => $Sub_Child_3,
                'Sub_Child_4' => $Sub_Child_4,
                'Source' => $source,
                'SourceUrl' => $source_url
            ];
        }
        sqlsrv_free_stmt($result);
    }

    header('Content-Type: application/json');
    if (!empty($data)) {
        echo json_encode(array('success' => true, 'data' => $data));
    } else {
        echo json_encode(array('success' => false, 'data' => 'Error retrieving ticket details'));
    }
}
