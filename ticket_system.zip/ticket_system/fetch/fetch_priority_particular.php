<?php
include "../config.php";

$priority_id =  base64_decode($_POST['priority_id']) ?? '';
if ($priority_id != '') {
    $sql = "SELECT Id, Priority FROM Priorities WHERE Id = ? AND (IsDeleted = 0 OR IsDeleted IS NULL);";
    $params = array($priority_id);
    $result = sqlsrv_query($conn, $sql, $params);

    if ($result === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);

    header('Content-Type: application/json');
    echo json_encode(array('Id' => base64_encode($row['Id']), 'Priority' => htmlspecialchars_decode($row['Priority']), 'csrf_token' => $_SESSION['csrf_token']));
}
