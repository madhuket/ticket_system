<?php
include "../config.php";


$sql_status = "SELECT t.id AS ticket_id, t.ticket_title, t.created_on, t.created_by, ts.id AS status_id, ts.ticket_status AS ticket_status, tc.id AS category_id, tc.category AS ticket_category, t.merchant_id FROM tickets t JOIN ticket_status ts ON t.ticket_status = ts.id JOIN ticket_category tc ON t.ticket_category = tc.id WHERE t.IsDeleted = 0;";

$result = sqlsrv_query($conn, $sql_status);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$data = array();
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {

    $row = stdToArray($row);
    $data[] = [
        'id' => $row['ticket_id'],
        'ticket_title' => $row['ticket_title'],
        'merchant_id' => $row['merchant_id'],
        'created_by' => $row['created_by'],
        'created_on' => $row['created_on']['date'],
        'status_id' => $row['status_id'],
        'select_status' => $row['ticket_status'],
        'category_id' => $row['category_id'],
        'select_category' => $row['ticket_category']
    ];
}

sqlsrv_free_stmt($result);


header('Content-Type: application/json');
echo json_encode($data);
