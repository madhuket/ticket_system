<?php
include "../config.php";

$tenant_id =  $_POST['tenant_id'] ?? '';

if($tenant_id !== ''){
    $length = 16;
    // Define a character set
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $charactersLength = strlen($characters);
    $licenseKey = '';

    // Generate a random string
    for ($i = 0; $i < $length; $i++) {
        $licenseKey .= $characters[rand(0, $charactersLength - 1)];
    }

    // Optionally, format the license key with hyphens
    $licenseKey = implode('-', str_split($licenseKey, 4));

    header('Content-Type: application/json');
    echo json_encode(array('LicenseKey' => $licenseKey));
}






