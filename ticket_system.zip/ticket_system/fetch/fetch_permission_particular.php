<?php
include "../config.php";

$permission_id =  base64_decode($_POST['permission_id']) ?? '';
if ($permission_id != '') {
    $sql = "SELECT Id, Permission, PermissionTag FROM Permissions WHERE Id = ? AND (IsDeleted = 0 OR IsDeleted IS NULL);";
    $params = array($permission_id);
    $result = sqlsrv_query($conn, $sql, $params);

    if ($result === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);

    header('Content-Type: application/json');
    echo json_encode(array('Id' => base64_encode($row['Id']), 'Permission' => htmlspecialchars_decode($row['Permission']), 'PermissionTag' => htmlspecialchars_decode($row['PermissionTag']), 'csrf_token' => $_SESSION['csrf_token']));
}
