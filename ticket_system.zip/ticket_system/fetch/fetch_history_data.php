<?php
include "../config.php";
$HistoryId = base64_decode($_POST['Id']) ?? '';
$TicketId = base64_decode($_POST['TicketId']) ?? '';


$data = array();

$actualTicketHtml = '';

if($user_login){
    $sql_ticket = "SELECT t.Id AS TicketId,t.Title, t.CreatedAt, t.CreatedBy, t.ModifiedAt as TktModifiedAt, t.Attachments, t.FollowUpAt, t.NextFollowUpDate,t.CaseDetails, t.ImmediateActionTaken, t.ReportedBy, t.Category,
        ts.Id AS StatusId, 
        ts.Status AS TicketStatus, 
        p.Priority AS TicketPriority,
        u.Username AS UserName,
        s.Source AS TicketSource
    FROM 
        Tickets t 
    JOIN 
        Status ts ON t.Status = ts.Id 
    JOIN
        Priorities p ON t.Priority = p.Id
    JOIN
        Source s ON t.Source = s.Id    
    JOIN
        [Users] u ON u.Id = t.ModifiedBy        
    WHERE t.Id = ? AND t.IsDeleted = 0";
} else {
    $sql_ticket = "SELECT t.Id AS TicketId,t.Title, t.CreatedAt, t.CreatedBy, t.ModifiedAt as TktModifiedAt, t.Attachments, t.FollowUpAt, t.NextFollowUpDate,t.CaseDetails, t.ImmediateActionTaken, t.ReportedBy, t.Category,
        ts.Id AS StatusId, 
        ts.Status AS TicketStatus, 
        p.Priority AS TicketPriority,
        CONCAT(u.FirstName,' ',u.LastName) AS UserName,
        s.Source AS TicketSource
    FROM 
        Tickets t 
    JOIN 
        Status ts ON t.Status = ts.Id 
    JOIN
        Priorities p ON t.Priority = p.Id
    JOIN
        Source s ON t.Source = s.Id    
    JOIN
        TenantUser u ON u.Id = t.ModifiedBy        
    WHERE t.Id = ? AND t.IsDeleted = 0";
}

$params = array($TicketId);
$ticket_data = sqlsrv_prepare($conn, $sql_ticket, $params);

if (sqlsrv_execute($ticket_data)) {

    $row = sqlsrv_fetch_array($ticket_data, SQLSRV_FETCH_ASSOC);

    if (!empty($row)) {
        $TicketFile = unserialize($row['Attachments']);
        $attachmentsHtml = '';
        if (!empty($TicketFile)) {
            foreach ($TicketFile as $val) {
                $attachmentsHtml .= '<div class="col-md-6">
                        <div class="card mb-1 shadow-none border">
                            <div class="p-2">
                                <div class="row align-items-center">
                                    <div class="col-auto">
                                        <div class="avatar-sm">
                                            <span class="avatar-title badge-soft-primary text-primary rounded">
                                                pdf
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col ps-0">
                                        <a href="download_ticket_file.php?file=' . $val . '" class="text-muted fw-bold" target="_blank">' . $val . '</a>
                                    </div>
                                    <div class="col-auto">
                                        <a href="download_ticket_file.php?file=' . $val . '" class="btn btn-link font-16 text-muted" target="_blank">
                                            <i class="mdi mdi-download"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>';
            }
        }

        $currDepartment = $currParent = $currChild = $currSub_Child_1 = $currSub_Child_2 = $currSub_Child_3 = $currSub_Child_4 = '';
        $child_hid_class = $sub_child_1_hid_class = $sub_child_2_hid_class  = $sub_child_3_hid_class  = $sub_child_4_hid_class = '';
        if ($row['Category'] != '' || $row['Category'] != NULL) {
            //fetch ticket categories

            $category_id = $row['Category'];

            if ($category_id != '') {
                $cate_sql = "SELECT * FROM Ticketing_Categories WHERE ID = ? AND Active = ?";

                $params = array($category_id, 1);
                $cate_result = sqlsrv_query($conn, $cate_sql, $params);

                if (sqlsrv_has_rows($cate_result)) {
                    $row_category = sqlsrv_fetch_array($cate_result, SQLSRV_FETCH_ASSOC);
                    $currDepartment = $row_category['Department'];
                    $currParent = $row_category['Parent'];
                    $currChild = $row_category['Child'];
                    $currSub_Child_1 = $row_category['Sub_Child_1'];
                    $currSub_Child_2 = $row_category['Sub_Child_2'];
                    $currSub_Child_3 = $row_category['Sub_Child_3'];
                    $currSub_Child_4 = $row_category['Sub_Child_4'];

                    $child_hid_class = ($currChild !== '' && $currChild !== NULL) ? '' : 'd-none';
                    $sub_child_1_hid_class = ($currSub_Child_1 !== '' && $currSub_Child_1 !== NULL) ? '' : 'd-none';
                    $sub_child_2_hid_class = ($currSub_Child_2 !== '' && $currSub_Child_2 !== NULL) ? '' : 'd-none';
                    $sub_child_3_hid_class = ($currSub_Child_3 !== '' && $currSub_Child_3 !== NULL) ? '' : 'd-none';
                    $sub_child_4_hid_class = ($currSub_Child_4 !== '' && $currSub_Child_4 !== NULL) ? '' : 'd-none';
                }
            }
        }

        $currTicketTitle = $row['Title'];
        $currTicketStatus = $row['TicketStatus'];
        $currSource = $row['TicketSource'];
        $currReportedBy = $row['ReportedBy'];
        $currFollowUpAt = $row['FollowUpAt'];
        $currCaseDetails = $row['CaseDetails'];
        $currImmediateActionTaken = $row['ImmediateActionTaken'];
        $currPriority = $row['TicketPriority'];
        $currTicketFile = $attachmentsHtml;

        if($row['NextFollowUpDate'] != NULL){
            $formatted_date = $row['NextFollowUpDate']->format('Y-m-d');
            $NextFollowUpDate = ($formatted_date != '1900-01-01') ? $row['NextFollowUpDate'] : '';
         }

        if ($NextFollowUpDate != '') {
            $NextFollowUpDate = $NextFollowUpDate->format('j M Y');
        }
        $currNextFollowUpDate = $NextFollowUpDate;

        $actualTicketHtml .= '
            <div class="row">
                <div class="col-md-6">      
                    <label class="mt-2 mb-1">Title :</label>
                    <p id="">
                        <i class="mdi mdi-ticket font-18 text-success me-1 align-middle"></i>
                        ' . $row['Title'] . '
                    </p>

                    <label class="mt-2 mb-1">Reported By :</label>
                    <div class="d-flex align-items-start">
                        <i class="mdi mdi-account font-18 text-success me-1 align-middle"></i>
                        <div class="w-100">
                            <p id="">' . $row['ReportedBy'] . '</p>
                        </div>
                    </div>

                    <label class="mt-2 mb-1">Department :</label>
                    <div class="d-flex align-items-start">
                        <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                        <div class="w-100">
                            <p id="">' . $currDepartment . '</p>
                        </div>
                    </div>

                    <label class="mt-2 mb-1">Parent :</label>
                    <div class="d-flex align-items-start">
                        <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                        <div class="w-100">
                            <p id="">' . $currParent . '</p>
                        </div>
                    </div>
                    
                    <div class='.$child_hid_class.'>
                        <label class="mt-2 mb-1">Child :</label>
                        <div class="d-flex align-items-start">
                            <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                            <div class="w-100">
                                <p id="">' . $currChild . '</p>
                            </div>
                        </div>
                    </div>
                
                    <div class='.$sub_child_1_hid_class.'>
                        <label class="mt-2 mb-1">Sub Child 1 :</label>
                        <div class="d-flex align-items-start">
                            
                            <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                            <div class="w-100">
                                <p id="">' . $currSub_Child_1 . '</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class='.$sub_child_2_hid_class.'>
                        <label class="mt-2 mb-1">Sub Child 2 :</label>
                        <div class="d-flex align-items-start">
                            
                            <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                            <div class="w-100">
                                <p id="">' . $currSub_Child_2 . '</p>
                            </div>
                        </div>
                    </div>

                    <div class='.$sub_child_3_hid_class.'>
                        <label class="mt-2 mb-1">Sub Child 3 :</label>
                        <div class="d-flex align-items-start">
                            <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                            <div class="w-100">
                                <p id="">' . $currSub_Child_3 . '</p>
                            </div>
                        </div>
                    </div>

                    <div class='.$sub_child_4_hid_class.'>
                        <label class="mt-2 mb-1">Sub Child 4 :</label>
                        <div class="d-flex align-items-start">
                            <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                            <div class="w-100">
                                <p id="">' . $currSub_Child_4 . '</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <label class="mt-2 mb-1">Source :</label>
                    <div class="d-flex align-items-start">
                        <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                        <div class="w-100">
                            <p id="">' . $row['TicketSource'] . '</p>
                        </div>
                    </div>

                    <label class="mt-2 mb-1">Priority Level :</label>
                    <div class="d-flex align-items-start">
                        <i class="mdi mdi-filter-variant font-18 text-success me-1 align-middle"></i>
                        <div class="w-100">
                            <p id="">' . $row['TicketPriority'] . '</p>
                        </div>
                    </div>

                    <label class="mt-2 mb-1">Status :</label>
                    <div class="d-flex align-items-start">
                        <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                        <div class="w-100">
                            <p id="">' . $row['TicketStatus'] . '</p>
                        </div>
                    </div>

                    <label class="mt-2 mb-1">Follow Up At :</label>
                    <div class="d-flex align-items-start">
                        <i class="mdi mdi-email font-18 text-success me-1 align-middle"></i>
                        <div class="w-100">
                            <p id="">' . $row['FollowUpAt'] . '</p>
                        </div>
                    </div>

                    <label class="mt-2 mb-1">Next Follow Up Date :</label>
                    <div class="d-flex align-items-start">                    
                        <i class="mdi mdi-phone font-18 text-success me-1 align-middle"></i>
                        <div class="w-100">
                            <p id="">' . $NextFollowUpDate . '</p>
                        </div>
                    </div>

                    <label class="mt-4 mb-1">Case Details :</label>
                    <p class="text-muted mb-0" id="">' . $row['CaseDetails'] . '</p>

                    <label class="mt-4 mb-1">Immediate Action Taken :</label>
                    <p class="text-muted mb-0" id="">' . $row['ImmediateActionTaken'] . '</p>

                </div> 
            </div>
    
            <div class="row">
                <label class="mt-4 mb-1">Attachments:</label>
                <div class="row">
                   ' . $attachmentsHtml . ' 
                </div>
            </div>
            
            <div class="row"> 
                <div class="col-md-6"> 
                    <label class="mt-2 mb-1">Modified By :</label>
                    <div class="d-flex align-items-start"> 
                        <i class="mdi mdi-account font-18 text-success me-1 align-middle"></i>
                        <div class="w-100">
                            <p id="">' . $row['UserName'] . '</p>
                        </div>
                    </div>
                </div>  
            </div>';
    } else {
        $actualTicketHtml = 'Ticket Data Not Found';
    }
}

if ($HistoryId != '') {
    if($user_login){
        $sql_history = "SELECT th.*, u.Username AS Name FROM History th INNER JOIN [Users] u ON th.CreatedBy = u.Id WHERE th.Id = ?";
    } else {
        $sql_history = "SELECT th.*, CONCAT(u.FirstName,' ',u.LastName) AS Name FROM History th INNER JOIN TenantUser u ON th.CreatedBy = u.Id WHERE th.Id = ?";
    }

    $params = array($HistoryId);

    $result = sqlsrv_query($conn, $sql_history, $params);

    if ($result === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $historyTicketHtml = '';
    $history_update_class = 'bg-warning text-light p-1 rounded-1';
    while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
        $row = stdToArray($row);
        $dataArr = unserialize($row['UpdatedData']);
        $historyDataArr = unserialize($row['HistoryData']);
        $TicketId = $row['TicketId'];

        $Department = $Parent = $Child = $Sub_Child_1 = $Sub_Child_2 = $Sub_Child_3 = $Sub_Child_4 = '';

        if (isset($dataArr['category']) || array_key_exists('category', $dataArr)) {
            $his_child_hid_class = $his_sub_child_1_hid_class = $his_sub_child_2_hid_class = $his_sub_child_3_hid_class = $his_sub_child_4_hid_class = '';

            if ($dataArr['category'] != '' || $dataArr['category'] != NULL) {
                //fetch ticket categories
                $category_id = $dataArr['category'];
                if ($category_id != '') {
                    $cate_sql = "SELECT * FROM Ticketing_Categories WHERE ID = ? AND Active = ?";

                    $params = array($category_id, 1);
                    $cate_result = sqlsrv_query($conn, $cate_sql, $params);

                    if (sqlsrv_has_rows($cate_result)) {
                        $row_category = sqlsrv_fetch_array($cate_result, SQLSRV_FETCH_ASSOC);
                        $Department = $row_category['Department'];
                        $Parent = $row_category['Parent'];
                        $Child = $row_category['Child'];
                        $Sub_Child_1 = $row_category['Sub_Child_1'];
                        $Sub_Child_2 = $row_category['Sub_Child_2'];
                        $Sub_Child_3 = $row_category['Sub_Child_3'];
                        $Sub_Child_4 = $row_category['Sub_Child_4'];

                        $department_class = $Department != $currDepartment ? $history_update_class : '';
                        $parent_class = $Parent != $currParent ? $history_update_class : '';
                        $child_class = $Child != $currChild ? $history_update_class : '';
                        $sub_child_class_1 = $Sub_Child_1 != $currSub_Child_1 ? $history_update_class : '';
                        $sub_child_class_2 = $Sub_Child_2 != $currSub_Child_2 ? $history_update_class : '';
                        $sub_child_class_3 = $Sub_Child_3 != $currSub_Child_3 ? $history_update_class : '';
                        $sub_child_class_4 = $Sub_Child_4 != $currSub_Child_4 ? $history_update_class : '';
                    }
                }
            }
        } else {
            $department_class = $parent_class = $child_class = $sub_child_class_1 = $sub_child_class_2 = $sub_child_class_3 = $sub_child_class_4 = '';

            //fetch ticket categories
            $category_id = $historyDataArr['Category'];
            if ($category_id != '') {
                $cate_sql = "SELECT * FROM Ticketing_Categories WHERE ID = ? AND Active = ?";
                $params = array($category_id, 1); 
                $cate_result = sqlsrv_query($conn, $cate_sql, $params);

                if (sqlsrv_has_rows($cate_result)) {
                    $row_category = sqlsrv_fetch_array($cate_result, SQLSRV_FETCH_ASSOC);
                    $Department = $row_category['Department'];
                    $Parent = $row_category['Parent'];
                    $Child = $row_category['Child'];
                    $Sub_Child_1 = $row_category['Sub_Child_1'];
                    $Sub_Child_2 = $row_category['Sub_Child_2'];
                    $Sub_Child_3 = $row_category['Sub_Child_3'];
                    $Sub_Child_4 = $row_category['Sub_Child_4'];

                    $his_child_hid_class = ($Child !== '' && $Child !== NULL) ? '' : 'd-none';
                    $his_sub_child_1_hid_class = ($Sub_Child_1 !== '' && $Sub_Child_1 !== NULL) ? '' : 'd-none';
                    $his_sub_child_2_hid_class = ($Sub_Child_2 !== '' && $Sub_Child_2 !== NULL) ? '' : 'd-none';
                    $his_sub_child_3_hid_class = ($Sub_Child_3 !== '' && $Sub_Child_3 !== NULL) ? '' : 'd-none';
                    $his_sub_child_4_hid_class = ($Sub_Child_4 !== '' && $Sub_Child_4 !== NULL) ? '' : 'd-none';
                }
            }
        }

        $Source = '';
        if (isset($dataArr['select_source']) || array_key_exists('select_source', $dataArr)) {
            $Source = $dataArr['select_source'];
            $source_class = $history_update_class;
        } else {
            $source_class = '';
            $Source = $historyDataArr['Source'];
        }

        if ($Source != '') {
            $sql_source = "SELECT Id, Source FROM Source WHERE Id = ?";
            $params = array($Source);

            $result_source = sqlsrv_query($conn, $sql_source, $params);

            if ($result_source === false) {
                die(print_r(sqlsrv_errors(), true));
            }

            while ($row_source = sqlsrv_fetch_array($result_source, SQLSRV_FETCH_ASSOC)) {
                $row_source = stdToArray($row_source);
                $Source = $row_source['Source'];
            }
        }

        $ticketStatus = '';
        if (isset($dataArr['select_status']) || array_key_exists('select_status', $dataArr)) {
            $ticketStatus = $dataArr['select_status'];
            $status_class = $history_update_class;
        } else {
            $status_class = '';
            $ticketStatus = $historyDataArr['Status'];
        }

        if ($ticketStatus != '') {
            $sql_status = "SELECT Id, Status FROM Status WHERE Id = ?";
            $params = array($ticketStatus);

            $result_status = sqlsrv_query($conn, $sql_status, $params);

            if ($result_status === false) {
                die(print_r(sqlsrv_errors(), true));
            }
            while ($row_status = sqlsrv_fetch_array($result_status, SQLSRV_FETCH_ASSOC)) {
                $row_status = stdToArray($row_status);
                $ticketStatus = $row_status['Status'];
            }
        }

        $ticketPriority = '';
        if (isset($dataArr['priority']) || array_key_exists('priority', $dataArr)) {
            $ticketPriority = $dataArr['priority'];
            $priority_class = $history_update_class;
        } else {
            $ticketPriority = $historyDataArr['Priority'];
            $priority_class = '';
        }

        if ($ticketPriority != '') {
            $sql_priority = "SELECT Id, Priority FROM Priorities WHERE Id = ?";
            $params = array($ticketPriority);

            $result_priority = sqlsrv_query($conn, $sql_priority, $params);

            if ($result_priority === false) {
                die(print_r(sqlsrv_errors(), true));
            }

            while ($row_priority = sqlsrv_fetch_array($result_priority, SQLSRV_FETCH_ASSOC)) {
                $row_priority = stdToArray($row_priority);
                $ticketPriority = $row_priority['Priority'];
            }
        }

        $attachmentsHtml = '';
        if (isset($dataArr['Attachments']) || array_key_exists('Attachments', $dataArr)) {
            $TicketFile = unserialize($dataArr['Attachments']);
            if (!empty($TicketFile)) {
                foreach ($TicketFile as $val) {
                    $attachmentsHtml .= '<div class="col-md-6">
                        <div class="card mb-1 shadow-none border">
                            <div class="p-2">
                                <div class="row align-items-center">
                                    <div class="col-auto">
                                        <div class="avatar-sm">
                                            <span class="avatar-title badge-soft-primary text-primary rounded">
                                                pdf
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col ps-0">
                                        <a href="download_ticket_file.php?file='.$val.'" class="text-muted fw-bold" target="_blank">' . $val . '</a>
                                    </div>
                                    <div class="col-auto">
                                        <a href="download_ticket_file.php?file='.$val.'" class="btn btn-link font-16 text-muted" target="_blank">
                                            <i class="mdi mdi-download"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>';  
                }
            }
            $attachments_class = $history_update_class;
        } else {
            $TicketFile = unserialize($historyDataArr['Attachments']);
            if (!empty($TicketFile)) {
                foreach ($TicketFile as $val) {
                    $attachmentsHtml .= '<div class="col-md-6">
                        <div class="card mb-1 shadow-none border">
                            <div class="p-2">
                                <div class="row align-items-center">
                                    <div class="col-auto">
                                        <div class="avatar-sm">
                                            <span class="avatar-title badge-soft-primary text-primary rounded">
                                                pdf
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col ps-0">
                                        <a href="download_ticket_file.php?file='.$val.'" class="text-muted fw-bold" target="_blank">' . $val . '</a>
                                    </div>
                                    <div class="col-auto">
                                        <a href="download_ticket_file.php?file='.$val.'" class="btn btn-link font-16 text-muted" target="_blank">
                                            <i class="mdi mdi-download"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>';
                }
            }

            $attachments_class = '';
        }

        if (isset($dataArr['next_follow_up_date']) || array_key_exists('next_follow_up_date', $dataArr)) {
            if ($dataArr['next_follow_up_date'] != '') {

                if($dataArr['next_follow_up_date'] != '01/01/1900'){
                    $next_follow_up_date = date("j M Y", strtotime($dataArr['next_follow_up_date']));
                } else {
                    $next_follow_up_date = '';
                } 
            } else {
                $next_follow_up_date = '';
            }
            $next_follow_up_date_class = $history_update_class;
        } else {
            $NextFollowUpDate = '';
            if($historyDataArr['NextFollowUpDate'] != NULL){
                $formatted_date = $historyDataArr['NextFollowUpDate']->format('Y-m-d');
                $NextFollowUpDate = ($formatted_date != '1900-01-01') ? $historyDataArr['NextFollowUpDate'] : '';
            }

            if ($NextFollowUpDate != '') {
                $NextFollowUpDate = $NextFollowUpDate->format('j M Y');
            }
            $next_follow_up_date = $NextFollowUpDate;
            $next_follow_up_date_class = '';
        }

        $title_class = (isset($dataArr['ticket_title']) || array_key_exists('ticket_title', $dataArr)) ? $history_update_class : '';
        $reported_by_class = (isset($dataArr['reported_by']) || array_key_exists('reported_by', $dataArr)) ? $history_update_class : '';
        $follow_up_at_class = (isset($dataArr['follow_up_at']) || array_key_exists('follow_up_at', $dataArr)) ? $history_update_class : '';
        $case_details_class = (isset($dataArr['case_details']) || array_key_exists('case_details', $dataArr)) ? $history_update_class : '';
        $immediateactiontaken_class = (isset($dataArr['immediate_action_taken']) || array_key_exists('immediate_action_taken', $dataArr)) ? $history_update_class : '';
        
        $ModifiedAtDate = date("j M Y", strtotime($row['CreatedAt']['date']));
        $ModifiedAtTime = date("g:i A", strtotime($row['CreatedAt']['date']));

        $historyTicketHtml .= '
        <div class="row">
            <div class="col-md-6">
                <label class="mt-2 mb-1 ' . $title_class . '">Title :</label>
                <p id="his_ticket_title">
                    <i class="mdi mdi-ticket font-18 text-success me-1 align-middle"></i>
                    ' . ((isset($dataArr['ticket_title']) ? $dataArr['ticket_title'] : $historyDataArr['Title']) ?? '') . '
                </p>

                <label class="mt-2 mb-1 ' . $reported_by_class . '">Reported By :</label>
                <div class="d-flex align-items-start">
                    <i class="mdi mdi-account font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_ticket_reported_By">' . ((isset($dataArr['reported_by']) ? $dataArr['reported_by'] : $historyDataArr['ReportedBy']) ?? '') . '</p>
                    </div>
                </div>

                <label class="mt-2 mb-1 ' . $department_class . '">Department :</label>
                <div class="d-flex align-items-start">
                    <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_department">' . $Department . '</p>
                    </div>
                </div>

                <label class="mt-2 mb-1 ' . $parent_class . '">Parent :</label>
                <div class="d-flex align-items-start">
                    <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_parent">' . $Parent . '</p>
                    </div>
                </div>

                <div class='.$his_child_hid_class.'>
                <label class="mt-2 mb-1 ' . $child_class . '">Child :</label>
                <div class="d-flex align-items-start">
                    <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_child">' . $Child . '</p>
                    </div>
                </div>
                </div>

                <div class='.$his_sub_child_1_hid_class.'>
                <label class="mt-2 mb-1 ' . $sub_child_class_1 . '">Sub Child 1 :</label>
                <div class="d-flex align-items-start">
                    <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_sub_child_1">' . $Sub_Child_1 . '</p>
                    </div>
                </div>
                </div>

                <div class='.$his_sub_child_2_hid_class.'>
                <label class="mt-2 mb-1 ' . $sub_child_class_2 . '">Sub Child 2 :</label>
                <div class="d-flex align-items-start">
                    <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_sub_child_2">' . $Sub_Child_2 . '</p>
                    </div>
                </div>
                </div>

                <div class='.$his_sub_child_3_hid_class.'>
                <label class="mt-2 mb-1 ' . $sub_child_class_3 . '">Sub Child 3 :</label>
                <div class="d-flex align-items-start">
                    <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_sub_child_3">' . $Sub_Child_3 . '</p>
                    </div>
                </div>
                </div>

                <div class='.$his_sub_child_4_hid_class.'>
                <label class="mt-2 mb-1 ' . $sub_child_class_4 . '">Sub Child 4 :</label>
                <div class="d-flex align-items-start">
                    <i class="mdi mdi-ticket-percent font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_sub_child_4">' . $Sub_Child_4 . '</p>
                    </div>
                </div>
                </div>
            </div>

            <div class="col-md-6">
                <label class="mt-2 mb-1 ' . $source_class . '">Source :</label>
                <div class="d-flex align-items-start">
                    <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_ticket_source">' . $Source . '</p>
                    </div>
                </div>

                <label class="mt-2 mb-1 ' . $priority_class . '">Priority Level :</label>
                <div class="d-flex align-items-start">
                    <i class="mdi mdi-filter-variant font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_ticket_priority">' . $ticketPriority . '</p>
                    </div>
                </div>

                <label class="mt-2 mb-1 ' . $status_class . '">Ticket Status :</label>
                <div class="d-flex align-items-start">
                    <i class="mdi mdi-ticket-confirmation font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_ticket_status">' . $ticketStatus . '</p>
                    </div>
                </div>

                <label class="mt-2 mb-1 ' . $follow_up_at_class . '">Follow Up At :</label>
                <div class="d-flex align-items-start">
                    <i class="mdi mdi-email font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_follow_up_email">' . ((isset($dataArr['follow_up_at']) ? $dataArr['follow_up_at'] : $historyDataArr['FollowUpAt']) ?? '') . '</p>
                    </div>
                </div>

                <label class="mt-2 mb-1 ' . $next_follow_up_date_class . '">Next Follow Up Date :</label>
                <div class="d-flex align-items-start">                    
                    <i class="mdi mdi-phone font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="his_follow_up_date">' . $next_follow_up_date . '</p>
                    </div>
                </div>

                <label class="mt-4 mb-1 ' . $case_details_class . '">Case Details :</label>
                <p class="text-muted mb-0" id="his_case_details">' . ((isset($dataArr['case_details']) ? $dataArr['case_details'] : $historyDataArr['CaseDetails']) ?? '') . '</p>

                <label class="mt-4 mb-1 ' . $immediateactiontaken_class . '">Immediate Action Taken :</label>
                <p class="text-muted mb-0" id="his_immediate_action_taken">' . ((isset($dataArr['immediate_action_taken']) ? $dataArr['immediate_action_taken'] : $historyDataArr['ImmediateActionTaken']) ?? '') . '</p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <label class="mt-4 mb-1 ' . $attachments_class . '">Attachments:</label>
                <div class="row his_attachments_list">
                ' . $attachmentsHtml . ' 
                </div>
            </div>
        </div>
        <div class="row"> 
            <div class="col-md-6"> 
                <label class="mt-2 mb-1">Modified By :</label>
                <div class="d-flex align-items-start"> 
                    <i class="mdi mdi-account font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="">' . $row['Name'] . '</p>
                    </div>
                </div>
            </div> 
            
            <div class="col-md-6"> 
                <label class="mt-2 mb-1">Modified At :</label>
                <div class="d-flex align-items-start"> 
                    <i class="mdi mdi-update font-18 text-success me-1 align-middle"></i>
                    <div class="w-100">
                        <p id="">' . $ModifiedAtDate . '&nbsp;<small class="text-muted">' . $ModifiedAtTime . '</small></p>
                    </div>
                </div>
            </div>     
        </div>';
    }

    $respHtml = array('historyTicketHtml' => $historyTicketHtml, 'actualTicketHtml' => $actualTicketHtml);
    sqlsrv_free_stmt($result);
}

header('Content-Type: application/json');
echo json_encode($respHtml);
