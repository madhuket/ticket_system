<?php
include "../config.php";

$sql = "SELECT * FROM License WHERE IsDeleted = 0 OR IsDeleted IS NULL ORDER BY Id DESC;";
$result = sqlsrv_query($conn, $sql);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$dataArray = array();
$i = 1;
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
    $action = '<div class="btn-group dropdown">
        <a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-bs-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-dots-horizontal"></i></a>
        <div class="dropdown-menu dropdown-menu-end">
        <a class="dropdown-item edit_license" href="javascript:void(0)" data-licenseid="' . base64_encode($row['Id']) . '"><i class="mdi mdi-pencil me-2 text-muted font-18 vertical-middle"></i>Edit License</a>
        <a class="dropdown-item remove_license" href="javascript:void(0)" data-licenseid="' . base64_encode($row['Id']) . '"><i class="mdi mdi-delete me-2 text-muted font-18 vertical-middle"></i>Remove License</a> 
        </div>
    </div>';
    $IsActive = $row['IsActive'] == 1 ? 'Active' : 'InActive';
    $FrmtIssueDate = $row['IssueDate']->format("Y-m-d");   //format("Y-m-d H:i:s")
    $FrmtExpiryDate = $row['ExpiryDate']->format("Y-m-d");
    $IssueDate = ($FrmtIssueDate != '1900-01-01') ? $row['IssueDate']->format('m/d/Y') : '';
    $ExpiryDate = ($FrmtExpiryDate != '1900-01-01') ? $row['ExpiryDate']->format('m/d/Y') : '';

    $dataArray[] = array($i, $row['TenantName'], $row['LicenseKey'], $IssueDate, $ExpiryDate, $IsActive, $action);
    $i++;
}

sqlsrv_free_stmt($result);

$tbldata = array(
    "draw" => '',
    "recordsTotal" => '',
    "recordsFiltered" => '',
    "data" => $dataArray
);

header('Content-Type: application/json');
echo json_encode($tbldata);
