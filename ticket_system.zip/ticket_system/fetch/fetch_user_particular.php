<?php
include "../config.php";

$user_id =  base64_decode($_POST['user_id']) ?? '';
if ($user_id != '') {
    //fetch role and permission 
    $sql = "SELECT Username, Email, Password, Role, Source, IsActive
    FROM Users
    WHERE Id = ?;";

    $params = array($user_id);
    $result = sqlsrv_query($conn, $sql, $params);

    if ($result === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
    
    header('Content-Type: application/json');
    echo json_encode(array('Id' => base64_encode($user_id), 'Username' => $row['Username'], 'Email' => $row['Email'], 'Password' => $row['Password'], 'Role' => base64_encode($row['Role']), 'Source' => base64_encode($row['Source']), 'IsActive' => $row['IsActive'], 'CsrfToken' => $_SESSION['csrf_token']));
}
