<?php
include "../config.php";

$license_id =  base64_decode($_POST['license_id']) ?? '';
if ($license_id != '') {
    $sql = "SELECT * FROM License WHERE Id = ? AND (IsDeleted = 0 OR IsDeleted IS NULL);";
    $params = array($license_id);

    $result = sqlsrv_query($conn, $sql, $params);

    if ($result === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);

    $FrmtIssueDate = $row['IssueDate']->format("Y-m-d"); 
    $FrmtExpiryDate = $row['ExpiryDate']->format("Y-m-d");
    $IssueDate = ($FrmtIssueDate != '1900-01-01') ? $row['IssueDate']->format('m/d/Y') : '';
    $ExpiryDate = ($FrmtExpiryDate != '1900-01-01') ? $row['ExpiryDate']->format('m/d/Y') : '';
    header('Content-Type: application/json');
    echo json_encode(array('Id' => base64_encode($row['Id']), 'TenantID' => base64_encode($row['TenantID']), 'TenantURL' => $row['TenantURL'], 'LicenseKey' => $row['LicenseKey'], 'LicenseURL' => $row['TenantURL'], 'IssueDate' => $IssueDate, 'ExpiryDate' => $ExpiryDate, 'IsActive' => $row['IsActive'], 'CsrfToken' => $_SESSION['csrf_token']));
}
