<?php
include "../config.php";

$startDate =  $_POST['startDate'] ?? '';
$endDate =  $_POST['endDate'] ?? '';

$table_row = '';
if($startDate != '' && $endDate != ''){
    $startDateObj = new DateTime($startDate);
    $endDateObj = new DateTime($endDate);

    $startDateFrmt = $startDateObj->format('Y-m-d H:i:s.u');
    $endDateFrmt = $endDateObj->format('Y-m-d H:i:s.u');

    $sql_latest_open_tickets = "SELECT TOP 10 t.Id AS TicketId,t.Title, t.CreatedAt, t.CreatedBy, t.ReportedBy, t.Category,
        ts.Id AS StatusId, 
        ts.Status AS Status,
        sr.Source,
        p.Priority,
        c.Department,
        c.Parent 
    FROM 
        Tickets t 
    LEFT JOIN 
        Status ts ON t.Status = ts.Id
    LEFT JOIN 
        Source sr ON t.Source = sr.Id    
    LEFT JOIN
        Priorities p ON p.Id = t.Priority
    LEFT JOIN 
        Ticketing_Categories c ON t.Category = c.ID      
    WHERE c.Active = ? AND t.Source = ? AND ts.BaseStatus = ? AND (t.CreatedAt BETWEEN ? AND ?) AND (t.IsDeleted = 0 OR t.IsDeleted IS NULL) ORDER BY t.Id DESC;";

    $params = array(1, $_SESSION['tenant_id'], 0, $startDateFrmt, $endDateFrmt);
    $stmt_latest_open_tickets = sqlsrv_prepare($conn, $sql_latest_open_tickets, $params);
    
    if (sqlsrv_execute($stmt_latest_open_tickets) && sqlsrv_has_rows($stmt_latest_open_tickets)) {
        while ($row = sqlsrv_fetch_array($stmt_latest_open_tickets, SQLSRV_FETCH_ASSOC)) {
            $row = stdToArray($row);

            $sts_class = $edit_class = '';
            if ($row['Status'] == 'Closed') {
                $sts_class = 'bg-secondary';
                $edit_class = 'd-none';
            } else 
                if ($row['Status'] == 'Open') {
                $sts_class = 'bg-success';
            } else {
                $sts_class = 'bg-secondary';
            }

            //show title upto 30 characters
            $title_str = '';
            if (strlen($row['Title']) > 30) {
                $title_str = substr($row['Title'], 0, 15) . '..';
                $title = '<span data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="' . $row['Title'] . '">' . $title_str . '</span>';
            } else {
                $title = $row['Title'];
            }

            $reported_by_str = '';
            if (strlen($row['ReportedBy']) > 30) {
                $reported_by_str = substr($row['ReportedBy'], 0, 15) . '..';
                $ReportedBy = '<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . $row['ReportedBy'] . '">' . $reported_by_str . '</span>';
            } else {
                $ReportedBy = $row['ReportedBy'];
            }

            $priority_class = '';
            if ($row['Priority'] == 'High') { 
                $priority_class = 'bg-soft-danger text-danger';
            } else 
                if ($row['Priority'] == 'Medium') {
                $priority_class = 'bg-soft-warning text-warning';
            } else 
                if ($row['Priority'] == 'Low') {
                $priority_class = 'bg-soft-secondary text-secondary';
            } else {
                $priority_class = 'bg-soft-secondary text-secondary';
            }

            $TicketStatus = '<span class="badge ' . $sts_class . ' text-light">' . $row['Status'] . '</span>';
            $TicketPriority = '<span class="badge ' . $priority_class . '">' . $row['Priority'] . '</span>';

            $table_row .= '<tr class="cursor-pointer tkt_tbl_row" data-ticketid="' . base64_encode($row['TicketId']) . '" title="Ticket Details"> 
            <td>' . $title . '</td>
            <td>' . $TicketStatus . '</td>
            <td>'. $TicketPriority . '</td>
            <td>'. $row['Source']. '</td>
            <td>'. $ReportedBy. '</td>
            <td>'. $row['Department']. '</td>
            <td>'. $row['Parent']. '</td>
            </tr>';
        }
    }

    header('Content-Type: application/json');
    echo json_encode(array('table_row' => $table_row));
}



?>