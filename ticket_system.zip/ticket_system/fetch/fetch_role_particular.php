<?php
include "../config.php";

$role_id =  base64_decode($_POST['role_id']) ?? '';
if ($role_id != '') {

    //fetch role and permission 
    $sql = "SELECT r.Id as RoleId, r.Role, r.IsSuperAdmin, p.Id as PermId, p.Permission
    FROM Roles r
    LEFT JOIN RolePermissions rp ON r.Id = rp.Role
    LEFT JOIN Permissions p ON rp.Permission = p.Id
    WHERE r.Id = ?;";

    $params = array($role_id);
    $result = sqlsrv_query($conn, $sql, $params);

    if ($result === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $permission_arr = [];
    while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
        $RoleId = base64_encode($row['RoleId']);
        $Role = $row['Role'];
        $IsSuperAdmin = $row['IsSuperAdmin'];
        $permission_arr[] = base64_encode($row['PermId']);
    }
 
    header('Content-Type: application/json');
    
    echo json_encode(array('Id' => $RoleId, 'Role' => $Role, 'Permission' => $permission_arr, 'IsSuperAdmin' => $IsSuperAdmin, 'CsrfToken' => $_SESSION['csrf_token']));
}
