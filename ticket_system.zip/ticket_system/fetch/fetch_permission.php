<?php
include "../config.php";

$sql = "SELECT Id, Permission, PermissionTag FROM Permissions WHERE IsDeleted = 0 OR IsDeleted IS NULL ORDER BY Id DESC;";
$result = sqlsrv_query($conn, $sql);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$dataArray = array();
$i = 1;
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
    $action = '<div class="btn-group dropdown">
        <a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-bs-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-dots-horizontal"></i></a>
        <div class="dropdown-menu dropdown-menu-end">
        <a class="dropdown-item edit_permission" href="javascript:void(0)" data-permissionid="' . base64_encode($row['Id']) . '"><i class="mdi mdi-pencil me-2 text-muted font-18 vertical-middle"></i>Edit Permission</a>
        <a class="dropdown-item remove_permission" href="javascript:void(0)" data-permissionid="' . base64_encode($row['Id']) . '"><i class="mdi mdi-delete me-2 text-muted font-18 vertical-middle"></i>Remove Permission</a> 
        </div>
    </div>';           

    $dataArray[] = array($i, $row['Permission'], $row['PermissionTag'], $action);
    $i++;
}

sqlsrv_free_stmt($result);

$tbldata = array(
    "draw" => '',
    "recordsTotal" => '',
    "recordsFiltered" => '',
    "data" => $dataArray
);

header('Content-Type: application/json');
echo json_encode($tbldata);
