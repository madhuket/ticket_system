<?php
include "../config.php";

$TicketId = base64_decode($_POST['Id']) ?? '';


$data = array();

if ($TicketId != '') {
    if($user_login){
        $sql_history = "SELECT th.*, u.Username AS Name
        FROM 
            History th
        JOIN 
            [Users] u ON th.CreatedBy = u.Id
        WHERE th.TicketId = ? AND (th.IsDeleted = 0 OR th.IsDeleted IS NULL)
        ORDER BY th.Id DESC";
    } else {
        $sql_history = "SELECT th.*, CONCAT(u.FirstName,' ',u.LastName) AS Name
        FROM 
            History th
        JOIN 
            TenantUser u ON th.CreatedBy = u.Id
        WHERE th.TicketId = ? AND (th.IsDeleted = 0 OR th.IsDeleted IS NULL)
        ORDER BY th.Id DESC";
    }
    $params = array($TicketId);

    $result = sqlsrv_query($conn, $sql_history, $params);

    if ($result === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $data_html = '';
    $i = 1;
    while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
        $row = stdToArray($row);
        $dataArr = unserialize($row['UpdatedData']);
        $data_html .= '<tr>
        <td>' . $i . '</td>
        <td>' . $row['Name'] . '</td>
        <td>' . $row['IPAddress'] . '</td>
        <td>' . date("Y-m-d H:i:s", strtotime($row['CreatedAt']['date'])) . '</td>
        <td>' . $dataArr['Action'] . '</td>
        <td><a class="dropdown-item history_details" href="javascript:void(0)" data-historyid="' . base64_encode($row['Id']) . '" data-ticketid="' . base64_encode($TicketId) . '" data-bs-toggle="modal" data-bs-target="#tktHistoryModal"><i class="mdi mdi-eye me-2 text-muted font-18 vertical-middle"></i></a></td>';
        $i++;
    }

    echo $data_html;
}
