<?php
include "../config.php";


$sql_status = "SELECT t.Id AS TicketId,t.TicketTitle, t.CreatedAt, t.CreatedBy, 
                ts.Id AS StatusId, 
                ts.Status AS Status, 
                tc.Id AS CategoryId, 
                tc.Category AS TicketCategory, 
                t.MerchantId,
                cp.Id AS ParticularsId,
                cp.EmailCall,
                cp.PersonCalling,
                cp.FollowUpEmail,
                cp.FollowUpPhone,
                cp.FollowUp,
                cp.CallTopic,
				ct.Topic,
                cp.CallDetail,
                cp.ActionTaken,
                cp.Notes,
                cp.Priority,
				p. Priority,
                cp.Feedback
            FROM 
                Tickets t 
            JOIN 
                TicketStatus ts ON t.TicketStatus = ts.Id 
            JOIN 
                TicketCategory tc ON t.TicketCategory = tc.Id
            JOIN
                CallParticulars cp ON t.Id = cp.TicketId
			JOIN
				Priorities p ON p.Id = cp.Priority
			JOIN
				CallTopic ct ON ct.Id = cp.CallTopic
            WHERE t.IsDeleted = 0;";

$result = sqlsrv_query($conn, $sql_status);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$data = array();
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {

    $row = stdToArray($row);
    $data[] = [
        'Id' => $row['TicketId'],
        'TicketTitle' => $row['TicketTitle'],
        'MerchantId' => $row['MerchantId'],
        'CreatedBy' => $row['CreatedBy'],
        'CreatedAT' => $row['CreatedAt']['date'],
        'StatusId' => $row['StatusId'],
        'SelectStatus' => $row['TicketStatus'],
        'TicketCategory' => $row['CategoryId'],
        'SelectCategory' => $row['TicketCategory'],
        'ParticularsId' => $row['ParticularsId'],
        'EmailCall' => $row['EmailCall'],
        'PersonCalling' => $row['PersonCalling'],
        'FollowUpEmail' => $row['FollowUpEmail'],
        'FollowUpPhone' => $row['FollowUpPhone'],
        'FollowUp' => $row['FollowUp'],
        'CallTopic' => $row['CallTopic'],
        'CallDetail' => $row['CallDetail'],
        'ActionTaken' => $row['ActionTaken'],
        'Notes' => $row['Notes'],
        'Priority' => $row['Priority'],
        'Feedback' => $row['Feedback']
    ];
}


sqlsrv_free_stmt($result);


header('Content-Type: application/json');
echo json_encode($data);
