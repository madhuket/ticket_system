<?php
include "../config.php";

$TicketId = base64_decode($_POST['TicketId']);

$sql = "SELECT DraftData,CreatedAt, ModifiedAt FROM Draft WHERE TicketId = ? AND IsDeleted = 0 OR IsDeleted IS NULL;";
$result = sqlsrv_query($conn, $sql, array(&$TicketId));

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$data = array();
$date_time = '';
if (sqlsrv_has_rows($result)) {
    while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
        $row = stdToArray($row);

        $ModifiedLastDraftDate = '';
        if($row['ModifiedAt'] != NULL){
            $dateObject = new DateTime($row['ModifiedAt']['date']);  
            $formatted_date = $dateObject->format('Y-m-d');
            $ModifiedLastDraftDate = ($formatted_date != '1900-01-01') ? $dateObject : '';
        }

        if ($ModifiedLastDraftDate == '') {
            $date = date_create($row['CreatedAt']['date']);
        } else {
            $date = date_create($row['ModifiedAt']['date']);
        }

        $date_time = date_format($date, "m/d/Y H:i A");
        $DraftDataArr = unserialize($row['DraftData']);

        $TicketFile = unserialize($DraftDataArr['Data']['Attachments']);
        $DraftData = $DraftDataArr['Data'];

        //fetch ticket categories
        $Department = $Parent = $Child = $Sub_Child_1 = $Sub_Child_2 = $Sub_Child_3 = $Sub_Child_4 = '';
        $category_id = $DraftData['Category'];
        if ($category_id != '') {
            $cate_sql = "SELECT * FROM Ticketing_Categories WHERE ID = ? AND Active = ?";
            $params = array($category_id, 1); // Binding the actual values to the placeholders
            $cate_stmt = sqlsrv_prepare($conn, $cate_sql, $params);

            $cate_result = sqlsrv_execute($cate_stmt);

            if (sqlsrv_has_rows($cate_stmt)) {
                $row_category = sqlsrv_fetch_array($cate_stmt, SQLSRV_FETCH_ASSOC);
                $Department = $row_category['Department'];
                $Parent = $row_category['Parent'];
                $Child = $row_category['Child'];
                $Sub_Child_1 = $row_category['Sub_Child_1'];
                $Sub_Child_2 = $row_category['Sub_Child_2'];
                $Sub_Child_3 = $row_category['Sub_Child_3'];
                $Sub_Child_4 = $row_category['Sub_Child_4'];
            }
        }

        //fetch license details
        $tenant_id = $DraftData['Source'];
        $source = $source_url = '';
        if ($tenant_id != NULL || $tenant_id != '') {
            $license_sql = "SELECT * FROM License WHERE TenantID = ? AND IsActive = ? AND (IsDeleted = 0 OR IsDeleted IS NULL);";

            $params = array($tenant_id, 1); // Binding the actual values to the placeholders
            $license_stmt = sqlsrv_prepare($conn, $license_sql, $params);

            $license_result = sqlsrv_execute($license_stmt);

            if (sqlsrv_has_rows($license_stmt)) {
                $license_row = sqlsrv_fetch_array($license_stmt, SQLSRV_FETCH_ASSOC);
                $source = $license_row['TenantName'];
                $source_url = $license_row['TenantURL'];
            }
        }

        $data = [
            'DraftData' => $DraftData,
            'SelectSource' => base64_encode($DraftData['Source']),
            'SelectStatus' => base64_encode($DraftData['SelectStatus']),
            'SelectPriority' => base64_encode($DraftData['Priority']),
            'FollowUpAt' => $DraftData['FollowUpAt'],
            'NextFollowUpDate' => ($DraftData['NextFollowUpDate'] != NULL || $DraftData['NextFollowUpDate'] != '01/01/1900') ? $DraftData['NextFollowUpDate'] : '',
            'TicketTitle' => htmlspecialchars_decode($DraftData['Title']),
            'CaseDetails' => htmlspecialchars_decode($DraftData['CaseDetails']),
            'ImmediateActionTaken' => htmlspecialchars_decode($DraftData['ImmediateActionTaken']),
            'Department' => $Department,
            'Parent' => $Parent,
            'Child' => $Child,
            'Sub_Child_1' => $Sub_Child_1,
            'Sub_Child_2' => $Sub_Child_2,
            'Sub_Child_3' => $Sub_Child_3,
            'Sub_Child_4' => $Sub_Child_4,
            'Attachments' => $TicketFile,
            'ModifiedAt' => $date_time,
            'Source' => $source,
            'SourceUrl' => $source_url,
            'CsrfToken' => $_SESSION['csrf_token']
            // 'TenantId' => $tenant_id
        ];
    }
} else {
    $TicketQuery = "SELECT * FROM Tickets WHERE Id = ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";
    $params = array($TicketId);

    $TktData = sqlsrv_prepare($conn, $TicketQuery, $params);

    $FileArr = [];
    
    $ticket_row = [];
    $call_particular_row = [];
    if (sqlsrv_execute($TktData)) {
        $ticket_row = sqlsrv_fetch_array($TktData, SQLSRV_FETCH_ASSOC);

        //fetch ticket categories
        $category_id = $ticket_row['Category'];
        $Department = $Parent = $Child = $Sub_Child_1 = $Sub_Child_2 = $Sub_Child_3 = $Sub_Child_4 = '';
        if ($category_id != NULL || $category_id != '') {
            $cate_sql = "SELECT * FROM Ticketing_Categories WHERE ID = ? AND Active = ?";

            $params = array($category_id, 1); // Binding the actual values to the placeholders
            $cate_stmt = sqlsrv_prepare($conn, $cate_sql, $params);

            $cate_result = sqlsrv_execute($cate_stmt);

            if (sqlsrv_has_rows($cate_stmt)) {
                $row_category = sqlsrv_fetch_array($cate_stmt, SQLSRV_FETCH_ASSOC);
                $Department = $row_category['Department'];
                $Parent = $row_category['Parent'];
                $Child = $row_category['Child'];
                $Sub_Child_1 = $row_category['Sub_Child_1'];
                $Sub_Child_2 = $row_category['Sub_Child_2'];
                $Sub_Child_3 = $row_category['Sub_Child_3'];
                $Sub_Child_4 = $row_category['Sub_Child_4'];
            }
        }

        //fetch license details
        $source = $source_url = '';
        $tenant_id = $ticket_row['Source'];
        if ($tenant_id != NULL || $tenant_id != '') {
            $license_sql = "SELECT * FROM License WHERE TenantID = ? AND IsActive = ? AND (IsDeleted = 0 OR IsDeleted IS NULL);";

            $params = array($tenant_id, 1); // Binding the actual values to the placeholders
            $license_stmt = sqlsrv_prepare($conn, $license_sql, $params);

            $license_result = sqlsrv_execute($license_stmt);

            if (sqlsrv_has_rows($license_stmt)) {
                $license_row = sqlsrv_fetch_array($license_stmt, SQLSRV_FETCH_ASSOC);
                $source = $license_row['TenantName'];
                $source_url = $license_row['TenantURL'];
            }
        }

        $Attachments = unserialize($ticket_row['Attachments']);
 
        $data['SelectStatus'] = base64_encode($ticket_row['Status']);
        $data['SelectSource'] = base64_encode($ticket_row['Source']);
        $data['SelectPriority'] = base64_encode($ticket_row['Priority']);
        $data['Department'] = $Department;
        $data['Parent'] = $Parent;
        $data['Child'] = $Child;
        $data['Sub_Child_1'] = $Sub_Child_1;
        $data['Sub_Child_2'] = $Sub_Child_2;
        $data['Sub_Child_3'] = $Sub_Child_3;
        $data['Sub_Child_4'] = $Sub_Child_4;

        $data['Source'] = $source;
        $data['SourceUrl'] = $source_url;
        
        $NextFollowUpDate = '';
        if($ticket_row['NextFollowUpDate'] != NULL){
           $formatted_date = $ticket_row['NextFollowUpDate']->format('Y-m-d');
           $NextFollowUpDate = ($formatted_date != '1900-01-01') ? $ticket_row['NextFollowUpDate']->format('m/d/Y') : '';
        }

        $data['NextFollowUpDate'] = $NextFollowUpDate != '' ? $NextFollowUpDate : '';
    } else {
        die(print_r(sqlsrv_errors(), true));
    }

    $data['DraftData'] = $ticket_row;
    $data['TicketTitle'] = htmlspecialchars_decode($ticket_row['Title']);
    $data['CaseDetails'] = htmlspecialchars_decode($ticket_row['CaseDetails']);
    $data['ImmediateActionTaken'] = htmlspecialchars_decode($ticket_row['ImmediateActionTaken']);
    $data['ModifiedAt'] = $date_time;
    $data['Attachments'] = $Attachments;
    $data['CsrfToken'] = $_SESSION['csrf_token'];
}

header('Content-type:application/json');
echo json_encode($data);

sqlsrv_free_stmt($result);

