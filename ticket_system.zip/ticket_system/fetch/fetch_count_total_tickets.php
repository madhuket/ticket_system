<?php

include "../config.php";

$startDate =  $_POST['startDate'] ?? '';
$endDate =  $_POST['endDate'] ?? '';

$total_ticket_count = 0;
$total_open_tickets = 0;
$average_age_open_ticket = 0;
$longest_open_ticket = 0;
if($startDate != '' && $endDate != ''){
    $startDateObj = new DateTime($startDate);
    $endDateObj = new DateTime($endDate);

    $startDateFrmt = $startDateObj->format('Y-m-d H:i:s.u');
    $endDateFrmt = $endDateObj->format('Y-m-d H:i:s.u');

    //get the count of total tickets
    $sql_count = "SELECT COUNT(Id) AS TotalTickets FROM Tickets WHERE Source = ? AND (CreatedAt BETWEEN ? AND ?) AND (IsDeleted = 0 OR IsDeleted IS NULL)";
    $params = array($_SESSION['tenant_id'], $startDateFrmt, $endDateFrmt);
    $stmt_count = sqlsrv_prepare($conn, $sql_count, $params);
    if (sqlsrv_execute($stmt_count)) {
        $row = sqlsrv_fetch_array($stmt_count, SQLSRV_FETCH_ASSOC);
        $total_ticket_count = $row['TotalTickets'];
    }

    //get count of open tickets 
    $sql_open_count = "SELECT COUNT(t.Id) AS TotalOpenTickets FROM Tickets t
        LEFT JOIN Status s ON s.Id = t.Status
        WHERE t.Source =? AND s.BaseStatus = ? AND (t.CreatedAt BETWEEN ? AND ?) AND (t.IsDeleted = 0 OR t.IsDeleted IS NULL)";

    $params = array($_SESSION['tenant_id'], 0, $startDateFrmt, $endDateFrmt);
    $stmt_open_count = sqlsrv_prepare($conn, $sql_open_count, $params);
    if (sqlsrv_execute($stmt_open_count)) {
        $row = sqlsrv_fetch_array($stmt_open_count, SQLSRV_FETCH_ASSOC);
        $total_open_tickets = $row['TotalOpenTickets'];
    }

    //get Average Age (in days) of open tickets
    $sql_average_age = "SELECT AVG(DATEDIFF(DAY, t.CreatedAt, GETDATE())) AS AverageAgeOpenTickets FROM Tickets t
        LEFT JOIN Status s ON s.Id = t.Status
        WHERE t.Source =? AND s.BaseStatus = ? AND (t.CreatedAt BETWEEN ? AND ?) AND (t.IsDeleted = 0 OR t.IsDeleted IS NULL)";

    $params = array($_SESSION['tenant_id'], 0, $startDateFrmt, $endDateFrmt);
    $stmt_average_age = sqlsrv_prepare($conn, $sql_average_age, $params);
    if (sqlsrv_execute($stmt_average_age)) {
        $row = sqlsrv_fetch_array($stmt_average_age, SQLSRV_FETCH_ASSOC);
        if($row['AverageAgeOpenTickets'] != null){
            $average_age_open_ticket = $row['AverageAgeOpenTickets'];
        }
    }

    //get Longest (in days) Open ticket 
    $sql_longest_open_ticket = "SELECT MAX(DATEDIFF(DAY, t.CreatedAt, GETDATE())) AS LongestOpenTicket FROM Tickets t
        LEFT JOIN Status s ON s.Id = t.Status
        WHERE t.Source =? AND s.BaseStatus =? AND (t.CreatedAt BETWEEN ? AND ?) AND (t.IsDeleted = 0 OR t.IsDeleted IS NULL)";

    $params = array($_SESSION['tenant_id'], 0, $startDateFrmt, $endDateFrmt);
    $stmt_longest_open_ticket = sqlsrv_prepare($conn, $sql_longest_open_ticket, $params);
    if (sqlsrv_execute($stmt_longest_open_ticket)) {
        $row = sqlsrv_fetch_array($stmt_longest_open_ticket, SQLSRV_FETCH_ASSOC);
        if($row['LongestOpenTicket']!= null){
            $longest_open_ticket = $row['LongestOpenTicket'];
        }
    }

    header('Content-Type: application/json');
    echo json_encode(array('success' => true, 'total_ticket_count' => $total_ticket_count, 'total_open_tickets' => $total_open_tickets, 'average_age_open_ticket' => $average_age_open_ticket, 'longest_open_ticket' => $longest_open_ticket));   
}
?>