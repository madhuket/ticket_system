<?php
include "../config.php";


$tenant_id = $_SESSION['tenant_id'] ?? '';
$params = array();

if (isset($_SESSION['user_login']) && $_SESSION['user_login'] === true) {
    if($tenant_id != ''){
        $sql_ticket = "SELECT t.Id AS TicketId,t.Title, t.CreatedAt, t.CreatedBy, t.ReportedBy, t.Category,
            ts.Id AS StatusId, 
            ts.Status AS Status,
            sr.Source,
            p.Priority,
            c.Department,
            c.Parent 
        FROM 
            Tickets t 
        JOIN 
            Status ts ON t.Status = ts.Id
        JOIN 
            Source sr ON t.Source = sr.Id    
        JOIN
            Priorities p ON p.Id = t.Priority
        LEFT JOIN 
            Ticketing_Categories c ON t.Category = c.ID      
        WHERE c.Active = ? AND t.Source = ? AND t.IsDeleted = 0 ORDER BY t.Id DESC;";

        $params = array(1, $tenant_id);
    } else {
        $sql_ticket = "SELECT t.Id AS TicketId,t.Title, t.CreatedAt, t.CreatedBy, t.ReportedBy, t.Category,
            ts.Id AS StatusId, 
            ts.Status AS Status,
            sr.Source,
            p.Priority,
            c.Department,
            c.Parent 
        FROM 
            Tickets t 
        JOIN 
            Status ts ON t.Status = ts.Id
        JOIN 
            Source sr ON t.Source = sr.Id    
        JOIN
            Priorities p ON p.Id = t.Priority
        LEFT JOIN 
            Ticketing_Categories c ON t.Category = c.ID      
        WHERE c.Active = ? AND t.IsDeleted = 0 ORDER BY t.Id DESC;";

        $params = array(1);
    }
} else {
    $sql_ticket = "SELECT t.Id AS TicketId,t.Title, t.CreatedAt, t.CreatedBy, t.ReportedBy, t.Category,
        ts.Id AS StatusId, 
        ts.Status AS Status,
        sr.Source,
        p.Priority,
        c.Department,
        c.Parent 
    FROM 
        Tickets t 
    JOIN 
        Status ts ON t.Status = ts.Id
    JOIN 
        Source sr ON t.Source = sr.Id    
    JOIN
        Priorities p ON p.Id = t.Priority
    LEFT JOIN 
        Ticketing_Categories c ON t.Category = c.ID     
    WHERE c.Active = ? AND t.Source = ? AND t.IsDeleted = 0 ORDER BY t.Id DESC;";

    $params = array(1, $tenant_id);
}

if(!empty($params)){
    $stmt = sqlsrv_prepare($conn, $sql_ticket, $params);
} else {
    $stmt = sqlsrv_prepare($conn, $sql_ticket);
}

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

$dataArray = array();
if ($result && sqlsrv_has_rows($stmt)) {
    $i = 1;
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $row = stdToArray($row);

        $sts_class = $edit_class = '';
        if ($row['Status'] == 'Closed') {
            $sts_class = 'bg-secondary';
            $edit_class = 'd-none';
        } else 
            if ($row['Status'] == 'Open') {
            $sts_class = 'bg-success';
        } else {
            $sts_class = 'bg-secondary';
        }

        $action = '<div class="btn-group dropdown">
            <a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-bs-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-dots-horizontal"></i></a>
            <div class="dropdown-menu dropdown-menu-end">
            <a class="dropdown-item edit_tkt '.$edit_class.'" href="javascript:void(0)" data-ticketid="' . base64_encode($row['TicketId']) . '"><i class="mdi mdi-pencil me-2 text-muted font-18 vertical-middle"></i>Edit Ticket</a>
            <a class="dropdown-item remove_tkt" href="javascript:void(0)" data-ticketid="' . base64_encode($row['TicketId']) . '"><i class="mdi mdi-delete me-2 text-muted font-18 vertical-middle"></i>Remove Ticket</a>
            <a class="dropdown-item ticket_details" href="javascript:void(0)" data-ticketid="' . base64_encode($row['TicketId']) . '"><i class="mdi mdi-eye me-2 text-muted font-18 vertical-middle"></i>Ticket Details</a>
            <a class="dropdown-item ticket_history" href="javascript:void(0)" data-ticketid="' . base64_encode($row['TicketId']) . '"><i class="mdi mdi-history me-2 font-18 text-muted vertical-middle"></i>View Ticket History</a>
            </div>
        </div>';

        $priority_class = '';
        if ($row['Priority'] == 'High') { 
            $priority_class = 'bg-soft-danger text-danger';
        } else 
            if ($row['Priority'] == 'Medium') {
            $priority_class = 'bg-soft-warning text-warning';
        } else 
            if ($row['Priority'] == 'Low') {
            $priority_class = 'bg-soft-secondary text-secondary';
        } else {
            $priority_class = 'bg-soft-secondary text-secondary';
        }

        //show title upto 30 characters
        $title_str = '';
        if (strlen($row['Title']) > 30) {
            $title_str = substr($row['Title'], 0, 15) . '..';
            $title = '<span data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="' . $row['Title'] . '">' . $title_str . '</span>';
        } else {
            $title = $row['Title'];
        }

        $reported_by_str = '';
        if (strlen($row['ReportedBy']) > 30) {
            $reported_by_str = substr($row['ReportedBy'], 0, 15) . '..';
            $ReportedBy = '<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . $row['ReportedBy'] . '">' . $reported_by_str . '</span>';
        } else {
            $ReportedBy = $row['ReportedBy'];
        }

        $TicketStatus = '<span class="badge ' . $sts_class . ' text-light">' . $row['Status'] . '</span>';
        $TicketPriority = '<span class="badge ' . $priority_class . '">' . $row['Priority'] . '</span>';

        $subdataArray = array();
        $subdataArray = array($i, $title, $TicketStatus, $TicketPriority, $row['Source'], $ReportedBy, $row['Department'], $row['Parent'], $action);
        $dataArray[] = $subdataArray;
        $i++;
    }
}
if (is_resource($stmt)) {
    sqlsrv_free_stmt($stmt);
}

$tbldata = array(
    "draw" => '',
    "recordsTotal" => '',
    "recordsFiltered" => '',
    "data" => $dataArray
);

header('Content-Type: application/json');
echo json_encode($tbldata);
