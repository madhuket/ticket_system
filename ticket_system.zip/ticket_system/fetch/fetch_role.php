<?php
include "../config.php";

$sql = "SELECT Id, Role FROM Roles WHERE IsDeleted = 0 OR IsDeleted IS NULL ORDER BY Id DESC;";
$result = sqlsrv_query($conn, $sql);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$dataArray = array();
$i = 1;
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
    $action = '<div class="btn-group dropdown">
        <a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-sm" data-bs-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-dots-horizontal"></i></a>
        <div class="dropdown-menu dropdown-menu-end">
        <a class="dropdown-item edit_role" href="javascript:void(0)" data-roleid="' . base64_encode($row['Id']) . '"><i class="mdi mdi-pencil me-2 text-muted font-18 vertical-middle"></i>Edit Role</a>
        <a class="dropdown-item remove_role" href="javascript:void(0)" data-roleid="' . base64_encode($row['Id']) . '"><i class="mdi mdi-delete me-2 text-muted font-18 vertical-middle"></i>Remove Role</a> 
        </div>
    </div>';

    //fetch permissions of role

    $perm_sql = "SELECT p.Permission
        FROM Permissions p
        JOIN RolePermissions rp ON p.Id = rp.Permission
        WHERE rp.Role = ?";

    $params = array($row['Id']);
    $stmt = sqlsrv_prepare($conn, $perm_sql, $params);
    sqlsrv_execute($stmt);
    // $rowcount = sqlsrv_has_rows($stmt); 

    $role_html = '';
    if (sqlsrv_has_rows($stmt)) {
        while ($perm_row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $permission = $perm_row['Permission'];
            // $permissionId = base64_encode($perm_row['Id']);
            $output =  htmlspecialchars($permission, ENT_QUOTES, 'UTF-8');
            $role_html .= '<span class="badge bg-primary me-1">' . $output . '</span>';
        }
    }

    $dataArray[] = array($i, $row['Role'], $role_html , $action);
    $i++;
}

sqlsrv_free_stmt($result);

$tbldata = array(
    "draw" => '',
    "recordsTotal" => '',
    "recordsFiltered" => '',
    "data" => $dataArray
);

header('Content-Type: application/json');
echo json_encode($tbldata);
