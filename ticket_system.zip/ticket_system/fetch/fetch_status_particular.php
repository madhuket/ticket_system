<?php
include "../config.php";

$status_id =  base64_decode($_POST['status_id']) ?? '';
if ($status_id != '') {
    $sql = "SELECT Id, Status, BaseStatus FROM Status WHERE Id = ? AND (IsDeleted = 0 OR IsDeleted IS NULL);";
    $params = array($status_id);

    $result = sqlsrv_query($conn, $sql, $params);

    if ($result === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);

    header('Content-Type: application/json');
    echo json_encode(array('Id' => base64_encode($row['Id']), 'TicketStatus' => htmlspecialchars_decode($row['Status']), 'BaseStatus' => $row['BaseStatus'], 'CsrfToken' => $_SESSION['csrf_token']));
}
