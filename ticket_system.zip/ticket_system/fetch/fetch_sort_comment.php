<?php
include("../config.php");

$TicketId = base64_decode($_POST['TicketId']) ?? '';
$SortBy = $_POST['SortBy'] ?? '';


if ($TicketId != '') {
    $SortBy = $SortBy == '1' ? 'DESC' : 'ASC';

    //Count total comments
    $countsql = "SELECT COUNT(Id) AS TotalComment FROM Comments WHERE TicketId = ? AND (IsDeleted = 0)";
    $countres = sqlsrv_query($conn, $countsql, array($TicketId));
    $cmtcount = 0;
    if ($countres !== false) {
        $cmt_count = sqlsrv_fetch_array($countres, SQLSRV_FETCH_ASSOC);
        $cmtcount = $cmt_count['TotalComment'];
    }

    if($user_login){
        $sql = "SELECT tc.Id, tc.Comment,tc.CommentBy,tc.CommentAt,u.Username AS UserName 
        FROM Comments tc 
        JOIN [Users] u ON tc.CommentBy = u.Id 
        WHERE tc.TicketId = ? AND (tc.IsDeleted = 0) 
        ORDER BY tc.Id " . $SortBy;  
    } else {
        $sql = "SELECT tc.Id, tc.Comment,tc.CommentBy,tc.CommentAt,CONCAT(u.FirstName,' ',u.LastName) AS UserName 
        FROM Comments tc 
        JOIN TenantUser u ON tc.CommentBy = u.Id 
        WHERE tc.TicketId = ? AND (tc.IsDeleted = 0) 
        ORDER BY tc.Id " . $SortBy;
    }

    $result = sqlsrv_query($conn, $sql, array($TicketId));

    if ($result === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $data = array();
    $html = '';
    $commentId = [];
    while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
        $row = stdToArray($row);
        $date = date_create($row['CommentAt']['date']);
        $date_time = date_format($date, "m/d/Y H:i A");

        $commentId[] = $row['Id'];

        $html .= '<div class="d-flex align-items-start mt-3"> 
            <div class="w-100">
                <h5 class="mt-0 mb-1">' . $row["UserName"] . '<small class="text-muted float-end">' . $date_time . '</small></h5>
                ' . $row['Comment'] . '
            </div>
        </div>';
    }

    header('Content-type:application/json');
    if (!empty($commentId)) {
        echo json_encode(array('html' => $html, 'more_records' => true));
    } else {
        echo json_encode(array('more_records' => false, 'comment_count' => $cmtcount));
    }

}
