<?php

include "../config.php";

$sql = "SELECT * FROM Ticketing_Categories WHERE Active = ?";

$stmt = sqlsrv_prepare($conn, $sql, array(1));

if ($stmt === false) {
  die(print_r(sqlsrv_errors(), true));
}

$result = sqlsrv_execute($stmt);

$dataArray = array();
if ($result && sqlsrv_has_rows($stmt)) {
  while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $dataArray[] = $row;
  }
}

sqlsrv_free_stmt($stmt);

header('Content-Type: application/json');
echo json_encode($dataArray);
