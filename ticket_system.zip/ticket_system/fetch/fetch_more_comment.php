<?php

include("../config.php");

$ticket_id = $_POST['ticket_id'];
$sort_by = $_POST['sort_by'];

if ($ticket_id != '') {
    $sort_by = $sort_by == '1' ? 'DESC' : 'ASC';

    $sql = "SELECT tc.Id, tc.Comment,tc.CommentBy,tc.CommentAt,u.Name AS UserName FROM TicketComments tc JOIN [User] u ON tc.CommentBy = u.Id WHERE tc.TicketId = ? AND (tc.IsDeleted = 0) ORDER BY tc.Id " . $sort_by . "";
    $result = sqlsrv_query($conn, $sql, array($ticket_id));

    if ($result === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $data = array();
    $html = '';
    $ticketId = [];
    while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
        $row = stdToArray($row);
        $date = date_create($row['CommentAt']['date']);
        $date_time = date_format($date, "m/d/Y H:i A");

        $ticketId[] = $row['Id'];

        $html .= '<div class="d-flex align-items-start mt-3">
            <a class="pe-2" href="#">
                <img src="assets/images/user-1.jpg" class="rounded-circle" alt="Generic placeholder image" height="32">
            </a>
            <div class="w-100">
                <h5 class="mt-0 mb-1">' . $row["UserName"] . '<small class="text-muted float-end">' . $date_time . '</small></h5>
                ' . $row['Comment'] . '
            </div>
        </div>';
    }

    header('Content-type:application/json');
    if (!empty($ticketId)) {
        $last_record_id = $ticketId[count($ticketId) - 1];

        echo json_encode(array('html' => $html, 'last_record_id' => $last_record_id, 'more_records' => true));
    } else {
        echo json_encode(array('more_records' => false));
    }


}
