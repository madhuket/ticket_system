<?php
include "../config.php";

$sql = "SELECT Id,TicketId,ModifiedBy,Data FROM TicketHistory;";
$result = sqlsrv_query($conn, $sql);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$data = array();
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {

    $data[] = [
        'id' => $row['Id'],
        'ticket_id' => $row['TicketId'],
        'modified_by' => $row['ModifiedBy'],
        'data' => $row['Data'],
    ];
}


sqlsrv_free_stmt($result);

header('Content-Type: application/json');
echo json_encode($data);
