<?php
include("../config.php");

$TicketId = base64_decode($_POST['TicketId']) ?? '';

$sql = "SELECT 
        tc.Id, 
        tc.Comment, 
        tc.CommentBy, 
        tc.CommentAt, 
        CASE 
            WHEN tc.IsTenantUser = 0 THEN u.Username
            ELSE CONCAT(tu.FirstName, ' ', tu.LastName)
        END AS UserName
    FROM 
        Comments tc
        LEFT JOIN [Users] u ON tc.IsTenantUser = 0 AND tc.CommentBy = u.Id
        LEFT JOIN TenantUser tu ON tc.IsTenantUser = 1 AND tc.CommentBy = tu.Id
    WHERE 
        tc.TicketId = ? 
        AND (tc.IsDeleted = 0 OR tc.IsDeleted IS NULL)
    ORDER BY 
        tc.Id DESC;";

$result = sqlsrv_query($conn, $sql, array($TicketId));

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$data = array();
$html = '';
$commentId = [];

while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
    $row = stdToArray($row);
    $date = date_create($row['CommentAt']['date']);
    $date_time = date_format($date, "m/d/Y H:i A");

    $commentId[] = $row['Id'];

    $html .= '<div class="d-flex align-items-start mt-3">
        <div class="w-100">
            <h5 class="mt-0 mb-1">' . $row["UserName"] . '<small class="text-muted float-end">' . $date_time . '</small></h5>
            ' . htmlspecialchars_decode($row['Comment']) . '
        </div>
    </div>';
}
$cmtcount = count($commentId);
header('Content-type:application/json');
if (!empty($cmtcount > 0)) {
    // $last_record_id = $commentId[count($commentId) - 1];
    echo json_encode(array('html' => $html, 'more_records' => true, 'comment_count' => $cmtcount));
} else {
    echo json_encode(array('more_records' => false, 'comment_count' => 0));
}


