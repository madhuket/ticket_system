<?php
include "header.php";

if(!(isset($_SESSION['is_superadmin']) && $_SESSION['is_superadmin'] == true)){
    header("Location: index.php");
    exit();
}
?>

<body>
    <?php include "sider.php"; ?>

    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right me-4">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>">Ticket Management</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/view_ticket.php">Tickets</a></li>
                                <li class="breadcrumb-item active">Permission</li>
                            </ol>
                        </div>
                        <h4 class="page-title ps-5">Permission</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" id="PermissionForm">
                                <input type='hidden' id="type" name="type" value="permission">
                                <input type="hidden" id="id" name="id" value="">
                                <input type="hidden" name="csrf_token" id="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="Permission" class="form-label">Permission<span class="req_star"> *</span></label>
                                            <input type="text" id="Permission" class="form-control" name="Permission" required>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="PermissionTag" class="form-label">Permission Tag<span class="req_star"> *</span></label>
                                            <input type="text" id="PermissionTag" class="form-control" name="PermissionTag" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="text-center d-flex justify-content-center">
                                        <div class="mt-3">
                                            <button type="submit" class="btn btn-primary" id="submit_form">Submit</button>
                                        </div>

                                        <div class="mt-3 ms-2">
                                            <button type="reset" class="btn btn-danger" id="reset_form">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tbl_permission">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Permission</th>
                                            <th>Permission Tag</th>
                                            <th class="hidden-sm">Action</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div><!-- end col -->
            </div>
            <!-- end row -->
        </div> <!-- container -->
    </div>

    

    <script>
        $(document).ready(function() {
            $("#reset_form").on("click", function () {
                $('#id').val('');

                $("#PermissionForm").find("label.error").remove();
                $("#PermissionForm").find(".error").removeClass("error");
            });

            $("#tbl_permission").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                },
                ajax: {
                    url: "fetch/fetch_permission.php"
                }
            });

            $('#PermissionForm').submit(function(e) {
                e.preventDefault();

                var isvalidForm = $(this).valid();
                if (isvalidForm) {
                    //disable button
                    $('#submit_form').attr('disabled', true);

                    var formData = $(this).serialize();
                    $.ajax({
                        type: 'POST',
                        url: 'store_data.php',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            if (response.success) {
                                $("#tbl_permission").DataTable().ajax.reload();
                                Swal.fire({
                                    title: "Permission added!",
                                    text: response.message,
                                    icon: "success"
                                });
                                $('#csrf_token').val(response.csrf_token);
                                $('#Permission').val('');
                                $('#PermissionTag').val('');
                                $('#id').val('');
                            } else {
                                Swal.fire({
                                    title: "Can't insert data",
                                    text: response.message,
                                    icon: "warning"
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            console.error("Error :", error);
                        },
                    });
                }
            });

            $(document).on("click", ".edit_permission", function() {
                var permission_id = $(this).data('permissionid');

                $.ajax({
                    type: 'POST',
                    url: 'fetch/fetch_permission_particular.php',
                    data: {
                        'permission_id': permission_id
                    },
                    dataType: 'json',
                    success: function(response) {
                        $('#PermissionTag').attr('readonly', 'readonly');
                        
                        $("#PermissionForm").find("label.error").remove();
                        $("#PermissionForm").find(".error").removeClass("error");
                        scrollToTop();
                        $('#csrf_token').val(response.csrf_token);
                        $('#Permission').val(response.Permission);
                        $('#PermissionTag').val(response.PermissionTag);
                        $('#id').val(response.Id);
                    }
                });
            });

            $(document).on("click", ".remove_permission", function() {
                var permission_id = $(this).data('permissionid');

                if(permission_id !== '' && permission_id !== null && permission_id !== undefined) {
                    Swal.fire({
                        title: "Are you sure?",
                        text: "You won't be able to revert this!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#3085d6",
                        cancelButtonColor: "#d33",
                        confirmButtonText: "Yes, delete it!"
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: 'delete_row.php',
                                type: 'POST',
                                data: {
                                    type: "permission",
                                    id: permission_id
                                },
                                dataType: "json",
                                success: function(response) {
                                    if (response.success) {
                                        $('#Permission').val('');
                                        $('#id').val('');
                                        $("#tbl_permission").DataTable().ajax.reload();
                                        Swal.fire({
                                            title: "Deleted!",
                                            text: response.message,
                                            icon: "success"
                                        });
                                    } else {
                                        Swal.fire({
                                            title: "Error!",
                                            text: response.message,
                                            icon: "warning"
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    alert("Error occurred while deleting row");
                                    console.error(xhr, status, error);
                                }
                            });
                        }
                    });
                } else{
                    Swal.fire({
                        title: "Error!",
                        text: "Permission Id is required",
                        icon: "warning",
                    });
                }
            });

            $("#PermissionForm").validate({
                rules: {
                    Permission: {
                        noSpecialChars: true,
                        maxlength: 100          // Max length rule
                    },
                    PermissionTag: {
                        required: true, // Make it mandatory
                        minlength: 3,   // Minimum length of 3 characters
                        maxlength: 20,  // Maximum length of 20 characters
                        pattern: /^[A-Z_]+$/ // Only uppercase letters and underscores
                    }
                },
                messages: {
                    PermissionTag: {
                        required: "Please enter a permission tag.",
                        minlength: "Permission tag must be at least 3 characters long.",
                        maxlength: "Permission tag cannot be longer than 20 characters.",
                        pattern: "Permission tag can only contain uppercase letters and underscores."
                    }
                }
            });

            // Custom validation method to check for special characters
            $.validator.addMethod("noSpecialChars", function(value, element) {
                return this.optional(element) || /^[a-zA-Z0-9\s]+$/.test(value);
            }, "Please enter only letters, numbers, and spaces.");
        });
    </script>

<?php include "footer.php" ?>

</body>

</html>