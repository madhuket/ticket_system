<?php include "header.php" ?>

<body>
    <?php include "sider.php" ?>

    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right me-4">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>">Ticket Management</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/view_ticket.php">Tickets</a></li>
                                <li class="breadcrumb-item active">Create Ticket Source</li>
                            </ol>
                        </div>
                        <h4 class="page-title ps-5">Create Ticket Source</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" action="index.php" class="create_ticket_source">
                                <input type="hidden" name="source" value="ISO Interface" />
                                <input type="hidden" name="source_url" value="" />

                                <div>
                                    <button type="submit" class="btn btn-primary">ISO Interface</button>
                                </div>
                            </form>

                            <form method="POST" action="index.php" class="create_ticket_source">
                                <input type="hidden" name="source" value="Merchant Support Center" />    
                                <input type="hidden" name="source_url" value="" />

                                <div class="mt-3">
                                    <button type="submit" class="btn btn-primary">Merchant Support Center</button>
                                </div>
                            </form>

                            <form method="POST" action="index.php" class="create_ticket_source">
                                <input type="hidden" name="source" value="ISO 360" />
                                <input type="hidden" name="source_url" value="" />

                                <div class="mt-3">
                                    <button type="submit" class="btn btn-primary">ISO 360</button>
                                </div>
                            </form>
                        </div>
                    </div> <!-- end card-->
                </div> <!-- end col -->
            </div>
        </div>

        <?php include "footer.php" ?>
        <script src="assets/js/pages/add_ticket.js"></script>

</body>

</html>