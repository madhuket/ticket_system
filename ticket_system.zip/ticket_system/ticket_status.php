<?php
include "header.php";
?>

<body>
    <?php include "sider.php"; ?>

    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right me-4">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>">Ticket Management</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/view_ticket.php">Tickets</a></li>
                                <li class="breadcrumb-item active">Ticket Status</li>
                            </ol>
                        </div>
                        <h4 class="page-title ps-5">Ticket Status</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->


            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" id="TicketStatus">
                                <input type='hidden' name="type" value="Status_of_Tickets">
                                <input type='hidden' name="id" id="id" value="">
                                <input type="hidden" name="csrf_token" id="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="Ticket_status" class="form-label">Title<span style="color: red;"> *</span></label>
                                            <input type="text" id="Ticket_status" class="form-control" name="Ticket_status" required>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="base_status" class="form-label">Base Status<span style="color: red;"> *</span></label>
                                            <select class="form-select" id="base_status" name="base_status" required>
                                                <option selected value="">Select a Base Status</option>
                                                <option value=0>Open</option>
                                                <option value=1>Close</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="text-center d-flex justify-content-center">
                                        <div class="mt-3">
                                            <button type="submit" class="btn btn-primary" id="submit_form">Submit</button>
                                        </div>

                                        <div class="mt-3 ms-2">
                                            <button type="reset" class="btn btn-danger" id="reset_form">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">

                            <div class="table-responsive">
                                <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="ticket_status-table">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Ticket Status</th>
                                            <th>Base Status</th>
                                            <th class="hidden-sm">Action</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div><!-- end col -->
            </div>
            <!-- end row -->

        </div> <!-- container -->

    </div>

    <script>
        $(document).ready(function() {
            $("#reset_form").on("click", function () {
                $('#id').val('');

                $("#TicketStatus").find("label.error").remove();
                $("#TicketStatus").find(".error").removeClass("error");
            });

            $('#TicketStatus').submit(function(e) {
                e.preventDefault();

                var isvalidForm = $(this).valid();
                if (isvalidForm) {
                    //disable button
                    $('#submit_form').attr('disabled', true);

                    var formData = $(this).serialize();
                    $.ajax({
                        type: 'POST',
                        url: 'store_data.php',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            if (response.success) {
                                Swal.fire({
                                    title: "Good job!",
                                    text: response.message,
                                    icon: "success"
                                });
                                $('#csrf_token').val(response.csrf_token);
                                $('#id').val('');
                                $('#Ticket_status').val('');
                                $('#base_status').val('');
                                $("#ticket_status-table").DataTable().ajax.reload();
                            } else {
                                Swal.fire({
                                    title: "Can't insert data",
                                    text: response.message,
                                    icon: "warning"
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            console.error("Error saving status:", error);
                        },
                    });
                }
            });

            $("#ticket_status-table").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                },
                ajax: {
                    url: "fetch/fetch_status.php"
                }
            });

            $(document).on("click", ".edit_sts", function() {
                var status_id = $(this).data('statusid');

                $.ajax({
                    type: 'POST',
                    url: 'fetch/fetch_status_particular.php',
                    data: {
                        'status_id': status_id
                    },
                    dataType: 'json',
                    success: function(response) {


                        $("#TicketStatus").find("label.error").remove();
                        $("#TicketStatus").find(".error").removeClass("error");

                        scrollToTop();
                        $('#Ticket_status').val(response.TicketStatus);
                        $('#base_status').val(response.BaseStatus);
                        $('#id').val(response.Id);
                        $('#csrf_token').val(response.CsrfToken);
                    }
                });
            });

            $(document).on("click", ".remove_sts", function() {
                var status_id = $(this).data('statusid');

                if(status_id !== '' && status_id !== null && status_id !== undefined) {
                    Swal.fire({
                        title: "Are you sure?",
                        text: "You won't be able to revert this!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#3085d6",
                        cancelButtonColor: "#d33",
                        confirmButtonText: "Yes, delete it!"
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: 'delete_row.php',
                                type: 'POST',
                                data: {
                                    type: "Status_of_Tickets",
                                    id: status_id
                                },
                                dataType: "json",
                                success: function(response) {
                                    if (response.success) {
                                        $('#Ticket_status').val('');
                                        $('#base_status').val('Select a Base Status');
                                        $("#ticket_status-table").DataTable().ajax.reload();
                                        Swal.fire({
                                            title: "Deleted!",
                                            text: response.message,
                                            icon: "success"
                                        });
                                    } else {
                                        Swal.fire({
                                            title: "Error!",
                                            text: response.message,
                                            icon: "warning"
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    alert("Error occurred while deleting row");
                                    console.error(xhr, status, error);
                                }
                            });
                        }
                    });
                }  else {
                    Swal.fire({
                        title: "Error!",
                        text: "Status Id is required",
                        icon: "warning",
                    });
                }
            });

            $("#TicketStatus").validate({
                rules: {
                    Ticket_status: {
                        noSpecialChars: true,
                        maxlength: 50          // Max length rule
                    }
                }    
            });

            // Custom validation method to check for special characters
            $.validator.addMethod("noSpecialChars", function(value, element) {
                return this.optional(element) || /^[a-zA-Z0-9\s]+$/.test(value);
            }, "Please enter only letters, numbers, and spaces.");
        });
    </script>

    <?php include "footer.php" ?>

</body>

</html>