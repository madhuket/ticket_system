<?php
include "connection.php";
include "ticket_function.php";

//Add common code in this file which can use in all files
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('X-Content-Type-Options: nosniff');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
header('Referrer-Policy: origin-when-cross-origin');
header("Access-Control-Allow-Origin: *");

session_start();
//set user id
if(isset($_SESSION['tenant_user_id'])){
    $user = $_SESSION['tenant_user_id'];
} else if(isset($_SESSION['userid'])){
    $user = $_SESSION['userid'];
}

$_SERVER['REQUEST_URI_PATH'] = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$segments = explode('/', $_SERVER['REQUEST_URI_PATH']);
$base_url = implode('/', array_slice($segments, 0, -1));

// Define the path to the attachments directory
$ticketDirPath = realpath(__DIR__ . '/../attachments') . '/';
$uploadTicketDir = str_replace('\\', '/', $ticketDirPath); 

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST']; 
$attachmentsDir = $protocol . $host .'/attachments/';
$ticketDir =  $attachmentsDir;

date_default_timezone_set('America/New_York');

$license_error = $_COOKIE['isValidateUrl'] ?? '';
$cookieAuthToken = $_COOKIE['AuthToken'] ?? '';
$sessionAuthToken = $_SESSION['AuthToken'] ?? '';
$tenant_url = $_SESSION['tenant_url'] ?? '';

// Generate a unique CSRF token if one doesn't exist
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Generate a random token
}

$validate_auth_token = false;
if($cookieAuthToken != '' && $sessionAuthToken != ''){
    if($cookieAuthToken == $sessionAuthToken){
        $validate_auth_token = true;
    }
}

$user_login = false;
//check is admin logged in
if (isset($_SESSION['user_login']) && $_SESSION['user_login'] === true) {
    // unset($_SESSION['tenant_url']);
    $user_login = $_SESSION['user_login'];
}

//check user permissions for valid license
if ((($license_error != 1) || (!$validate_auth_token)) && !$user_login && !$_SESSION['tenant_logout']) {
    header("Location: admin_login.php");
    exit();
} else if(isset($_SESSION['tenant_logout']) && ($_SESSION['tenant_logout'] == 1)) {
    unset($_SESSION['tenant_logout']);
    header("Location: $tenant_url");
    exit();
}

//fetch css content from license table
$css_content = '';
if (isset($_SESSION['license_id']) && $_SESSION['license_id'] !== '') {
    $license_id = $_SESSION['license_id'];
    $css_query = "SELECT CssContent FROM License WHERE Id = ? AND IsActive = ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";
    $params = array($license_id, 1);
    
    $stmt = sqlsrv_prepare($conn, $css_query, $params); 
    $result = sqlsrv_execute($stmt);

    if ($result !== false && sqlsrv_has_rows($stmt)) {
        $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

        if($row['CssContent'] !== ''){
            $css_content = $row['CssContent'];
        } else {
            $css_content = '';    
        }    
    }
}

$user_permissions = [];
if (isset($_SESSION['roleid']) && $_SESSION['roleid'] !== '') {
    // SQL to get permissions for the role
    $sql = "SELECT p.PermissionTag 
    FROM Permissions p
    JOIN RolePermissions rp ON p.Id = rp.Permission
    JOIN Roles r ON rp.Role = r.Id
    WHERE rp.Role = ?";

    $params = array($_SESSION['roleid']);

    $stmt = sqlsrv_prepare($conn, $sql, $params); 
    $result = sqlsrv_execute($stmt);

    if ($result !== false && sqlsrv_has_rows($stmt)) {
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $user_permissions[] = $row['PermissionTag'];
        }
    }

    $_SESSION['user_permissions'] = $user_permissions;
}
?>