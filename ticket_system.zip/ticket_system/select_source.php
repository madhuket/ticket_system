<?php
$sql = "SELECT Id,Source,SourceDetails FROM Source WHERE (IsDeleted = 0 OR IsDeleted IS NULL) ORDER BY Source";
$result = sqlsrv_query($conn, $sql);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

// $data = array();
$option_html = '';
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
    $option_html .= "<option value='" . base64_encode($row['Id']) . "'>" . htmlspecialchars_decode(htmlspecialchars($row['Source'], ENT_QUOTES, 'UTF-8')) . "</option>";
}

sqlsrv_free_stmt($result);

echo $option_html;
