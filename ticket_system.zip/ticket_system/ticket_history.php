<div class="content d-none" id="ticket_history">
    <!-- Start Content-->
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right me-4">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Ticket Management</a></li>
                            <li class="breadcrumb-item"><a href="view_ticket.php">Tickets</a></li>
                            <li class="breadcrumb-item active">Ticket History</li>
                        </ol>
                    </div>
                    <h4 class="page-title ps-5">Ticket History</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->

        <!-- end row -->
        <div class="row">

            <div class="col-12 px-0">
                <div class="card">
                    <div class="card-body">

                        <div class="table-responsive" id="tkt_history-table_wrapper">
                            <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tkt_history-table">
                                <thead>
                                    <tr>
                                        <th>Sr.No.</th>
                                        <th>Updated By</th>
                                        <th>User IP</th>
                                        <th>Updated At</th>
                                        <th>Operation</th>
                                        <th class="hidden-sm">View Hisory</th>
                                    </tr>
                                </thead>

                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->
        </div>
        <!-- end row -->

    </div> <!-- container -->

</div>

<!-- View History Details Modal Start -->
<div class="modal fade modal-xl" id="tktHistoryModal" tabindex="-1" aria-labelledby="tktHistoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-full-width">
        <div class="modal-content">
            <div class="modal-header modal-title-box">
                <h4 class="modal-title" id="tktHistoryModalLabel">Ticket History Data</h4>
                <button type="button" class="btn-close bg-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <h4 class="mt-0 text-center">Ticket Data</h4>
                        <hr />
                        <div class="actualTicket"></div>
                    </div>
                    <div class="col-md-6">
                        <h4 class="mt-0 text-center">History Data</h4>
                        <hr />
                        <div class="historyTicket"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- View History Details Modal End -->