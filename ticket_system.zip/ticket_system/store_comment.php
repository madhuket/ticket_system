<?php
include "config.php";

function validate($value)
{
    if (isset($value) && $value !== "") {
        if (preg_match("/\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE)\b/i", $value)) {
            echo json_encode(array('success' => false, 'message' => 'SQL keywords are not allowed!'));
            exit;
        } else if (preg_match("/\b(alert|prompt|confirm|script)\b/i", $value)) {
            echo json_encode(array('success' => false, 'message' => 'JavaScript keywords are not allowed!'));
            exit;
        } else if(strlen($value) > 255){
            echo json_encode(array('success' => false, 'message' => 'Comment cannot be more than 255 characters!'));
            exit;
        } else {
            return $value;
        }
    } else {
        echo json_encode(array('success' => false, 'message' => "You didn't fill the required fields!"));
        exit;
    }
}

if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    echo json_encode(array('success' => false, 'message' => "CSRF token validation failed."));
    exit();
}

$ticket_id = base64_decode($_POST['ticket_id']) ?? "";  //null collision operator for compatibility with old versions
$cur_date = date("Y-m-d H:i A");
$comment = validate(htmlspecialchars($_POST['comment'], ENT_QUOTES, 'UTF-8'));
$data = [];


$ipaddress = '';
if (getenv('HTTP_CLIENT_IP'))
    $ipaddress = getenv('HTTP_CLIENT_IP');
else if (getenv('HTTP_X_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
else if (getenv('HTTP_X_FORWARDED'))
    $ipaddress = getenv('HTTP_X_FORWARDED');
else if (getenv('HTTP_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_FORWARDED_FOR');
else if (getenv('HTTP_FORWARDED'))
    $ipaddress = getenv('HTTP_FORWARDED');
else if (getenv('REMOTE_ADDR'))
    $ipaddress = getenv('REMOTE_ADDR');
else
    $ipaddress = 'UNKNOWN';

$data_ip = $ipaddress;

if ($ticket_id != "") {
    if($user_login){
        $sql = "INSERT INTO Comments(TicketId, Comment, CommentBy, CommentAt, CommentIp, CreatedBy, IsTenantUser) VALUES (?, ?, ?, ?, ?, ?, ?);";
        $params = array(&$ticket_id, $comment, $user, $cur_date, $data_ip, $user, 0);
    } else {
        $sql = "INSERT INTO Comments(TicketId, Comment, CommentBy, CommentAt, CommentIp, CreatedBy, IsTenantUser) VALUES (?, ?, ?, ?, ?, ?, ?);";
        $params = array(&$ticket_id, $comment, $user, $cur_date, $data_ip, $user, 1);
    }
    $stmt = sqlsrv_prepare($conn, $sql, $params);

    if (sqlsrv_execute($stmt)) {
        //Count total comments
        $countsql = "SELECT COUNT(Id) AS TotalComment FROM Comments WHERE TicketId = ? AND (IsDeleted = 0)";
        $countres = sqlsrv_query($conn, $countsql, array($ticket_id));
        $cmtcount = 0;
        if ($countres !== false) {
            $cmt_count = sqlsrv_fetch_array($countres, SQLSRV_FETCH_ASSOC);
            $cmtcount = $cmt_count['TotalComment'];
        }

        $sql_last_id = "SELECT TOP 1 Id AS LastRecordID FROM Comments ORDER BY Id DESC";
        $stmt_last_id = sqlsrv_prepare($conn, $sql_last_id);
        if (sqlsrv_execute($stmt_last_id)) {
            $row = sqlsrv_fetch_array($stmt_last_id, SQLSRV_FETCH_ASSOC);
            $last_inserted_id = $row['LastRecordID'];
        }

        $sql = "SELECT TOP 1
                tc.Id, 
                tc.Comment, 
                tc.CommentBy, 
                tc.CommentAt, 
                CASE 
                    WHEN tc.IsTenantUser = 0 THEN u.Username
                    ELSE CONCAT(tu.FirstName, ' ', tu.LastName)
                END AS UserName
            FROM 
                Comments tc
                LEFT JOIN [Users] u ON tc.IsTenantUser = 0 AND tc.CommentBy = u.Id
                LEFT JOIN TenantUser tu ON tc.IsTenantUser = 1 AND tc.CommentBy = tu.Id
            WHERE 
                tc.TicketId = ? 
                AND (tc.IsDeleted = 0 OR tc.IsDeleted IS NULL)
            ORDER BY 
                tc.Id DESC;";

        $result = sqlsrv_query($conn, $comment_sql, array($last_inserted_id));

        if ($result === false) {
            die(print_r(sqlsrv_errors(), true));
        }

        $html = '';
        while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
            $row = stdToArray($row);

            $date = date_create($row['CommentAt']['date']);
            $date_time = date_format($date, "m/d/Y H:i A");

            $html .= '<div class="d-flex align-items-start mt-3">
                <div class="w-100">
                    <h5 class="mt-0 mb-1">' . $row["UserName"] . '<small class="text-muted float-end">' . $date_time . '</small></h5>
                    ' . $row['Comment'] . '
                </div>
            </div>';
        }

        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        header('Content-type:application/json');
        echo json_encode(array('success' => true, 'html' => $html, 'comment_count' => $cmtcount, 'csrf_token' => $_SESSION['csrf_token']));
    } else {
        echo "Error: " . print_r(sqlsrv_errors(), true);

        echo json_encode(array('success' => false, 'message' => "Error: " . print_r(sqlsrv_errors(), true)));
    }
}
