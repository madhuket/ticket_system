$(document).ready(function () {
  //fetch session and cookie data from server using ajax

  $.ajax({
    url: "get_session.php",
    type: "GET",
    dataType: "json",
    success: function (data) {
      //process the session and cookie data here
      if ((data.isvalid_license) || (data.user_login)) {
        fetch_category();

        //show autoselected source when page is redirected from tenant url
        if(data.tenant_id !== ''){
          $('#select_source').val(data.tenant_id);
        }
      } else {
        // redirect to referrer page
        if(data.tenant_url != ''){
          window.location.href = data.tenant_url;
        }
      }
    },
    error: function (xhr, status, error) {
      console.log(xhr.responseText);
    },
  });

  var globalCategory = [];
  function fetch_category() {
    //fetch categories
    $.ajax({
      url: "fetch/fetch_categories.php",
      type: "GET",
      datatype: "json",
      success: function (response) {
        globalCategory = response;

        var departments = [];
        var deptHtml = '<option value="" selected>Select Department</option>';
        $.each(globalCategory, function (index, category) {
          if ($.inArray(category.Department, departments) === -1) {
            departments.push(category.Department);
            deptHtml +=
              '<option value="' +
              category.Department +
              '">' +
              category.Department +
              "</option>";
          }
        });
        $("#department").html(deptHtml);
      },
      error: function (xhr, status, error) {
        alert("Error occurred while fetching categories");
        console.error(xhr, status, error);
      },
    });
  }

  $("#create_ticket_form").submit(function (e) {
    e.preventDefault(); //prevent default action

    //check uploaded multiple files size it should be upto 2mb
    var fileInput = $(".file-input")[0];
    var fileLength = fileInput.files.length;
    if (fileLength > 0) {
      var error_cnt = 0;
      for (var i = 0; i < fileLength; i++) {
        var file = fileInput.files[i];

        if (file.size > 2097152) {
          error_cnt++;
        }
      }
      if (error_cnt > 0) {
        $("#attachments-error").removeClass("d-none");
        $("#attachments-error").text(
          "File too large. File must be less than 2 MB."
        );
        return false;
      } else {
        error_cnt = 0;
        $("#attachments-error").addClass("d-none");
      }
    }

    //check uploaded file type it should be jpg, jpeg, png, pdf, txt, doc, docx
    var fileInput = $(".file-input")[0];
    var fileLength = fileInput.files.length;
    if (fileLength > 0) {
      var error_cnt = 0;
      var allowedExtensions = /\.(jpg|jpeg|png|pdf|txt|doc|docx)$/i;

      for (var i = 0; i < fileLength; i++) {
        var file = fileInput.files[i];
        
        if (!allowedExtensions.exec(file.name)) {
          error_cnt++;
        }
      }
      
      if (error_cnt > 0) {
        $("#attachments-error").removeClass("d-none");
        $("#attachments-error").text(
          "Only jpg, jpeg, png, pdf, txt, doc, docx files are allowed"
        );
        return false;
      } else {
        $("#attachments-error").addClass("d-none");
      }
    }

    var isvalidForm = $(this).valid();
    if (isvalidForm) {
      $("#create_ticket_form :disabled").removeAttr("disabled");
      var formData = new FormData(this);

      $.ajax({
        type: "POST",
        url: "store_data.php",
        data: formData,
        contentType: false,
        processData: false,
        cache: false,
        dataType: "json",
        success: function (response) {
          if (response.success) {
            Swal.fire({
              title: "Good job!",
              text: response.message,
              icon: "success",
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.href = `view_ticket.php`;
              }
            });
          } else {
            $("#select_status").prop("disabled", true);
            Swal.fire({
              title: "Error!",
              text: response.message,
              icon: "warning",
            });
          }
        },
      });
    }
  });

  // File upload start
  $(document).on("change", ".file-input", function () {
    var filesCount = $(this)[0].files.length;
    var textbox = $(this).prev();

    if (filesCount === 1) {
      var fileName = $(this).val().split("\\").pop();
      textbox.text(fileName);
    } else {
      textbox.text(filesCount + " files selected");
    }
  });
  // File upload end

  // Custom validation method
  $.validator.addMethod(
    "emailOrMobile",
    function (value, element) {
      var emailPattern = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
      var mobilePattern = /^[0-9]{10}$/; // Assuming a 10-digit mobile number
      return (
        this.optional(element) ||
        emailPattern.test(value) ||
        mobilePattern.test(value)
      );
    },
    "Please enter a valid email address or mobile number."
  );

  //form validate
  $("#create_ticket_form").validate({
    rules: {
      follow_up_at: {
        emailOrMobile: true,
      },
      reported_by: {
        lettersonly: true // Custom validation to allow only alphabetic characters
      },
    },
    messages: {
      follow_up_at: {
        emailOrMobile: "Please enter a valid email address or mobile number.",
      },
      reported_by: {
        lettersonly: "Please enter only alphabetic characters.",
      },
    },
  });

  // Custom method to allow only alphabetic characters
  jQuery.validator.addMethod("lettersonly", function(value, element) {
    return this.optional(element) || /^[a-zA-Z\s]+$/.test(value);
  }, "Please enter only letters.");

  //reset file input
  $("#reset_form").on("click", function () {
    // $("#file-input").val("");
    $("#create_ticket_form").find("label.error").remove();
    // $("#create_ticket_form").find("").remove();

    $("#create_ticket_form").find(".error").removeClass("error");
    $(".file-drop-area")
      .find(".file-message")
      .text("or drag and drop files here");
  });

  //restrict datepicker to select previous date from today
  $("#next_follow_up_date").datepicker({
    startDate: new Date(), // Set start date to today
    autoclose: true, // Automatically close the datepicker after date selection
    todayHighlight: true, // Highlight today's date
  });
  // .datepicker("setDate", new Date());

  //fetch parent
  $("#department").on("change", function () {
    var department = $(this).val();
    var parents = [];
    var parentHtml = '<option value="" selected>Select Parent</option>';
    $.each(globalCategory, function (index, category) {
      if (
        category.Department === department &&
        $.inArray(category.Parent, parents) === -1 &&
        (category.Parent != null || category.Parent != "") 
      ) {
        parents.push(category.Parent);
        parentHtml +=
          '<option value="' +
          category.Parent +
          '">' +
          category.Parent +
          "</option>";
      }
    });
    $("#parent").html(parentHtml);
    $("#parent").val("").trigger("change");
  });

  //fetch child
  $("#parent").on("change", function () {
    $("#child, #sub_child_1, #sub_child_2, #sub_child_3, #sub_child_4").val("");
    $(
      ".child_div, .sub_child_1_div, .sub_child_2_div, .sub_child_3_div, .sub_child_4_div"
    ).addClass("d-none");

    var parent = $(this).val();

    var childs = [];
    var childHtml = '<option value="" selected>Select Child</option>';
    $.each(globalCategory, function (index, category) {
      

      if (
        category.Parent === parent &&
        $.inArray(category.Child, childs) === -1 &&
        (category.Child != null && category.Child != "")
      ) {
        childs.push(category.Child);
        childHtml +=
          '<option value="' +
          category.Child +
          '">' +
          category.Child +
          "</option>";
      }
    });
    if (childs.length > 0) {
      $(".child_div").removeClass("d-none");
      $("#child").html(childHtml);
      $("#child").val("").trigger("change");
    }
  });

  //fetch subchild1
  $("#child").on("change", function () {
    $("#sub_child_1, #sub_child_2, #sub_child_3, #sub_child_4").val("");
    $(
      ".sub_child_1_div, .sub_child_2_div, .sub_child_3_div, .sub_child_4_div"
    ).addClass("d-none");

    var child = $(this).val();

    var subchild1 = [];
    var subchild1Html = '<option value="" selected>Select Sub Child 1</option>';
    $.each(globalCategory, function (index, category) {
      if (
        category.Child === child &&
        $.inArray(category.Sub_Child_1, subchild1) === -1 &&
        (category.Sub_Child_1 != null && category.Sub_Child_1 != "")
      ) {
        subchild1.push(category.Sub_Child_1);
        subchild1Html +=
          '<option value="' +
          category.Sub_Child_1 +
          '">' +
          category.Sub_Child_1 +
          "</option>";
      }
    });

    if (subchild1.length > 0) {
      $(".sub_child_1_div").removeClass("d-none");
      $("#sub_child_1").html(subchild1Html);
      $("#sub_child_1").val("").trigger("change");
    }
  });

  //fetch subchild2
  $("#sub_child_1").on("change", function () {
    $("#sub_child_2, #sub_child_3, #sub_child_4").val("");
    $(".sub_child_2_div, .sub_child_3_div, .sub_child_4_div").addClass(
      "d-none"
    );

    var sub_child_1 = $(this).val();

    var subchild2 = [];
    var subchild2Html = '<option value="" selected>Select Sub Child 2</option>';
    $.each(globalCategory, function (index, category) {
      if (
        category.Sub_Child_1 === sub_child_1 &&
        $.inArray(category.Sub_Child_2, subchild2) === -1 &&
        (category.Sub_Child_2 != null && category.Sub_Child_2 != "")
      ) {
        subchild2.push(category.Sub_Child_2);
        subchild2Html +=
          '<option value="' +
          category.Sub_Child_2 +
          '">' +
          category.Sub_Child_2 +
          "</option>";
      }
    });

    if (subchild2.length > 0) {
      $(".sub_child_2_div").removeClass("d-none");
      $("#sub_child_2").html(subchild2Html);
      $("#sub_child_2").val("").trigger("change");
    }
  });

  //fetch subchild3
  $("#sub_child_2").on("change", function () {
    $("#sub_child_3, #sub_child_4").val("");
    $(".sub_child_3_div, .sub_child_4_div").addClass("d-none");

    var sub_child_2 = $(this).val();
    var subchild3 = [];
    var subchild3Html = '<option value="" selected>Select Sub Child 3</option>';
    $.each(globalCategory, function (index, category) {
      if (
        category.Sub_Child_2 === sub_child_2 &&
        $.inArray(category.Sub_Child_3, subchild3) === -1 &&
        (category.Sub_Child_3 != null && category.Sub_Child_3 != "")
      ) {
        subchild3.push(category.Sub_Child_3);
        subchild3Html +=
          '<option value="' +
          category.Sub_Child_3 +
          '">' +
          category.Sub_Child_3 +
          "</option>";
      }
    });

    if (subchild3.length > 0) {
      $(".sub_child_3_div").removeClass("d-none");
      $("#sub_child_3").html(subchild3Html);
      $("#sub_child_3").val("").trigger("change");
    }
  });

  //fetch subchild4
  $("#sub_child_3").on("change", function () {
    $("#sub_child_4").val("");
    $(".sub_child_4_div").addClass("d-none");

    var sub_child_3 = $(this).val();
    var subchild4 = [];
    var subchild4Html = '<option value="" selected>Select Sub Child 4</option>';
    $.each(globalCategory, function (index, category) {
      if (
        category.Sub_Child_3 === sub_child_3 &&
        $.inArray(category.Sub_Child_4, subchild4) === -1 &&
        (category.Sub_Child_4 != null && category.Sub_Child_4 != "")
      ) {
        subchild4.push(category.Sub_Child_4);
        subchild4Html +=
          '<option value="' +
          category.Sub_Child_4 +
          '">' +
          category.Sub_Child_4 +
          "</option>";
      }
    });

    if (subchild4.length > 0) {
      $(".sub_child_4_div").removeClass("d-none");
      $("#sub_child_4").html(subchild4Html);
    }
  });
});
