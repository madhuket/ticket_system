$(document).ready(function () {
  //fetch session and cookie data from server using ajax
  $.ajax({
    url: "get_session.php",
    type: "GET",
    dataType: "json",
    success: function (data) {
      //process the session and cookie data here
      if ((data.isvalid_license) || (data.user_login)) {
        fetch_category();
      } else {
        // redirect to referrer page
        if(data.tenant_url != ''){
          window.location.href = data.tenant_url;
        }
      }
    },
    error: function (xhr, status, error) {
      console.log(xhr.responseText);
    },
  });

  var isEditTicket = false;
  var autoSaveInterval;

  $(document).on("click", ".edit_tkt", function () {
    var TicketId = $(this).data("ticketid");

    $("#ticket_detail").addClass("d-none");
    $("#ticket_history").addClass("d-none");
    isEditTicket = true;
    fetch_draft(TicketId);
  });

  function fetch_draft(TicketId) {
    $.ajax({
      url: "fetch/fetch_draft.php",
      type: "POST",
      dataType: "json",
      data: {
        TicketId: TicketId,
      },
      success: function (response) {
        var ticketdata = response.DraftData;
        $("#ed_ticket_title").val(ticketdata.Title);
        $("#ed_select_source").val(response.SelectSource);
        $("#ed_reported_by").val(ticketdata.ReportedBy);
        $("#ed_department").val(response.Department).trigger("change");
        $("#ed_parent").val(response.Parent).trigger("change");
        $("#ed_child").val(response.Child).trigger("change");
        $("#ed_sub_child_1").val(response.Sub_Child_1).trigger("change");
        $("#ed_sub_child_2").val(response.Sub_Child_2).trigger("change");
        $("#ed_sub_child_3").val(response.Sub_Child_3).trigger("change");
        $("#ed_sub_child_4").val(response.Sub_Child_4);
        $("#ed_priority").val(response.SelectPriority);
        $("#ed_select_status").val(response.SelectStatus);
        $("#ed_case_details").val(response.CaseDetails);
        $("#ed_immediate_action_taken").val(response.ImmediateActionTaken);
        $("#ed_follow_up_at").val(ticketdata.FollowUpAt);
        $("#ed_next_follow_up_date").val(response.NextFollowUpDate);
        $("#ed_ticket_id").val(TicketId);
        $("#ticket_id").val(TicketId);

        $("#source_url").val(response.SourceUrl);
        $("#tenant_id").val(response.SelectSource);
        $("#ed_csrf_token, #csrf_token").val(response.CsrfToken);

        $("#ed_source").html(
          '<span class="h5">Source: </span>' + response.Source
        );
        $("#ed_source_url").html(
          '<span class="h5">Source URL: </span>' + response.SourceUrl
        );

        //restrict datepicker to select previous date from today
        $("#ed_next_follow_up_date").datepicker({
          autoclose: true, // Automatically close the datepicker after date selection
          todayHighlight: true, // Highlight today's date

          beforeShowDay: function(date) {
            var today = new Date();
            // Disable all dates before today
            return date >= today ? true : false;
          }
        });

        if (response.ModifiedAt != "") {
          $(".last_draft_div").removeClass("d-none");
          $(".draft_date").text(response.ModifiedAt);
        } else {
          $(".last_draft_div").addClass("d-none");
        }

        attachments = response.Attachments;
        var fileList = "";
        $.each(attachments, function (index, ticketFile) {
          var file_extension = ticketFile.split(".").pop();

          fileList +=
            '<div class="card mb-1 shadow-none border file-div">\
                            <div class="p-2">\
                                <div class="row align-items-center">\
                                    <div class="col-auto">\
                                        <div class="avatar-sm">\
                                            <span class="avatar-title badge-soft-primary text-primary rounded">\
                                                ' +
            file_extension +
            '\
                                            </span>\
                                        </div>\
                                    </div>\
                                    <div class="col ps-0">\
                                        <a href="download_ticket_file.php?file=' + ticketFile + '" class="text-muted fw-bold filelink" target="_blank">' +
            ticketFile +
            '</a>\
                                    </div>\
                                    <div class="col-auto">\
                                        <a href="download_ticket_file.php?file=' + ticketFile + '" class="btn btn-link font-16 text-muted" target="_blank">\
                                            <i class="mdi mdi-download"></i>\
                                        </a>\
                                        <a href="javascript:void(0);" class="font-16 text-danger delete-file">\
                                            <i class="mdi mdi-delete"></i>\
                                        </a>\
                                    </div>\
                                </div>\
                            </div>\
                        </div>';
        });
        $(".edit_attachments_list").html(fileList);
        $("#ticket_list").addClass("d-none");
        $("#edit_ticket").removeClass("d-none");

        if (isEditTicket && !autoSaveInterval) {
          autoSaveInterval = setInterval(function () {
            autoSave();
          }, 5000);
        }

        fetchComment(TicketId);
      },
      error: function (xhr, status, error) {
        alert("Error occurred on edit");
        console.error(xhr, status, error);
      },
    });
    scrollToTop();
  }

  $(document).on("click", ".ticket_details", function () {
    var TicketId = $(this).data("ticketid");
    $("#ticket_list").addClass("d-none");
    $("#ticket_detail").removeClass("d-none");
    fetch_ticket_details(TicketId);

    isEditTicket = false;
    clearInterval(autoSaveInterval);
    autoSaveInterval = null;
  });

  $("#comment-form").submit(function (e) {
    e.preventDefault();

    var isvalidForm = $(this).valid();
    if (isvalidForm) {
      var ticket_id = $("#ticket_id").val();
      var comment = $("#comment").val();
      var csrf_token = $("#cmt_csrf_token").val();

      //disabled add-comment button
      $(".add-comment").prop("disabled", true);  
      $.ajax({
        type: "POST",
        url: "store_comment.php",
        data: {
          ticket_id: ticket_id,
          comment: comment,
          csrf_token: csrf_token
        },
        dataType: "json",
        success: function (response) {
          //remove disabled add-comment button
          $(".add-comment").prop("disabled", false);
          if (response.success) {
            $("#cmt_csrf_token").val(response.csrf_token);
            $("#comment").val("");
            $(".comment_area").prepend(response.html);
            $(".comment_count").text("Comment (" + response.comment_count + ")");
            if (response.comment_count > 4) {
              $(".comment_area").addClass("comment_scroll");
            }

            Swal.fire({
              title: "Comment added!",
              text: response.message,
              icon: "success"
            });
          } else {
            Swal.fire({
              title: "Can't insert data",
              text: response.message,
              icon: "warning"
            });
          }
        },
        error: function (xhr, status, error) {
          console.error("Error saving comment:", error);
        },
      });
    }
  });

  $("#ed_comment-form").submit(function (e) {
    e.preventDefault();
    var isvalidForm = $(this).valid();
    if (isvalidForm) {
      var ticket_id = $("#ed_ticket_id").val();
      var comment = $("#ed_comment").val();
      var csrf_token = $("#ed_csrf_token").val();
      //disabled add-comment button
      $(".ed_add-comment").prop("disabled", true);
      if(ticket_id !== ''){
        $.ajax({
          type: "POST",
          url: "store_comment.php",
          data: {
            ticket_id: ticket_id,
            comment: comment,
            csrf_token: csrf_token
          },
          dataType: "json",
          success: function (response) {
            //remove disabled add-comment button
            $(".ed_add-comment").prop("disabled", false);
            if (response.success) {
              $("#ed_csrf_token, #csrf_token").val(response.csrf_token);
              $("#ed_comment").val("");
              $(".comment_area").prepend(response.html);
              $(".comment_count").text("Comment (" + response.comment_count + ")");
              if (response.comment_count > 4) {
                $(".comment_area").addClass("comment_scroll");
              }  
              
              Swal.fire({
                  title: "Comment added!",
                  text: response.message,
                  icon: "success"
              });
            } else {
              Swal.fire({
                title: "Can't insert data",
                text: response.message,
                icon: "warning"
              });
            }
          },
          error: function (xhr, status, error) {
            console.error("Error saving comment:", error);
          },
        });
      }
    }
  });

  // Load more comments
  $(document).on("click", ".load-more-comment", function () {
    $(this).html('<i class="mdi mdi-spin mdi-loading me-1"></i> Load More');

    var ticket_id = $("#ticket_id").val();
    var sort_by = $(".comment_sort").val();

    $.ajax({
      url: "fetch/fetch_more_comment.php",
      type: "POST",
      datatype: "json",
      data: {
        ticket_id: ticket_id,
        sort_by: sort_by,
      },
      success: function (response) {
        $(".load-more-comment").html("Load More");
        if (response.more_records) {
          $(".comment_area").addClass("comment_scroll");
          $(".comment_area").append(response.html);
        } else {
          $(".load-more-comment").css("display", "none");
        }
      },
      error: function (xhr, status, error) {
        alert("Error occurred on edit");
        console.error(xhr, status, error);
      },
    });
  });

  $(document).on("click", ".comment_sort", function () {
    var ticket_id = $("#ticket_id").val();
    var sort_by = $(this).val();

    $.ajax({
      url: "fetch/fetch_sort_comment.php",
      type: "POST",
      datatype: "json",
      data: {
        TicketId: ticket_id,
        SortBy: sort_by,
      },
      success: function (response) {
        $(".load-more-comment").html("Load More");
        if (response.more_records) {
          $(".comment_area").html(response.html);
        } else {
          $(".load-more-comment").css("display", "none");
        }
      },
      error: function (xhr, status, error) {
        alert("Error occurred on edit");
        console.error(xhr, status, error);
      },
    });
  });

  $("#edit_ticket_form").submit(function (e) {
    e.preventDefault();
    //check uploaded file size it should be upto 2mb
    var fileInput = $(".file-input")[0];
    var fileLength = fileInput.files.length;
    if (fileLength > 0) {
      var error_cnt = 0;
      for (var i = 0; i < fileLength; i++) {
        var file = fileInput.files[i];

        if (file.size > 2097152) {
          error_cnt++;
        }
      }

      if (error_cnt > 0) {
        $("#attachments-error").removeClass("d-none");
        $("#attachments-error").text(
          "File too large. File must be less than 2 MB."
        );
        return false;
      } else {
        error_cnt = 0;
        $("#attachments-error").addClass("d-none");
      }
    }

    //check uploaded file type it should be jpg, jpeg, png, pdf, txt, doc, docx
    var fileInput = $(".file-input")[0];
    var fileLength = fileInput.files.length;
    if (fileLength > 0) {
      var error_cnt = 0;
      var allowedExtensions = /\.(jpg|jpeg|png|pdf|txt|doc|docx)$/i;

      for (var i = 0; i < fileLength; i++) {
        var file = fileInput.files[i];
        
        if (!allowedExtensions.exec(file.name)) {
          error_cnt++;
        }
      }
      
      if (error_cnt > 0) {
        $("#attachments-error").removeClass("d-none");
        $("#attachments-error").text(
          "Only jpg, jpeg, png, pdf, txt, doc, docx files are allowed"
        );
        return false;
      } else {
        $("#attachments-error").addClass("d-none");
      }
    }

    var isvalidForm = $(this).valid();
    if (isvalidForm) {
      isEditTicket = false;
      clearInterval(autoSaveInterval);
      autoSaveInterval = null;

      // $("#edit_ticket_form :disabled").removeAttr("disabled");
      var formData = new FormData(this);
      $.ajax({
        type: "POST",
        url: "store_data.php",
        data: formData,
        contentType: false,
        processData: false,
        cache: false,
        dataType: "json",
        success: function (response) {
          if (response.success) {
            Swal.fire({
              title: "Good job!",
              text: response.message,
              icon: "success",
            });
            $(".file-input").val("");
            $(".file-drop-area")
              .find(".file-message")
              .text("or drag and drop files here");
            $("#tickets-table").DataTable().ajax.reload();
            $("#ticket_list").removeClass("d-none");
            $("#edit_ticket").addClass("d-none");
            
          } else {
            $("#select_status").prop("disabled", true);
            Swal.fire({
              title: "Error!",
              text: response.message,
              icon: "warning",
            });
          }
        },
      });
    }
  });

  $(document).on("click", ".remove_tkt", function () {
    isEditTicket = false;
    clearInterval(autoSaveInterval);
    autoSaveInterval = null;
    var TicketId = $(this).data("ticketid");

    if(TicketId !== '' && TicketId !== null && TicketId !== undefined) {
      Swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!",
      }).then((result) => {
        if (result.isConfirmed) {
          $.ajax({
            url: "delete_row.php",
            type: "POST",
            data: {
              type: "ticket_and_particular",
              id: TicketId,
            },
            dataType: "json",
            success: function (response) {
              if (response.success) {
                Swal.fire({
                  title: "Deleted!",
                  text: response.message,
                  icon: "success",
                });
                $("#tickets-table").DataTable().ajax.reload();
              } else {
                Swal.fire({
                  title: "Error!",
                  text: response.message,
                  icon: "warning",
                });
              }
            },
            error: function (xhr, status, error) {
              alert("Error occurred while deleting row");
              console.error(xhr, status, error);
            },
          });
        }
      });
    } else {
      Swal.fire({
        title: "Error!",
        text: "Ticket Id is required",
        icon: "warning",
      });
    }
  });

  //Delete ticket file
  $(document).on("click", ".delete-file", function () {
    var thisFile = $(this).parents(".file-div");

    Swal.fire({
      title: "Are you sure to delete file?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        thisFile.remove();
        var fileName = $(this).parents(".file-div").find(".filelink").text();
        var ticket_id = $("#ticket_id").val();

        var file_arr = [];
        $(".file-div")
          .find(".filelink")
          .each(function () {
            file_arr.push($(this).text());
          });

        $.ajax({
          url: "delete_file.php",
          type: "POST",
          datatype: "json",
          data: {
            ticket_id: ticket_id,
            fileName: fileName,
            Attachments: file_arr,
          },
          success: function (response) {
            if (response.status) {
              const Toast = Swal.mixin({
                toast: true,
                position: "bottom-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                  toast.onmouseenter = Swal.stopTimer;
                  toast.onmouseleave = Swal.resumeTimer;
                },
              });
              Toast.fire({
                icon: "success",
                title: response.message,
              });
            } else {
              const Toast = Swal.mixin({
                toast: true,
                position: "bottom-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                  toast.onmouseenter = Swal.stopTimer;
                  toast.onmouseleave = Swal.resumeTimer;
                },
              });
              Toast.fire({
                icon: "error",
                title: response.message,
              });
            }
          },
          error: function (xhr, status, error) {
            alert("Error occurred while deleting row");
            console.error(xhr, status, error);
          },
        });
      }
    });
  });

  //Fetch ticket history list
  $(document).on("click", ".ticket_history", function () {
    isEditTicket = false;
    clearInterval(autoSaveInterval);
    autoSaveInterval = null;

    var TicketId = $(this).data("ticketid");
    $("#tkt_history-table").dataTable().fnDestroy();

    $.ajax({
      url: "fetch/fetch_ticket_history.php",
      type: "POST",
      data: {
        Id: TicketId,
      },
      datatype: "html",
      success: function (response) {
        $("#ticket_list").addClass("d-none");
        $("#ticket_history").removeClass("d-none");
        $("#tkt_history-table").find("tbody").html(response);
        
        $("#tkt_history-table").DataTable({
          language: {
            paginate: {
              previous: "<i class='mdi mdi-chevron-left'>",
              next: "<i class='mdi mdi-chevron-right'>",
            },
          },
          // dom: 'lfr<"backlinkdiv">',
        /**
         * Callback function to apply classes on pagination and length label
         * after DataTables has redrawn the table
         */
          drawCallback: function () {
            $(".dataTables_paginate > .pagination").addClass(
              "pagination-rounded"
            );
            $(".dataTables_length label").addClass("form-label");
          },
        });

        //Back link
        $("#tkt_history-table_filter").addClass('d-flex align-items-center justify-content-between');
        $("#tkt_history-table_filter").css('flex-direction', 'row-reverse');

        $("#tkt_history-table_filter").append(
          '<div class="history_back_link d-flex align-items-center"><a href="javascript:void(0)" class="btn btn-sm btn-link history_back d-flex align-items-center"><i class="mdi mdi-keyboard-backspace"></i>Back</a></div>'
        );
      },
      
      /**
       * Error callback for fetching ticket history
       * @param {Object} xhr - The jqXHR object
       * @param {String} status - The status of the request
       * @param {String} error - The error message
       * @returns {undefined}
       */
      error: function (xhr, status, error) {
        alert("Error occurred while fetching ticket history");
        console.error(xhr, status, error);
      },
    });
  });

  //Fetch ticket history data
  $(document).on("click", ".history_details", function () {
    isEditTicket = false;
    clearInterval(autoSaveInterval);
    autoSaveInterval = null;

    var history_id = $(this).data("historyid");
    var ticket_id = $(this).data("ticketid");

    $.ajax({
      url: "fetch/fetch_history_data.php",
      type: "POST",
      data: {
        Id: history_id,
        TicketId: ticket_id,
      },
      success: function (response) {
        if (response.historyHtml != "") {
          $(".actualTicket").html(response.actualTicketHtml);
        }

        if (response.historyTicketHtml != "") {
          $(".historyTicket").html(response.historyTicketHtml);
        }
      },
      error: function (xhr, status, error) {
        alert("Error occurred while fetching ticket history details");
        console.error(xhr, status, error);
      },
    });
  });

  $("#tickets-table").DataTable({
    language: {
      paginate: {
        previous: "<i class='mdi mdi-chevron-left'>",
        next: "<i class='mdi mdi-chevron-right'>",
      },
    },
    drawCallback: function () {
      $(".dataTables_paginate > .pagination").addClass("pagination-rounded");

      // Initialize Bootstrap tooltips
      $('[data-bs-toggle="tooltip"]').tooltip();
    },
    ajax: {
      url: "fetch/fetch_all_ticket.php",
    },
  });

  // Custom validation method
  $.validator.addMethod(
    "emailOrMobile",
    function (value, element) {
      var emailPattern = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
      var mobilePattern = /^[0-9]{10}$/; // Assuming a 10-digit mobile number
      return (
        this.optional(element) ||
        emailPattern.test(value) ||
        mobilePattern.test(value)
      );
    },
    "Please enter a valid email address or mobile number."
  );

  //form validate
  $("#edit_ticket_form").validate({
    rules: {
      ed_follow_up_at: {
        emailOrMobile: true,
      },
      reported_by: {
        lettersonly: true // Custom validation to allow only alphabetic characters
      }
    },
    messages: {
      ed_follow_up_at: {
        emailOrMobile: "Please enter a valid email address or mobile number.",
      },
      reported_by: {
        lettersonly: "Please enter only alphabetic characters.",
      }
    },
  });

  // Custom method to allow only alphabetic characters
  jQuery.validator.addMethod("lettersonly", function(value, element) {
    return this.optional(element) || /^[a-zA-Z\s]+$/.test(value);
  }, "Please enter only letters.");

  $("#comment-form").validate({
    rules: {
        comment: {
            required: true,    // Make the comment field required
            maxlength: 255     // Set the maximum length to 255 characters
        }
    },
    messages: {
        comment: {
            required: "Please enter a comment.",
            maxlength: "Your comment must be 255 characters or less."
        }
    }
  });

  $("#ed_comment-form").validate({
    rules: {
        comment: {
            required: true,    // Make the comment field required
            maxlength: 255     // Set the maximum length to 255 characters
        }
    },
    messages: {
        comment: {
            required: "Please enter a comment.",
            maxlength: "Your comment must be 255 characters or less."
        }
    }
  });

  // File upload start
  $(document).on("change", ".file-input", function () {
    var filesCount = $(this)[0].files.length;
    var textbox = $(this).prev();

    if (filesCount === 1) {
      var fileName = $(this).val().split("\\").pop();
      textbox.text(fileName);
    } else {
      textbox.text(filesCount + " files selected");
    }
  });
  // File upload end

  $("#tktHistoryModal").on("hidden.bs.modal", function () {
    $(".actualTicket", ".historyTicket").html("");
  });

  //format refund amount in text box
  $("#ed_refund_amount")
    .on("input", function () {
      let value = $(this)
        .val()
        .replace(/[^0-9.]/g, "");
      let parts = value.split(".");
      parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      $(this).val(parts.join("."));
    })
    .on("blur", function () {
      $(this).val($(this).val().replace(/\.$/, ""));
    });

  // Remove non-numeric characters from input
  $("#ed_follow_up_phone").on("input", function () {
    $(this).val(
      $(this)
        .val()
        .replace(/[^0-9]/g, "")
    );
  });

  //accept only letters and spaces
  $("#ed_person_calling").on("input", function () {
    $(this).val(
      $("#ed_person_calling")
        .val()
        .replace(/[^a-zA-Z ]/g, "")
    );
  });

  var globalCategory = [];
  function fetch_category() {
    //fetch categories
    $.ajax({
      url: "fetch/fetch_categories.php",
      type: "GET",
      datatype: "json",
      success: function (response) {
        globalCategory = response;

        var departments = [];
        var deptHtml = '<option value="" selected>Select Department</option>';
        $.each(globalCategory, function (index, category) {
          if ($.inArray(category.Department, departments) === -1) {
            departments.push(category.Department);
            deptHtml +=
              '<option value="' +
              category.Department +
              '">' +
              category.Department +
              "</option>";
          }
        });
        $("#ed_department").html(deptHtml);
      },
      error: function (xhr, status, error) {
        alert("Error occurred while fetching categories");
        console.error(xhr, status, error);
      },
    });
  }

  //fetch parent
  $(document).on("change", "#ed_department", function () {
    var department = $(this).val();
    var parents = [];
    var parentHtml = '<option value="" selected>Select Parent</option>';
    $.each(globalCategory, function (index, category) {
      if (
        category.Department === department &&
        $.inArray(category.Parent, parents) === -1 &&
        (category.Parent != null || category.Parent != "")
      ) {
        parents.push(category.Parent);
        parentHtml +=
          '<option value="' +
          category.Parent +
          '">' +
          category.Parent +
          "</option>";
      }
    });
    $("#ed_parent").html(parentHtml);
    $("#ed_parent").val("").trigger("change");
  });

  //fetch child
  $("#ed_parent").on("change", function () {
    $(
      "#ed_child, #ed_sub_child_1, #ed_sub_child_2, #ed_sub_child_3, #ed_sub_child_4"
    ).val("");
    $(
      ".child_div, .sub_child_1_div, .sub_child_2_div, .sub_child_3_div, .sub_child_4_div"
    ).addClass("d-none");

    var parent = $(this).val();
    var childs = [];
    var childHtml = '<option value="" selected>Select Child</option>';
    $.each(globalCategory, function (index, category) {
      if (
        category.Parent === parent &&
        $.inArray(category.Child, childs) === -1 &&
        (category.Child != null && category.Child != "")
      ) {
        childs.push(category.Child);
        childHtml +=
          '<option value="' +
          category.Child +
          '">' +
          category.Child +
          "</option>";
      }
    });
    if (childs.length > 0) {
      $(".child_div").removeClass("d-none");
      $("#ed_child").html(childHtml);
      $("#ed_child").val("").trigger("change");
    }
  });

  //fetch subchild1
  $("#ed_child").on("change", function () {
    $("#ed_sub_child_1, #ed_sub_child_2, #ed_sub_child_3, #ed_sub_child_4").val(
      ""
    );
    $(
      ".sub_child_1_div, .sub_child_2_div, .sub_child_3_div, .sub_child_4_div"
    ).addClass("d-none");

    var child = $(this).val();
    var subchild1 = [];
    var subchild1Html = '<option value="" selected>Select Sub Child 1</option>';
    $.each(globalCategory, function (index, category) {
      if (
        category.Child === child &&
        $.inArray(category.Sub_Child_1, subchild1) === -1 &&
        (category.Sub_Child_1 != null && category.Sub_Child_1 != "")
      ) {
        subchild1.push(category.Sub_Child_1);
        subchild1Html +=
          '<option value="' +
          category.Sub_Child_1 +
          '">' +
          category.Sub_Child_1 +
          "</option>";
      }
    });
    if (subchild1.length > 0) {
      $(".sub_child_1_div").removeClass("d-none");
      $("#ed_sub_child_1").html(subchild1Html);
      $("#ed_sub_child_1").val("").trigger("change");
    }
  });

  //fetch subchild2
  $("#ed_sub_child_1").on("change", function () {
    $("#ed_sub_child_2, #ed_sub_child_3, #ed_sub_child_4").val("");
    $(".sub_child_2_div, .sub_child_3_div, .sub_child_4_div").addClass(
      "d-none"
    );

    var sub_child_1 = $(this).val();
    var subchild2 = [];
    var subchild2Html = '<option value="" selected>Select Sub Child 2</option>';
    $.each(globalCategory, function (index, category) {
      if (
        category.Sub_Child_1 === sub_child_1 &&
        $.inArray(category.Sub_Child_2, subchild2) === -1 &&
        (category.Sub_Child_2 != null && category.Sub_Child_2 != "")
      ) {
        subchild2.push(category.Sub_Child_2);
        subchild2Html +=
          '<option value="' +
          category.Sub_Child_2 +
          '">' +
          category.Sub_Child_2 +
          "</option>";
      }
    });
    if (subchild2.length > 0) {
      $(".sub_child_2_div").removeClass("d-none");
      $("#ed_sub_child_2").html(subchild2Html);
      $("#ed_sub_child_2").val("").trigger("change");
    }
  });

  //fetch subchild3
  $("#ed_sub_child_2").on("change", function () {
    $("#ed_sub_child_3, #ed_sub_child_4").val("");
    $(".sub_child_3_div, .sub_child_4_div").addClass("d-none");

    var sub_child_2 = $(this).val();
    var subchild3 = [];
    var subchild3Html = '<option value="" selected>Select Sub Child 3</option>';
    $.each(globalCategory, function (index, category) {
      if (
        category.Sub_Child_2 === sub_child_2 &&
        $.inArray(category.Sub_Child_3, subchild3) === -1 &&
        (category.Sub_Child_3 != null && category.Sub_Child_3 != "")
      ) {
        subchild3.push(category.Sub_Child_3);
        subchild3Html +=
          '<option value="' +
          category.Sub_Child_3 +
          '">' +
          category.Sub_Child_3 +
          "</option>";
      }
    });
    if (subchild3.length > 0) {
      $(".sub_child_3_div").removeClass("d-none");
      $("#ed_sub_child_3").html(subchild3Html);
      $("#ed_sub_child_3").val("").trigger("change");
    }
  });

  //fetch subchild4
  $("#ed_sub_child_3").on("change", function () {
    $("#ed_sub_child_4").val("");
    $(".sub_child_4_div").addClass("d-none");

    var sub_child_3 = $(this).val();
    var subchild4 = [];
    var subchild4Html = '<option value="" selected>Select Sub Child 4</option>';
    $.each(globalCategory, function (index, category) {
      if (
        category.Sub_Child_3 === sub_child_3 &&
        $.inArray(category.Sub_Child_4, subchild4) === -1 &&
        (category.Sub_Child_4 != null && category.Sub_Child_4 != "")
      ) {
        subchild4.push(category.Sub_Child_4);
        subchild4Html +=
          '<option value="' +
          category.Sub_Child_4 +
          '">' +
          category.Sub_Child_4 +
          "</option>";
      }
    });
    if (subchild4.length > 0) {
      $(".sub_child_4_div").removeClass("d-none");
      $("#ed_sub_child_4").html(subchild4Html);
    }
  });

  //history list back link
  $(document).on("click", ".history_back", function () {
    $("#ticket_detail").addClass("d-none");
    $("#ticket_history").addClass("d-none");
    $("#ticket_list").removeClass("d-none");
  });

  //Save draft data when any changes made in the form
  function autoSave() {
    var TicketId = $("#ed_ticket_id").val();
    $.ajax({
      url: "fetch/fetch_draft.php",
      type: "POST",
      dataType: "json",
      data: {
        TicketId: TicketId,
      },
      success: function (response) {
        dataObject = response;

        var tenant_id = $("#tenant_id").val();
        var post_ticket_title = $("#ed_ticket_title").val();
        // var post_source = $("#ed_select_source").val();
        var post_reported_by = $("#ed_reported_by").val();
        var post_select_status = $("#ed_select_status").val();

        var post_department = $("#ed_department").val();
        var post_parent = $("#ed_parent").val();
        var post_child =
          $("#ed_child").val() != "" ? $("#ed_child").val() : "";
        var post_sub_child_1 =
          $("#ed_sub_child_1").val() != "" ? $("#ed_sub_child_1").val() : "";
        var post_sub_child_2 =
          $("#ed_sub_child_2").val() != "" ? $("#ed_sub_child_2").val() : "";
        var post_sub_child_3 =
          $("#ed_sub_child_3").val() != "" ? $("#ed_sub_child_3").val() : "";
        var post_sub_child_4 =
          $("#ed_sub_child_4").val() != "" ? $("#ed_sub_child_4").val() : "";

        var post_priority = $("#ed_priority").val();
        var post_case_details = $("#ed_case_details").val();
        var post_immediate_action_taken = $("#ed_immediate_action_taken").val();
        var post_follow_up_at = $("#ed_follow_up_at").val();
        var post_next_follow_up_date =
          $("#ed_next_follow_up_date").val() != ""
            ? $("#ed_next_follow_up_date").val()
            : "";
        var ticket_id = $("#ticket_id").val();

        // Check if any changes made
        if (
          dataObject.DraftData.Title != post_ticket_title ||
          // response.SelectSource != post_source ||
          dataObject.DraftData.ReportedBy != post_reported_by ||
          response.Department != post_department ||
          response.Parent != post_parent ||
          response.Child != post_child ||
          response.Sub_Child_1 != post_sub_child_1 ||
          response.Sub_Child_2 != post_sub_child_2 ||
          response.Sub_Child_3 != post_sub_child_3 ||
          response.Sub_Child_4 != post_sub_child_4 ||
          response.SelectPriority != post_priority ||
          response.SelectStatus != post_select_status ||
          response.CaseDetails != post_case_details ||
          response.ImmediateActionTaken != post_immediate_action_taken ||
          dataObject.DraftData.FollowUpAt != post_follow_up_at ||
          response.NextFollowUpDate != post_next_follow_up_date
        ) {
          $.ajax({
            url: "draft.php",
            type: "POST",
            data: {
              Id: ticket_id,
              TenantId: tenant_id,
              TicketTitle: post_ticket_title,
              // Source: post_source,
              ReportedBy: post_reported_by,
              Department: post_department,
              Parent: post_parent,
              Child: post_child,
              Sub_Child_1: post_sub_child_1,
              Sub_Child_2: post_sub_child_2,
              Sub_Child_3: post_sub_child_3,
              Sub_Child_4: post_sub_child_4,
              Priority: post_priority,
              SelectStatus: post_select_status,
              CaseDetails: post_case_details,
              ImmediateActionTaken: post_immediate_action_taken,
              FollowUpAt: post_follow_up_at,
              NextFollowUpDate: post_next_follow_up_date,
              Attachments: dataObject.DraftData.Attachments,
            },
            datatype: "json",
            success: function (response) {
              if (response.success) {
                if (response.ModifiedAt != "") {
                  $(".last_draft_div").removeClass("d-none");
                  $(".draft_date").text(response.ModifiedAt);
                } else {
                  $(".last_draft_div").addClass("d-none");
                }

                const Toast = Swal.mixin({
                  toast: true,
                  position: "bottom-end",
                  showConfirmButton: false,
                  timer: 3000,
                  timerProgressBar: true,
                  didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                  },
                });
                Toast.fire({
                  icon: "success",
                  title: response.message,
                });
              }
            },
            error: function (xhr, status, error) {
              alert("Error saving data");
            },
          });
        }
      },
      error: function (xhr, status, error) {
        alert("Error occurred while fetching data");
        console.error(xhr, status, error);
      },
    });
  }

  function fetch_ticket_details(TicketId) {
    $(".de_child_div, .de_sub_child_1_div, .de_sub_child_2_div, .de_sub_child_3_div, .de_sub_child_4_div").addClass("d-none");
    $.ajax({
      url: "fetch/fetch_ticket_details.php",
      type: "POST",
      datatype: "json",
      data: {
        TicketId: TicketId,
      },
      success: function (response) {
        if(response) {
          var ticket_data = response.data;

          if(ticket_data.SelectStatus == 'Closed'){
            $('#back_ticket_list').addClass('d-none');
          }
          
          $("#title").html(
            '<i class="mdi mdi-ticket font-18 text-success me-1 align-middle"></i>' +
            ticket_data.TicketTitle
          );
          $("#source").text(ticket_data.Source);
          $("#reported_by").text(ticket_data.ReportedBy);
          $("#ticket_department").text(ticket_data.Department);
          $("#ticket_parent").text(ticket_data.Parent);
  
          if (ticket_data.Child !== null && ticket_data.Child != "") {
            $(".de_child_div").removeClass("d-none");
            $("#ticket_child").text(ticket_data.Child);
          }
          if (ticket_data.Sub_Child_1 !== null && ticket_data.Sub_Child_1 != "") {
            $(".de_sub_child_1_div").removeClass("d-none");
            $("#ticket_sub_child_1").text(ticket_data.Sub_Child_1);
          }
          if (ticket_data.Sub_Child_2 !== null && ticket_data.Sub_Child_2 != "") {
            $(".de_sub_child_2_div").removeClass("d-none");
            $("#ticket_sub_child_2").text(ticket_data.Sub_Child_2);
          }
          if (ticket_data.Sub_Child_3 !== null && ticket_data.Sub_Child_3 != "") {
            $(".de_sub_child_3_div").removeClass("d-none");
            $("#ticket_sub_child_3").text(ticket_data.Sub_Child_3);
          }
          if (ticket_data.Sub_Child_4 !== null && ticket_data.Sub_Child_4 != "") {
            $(".de_sub_child_4_div").removeClass("d-none");
            $("#ticket_sub_child_4").text(ticket_data.Sub_Child_4);
          }
  
          $("#ticket_status").text(ticket_data.SelectStatus);
          $("#priority").text(ticket_data.Priority);
          $("#follow_up_at").text(ticket_data.FollowUpAt);
          $("#next_follow_up_date").text(ticket_data.NextFollowUpDate);
          $("#case_details").text(ticket_data.CaseDetails);
          $("#immediate_action_taken").text(ticket_data.ImmediateActionTaken);
          $("#created_at").text(ticket_data.CreatedAtDate);
          $("#created_at").append(
            '&nbsp;<small class="text-muted" id="created_time">' +
            ticket_data.CreatedAtTime +
              "</small>"
          );
          $("#modified_at").text(ticket_data.ModifiedAtDate);
          $("#modified_at").append(
            '&nbsp;<small class="text-muted" id="updated_time">' +
            ticket_data.ModifiedAtTime +
              "</small>"
          );
          $("#ticket_id").val(ticket_data.TicketId);
          $(".edit_tkt_lnk").attr("data-ticketid", ticket_data.TicketId);
  
          ticketFiles = ticket_data.Attachments;
          var fileList = "";
          $.each(ticketFiles, function (index, ticketFile) {
            var file_extension = ticketFile.split(".").pop();
            
            fileList +=
              '<div class="card mb-1 shadow-none border">\
                            <div class="p-2">\
                                <div class="row align-items-center">\
                                    <div class="col-auto">\
                                        <div class="avatar-sm">\
                                            <span class="avatar-title badge-soft-primary text-primary rounded">\
                                                ' +
              file_extension +
              '\
                                            </span>\
                                        </div>\
                                    </div>\
                                    <div class="col ps-0">\
                                        <a href="download_ticket_file.php?file=' + ticketFile + '" class="text-muted fw-bold" target="_blank">' + ticketFile + '</a>\
                                    </div>\
                                    <div class="col-auto">\
                                        <a href="download_ticket_file.php?file=' + ticketFile + '" class="btn btn-link font-16 text-muted" target="_blank">\
                                            <i class="mdi mdi-download"></i>\
                                        </a>\
                                    </div>\
                                </div>\
                            </div>\
                        </div>';
          });
          $(".ticket_file_list").html(fileList);
  
          $("#tenant_source").html(
            '<i class="mdi mdi-ticket font-18 text-success me-1 align-middle"></i>' +
            ticket_data.Source
          );
          $("#tenant_source_url").html(
            '<i class="mdi mdi-link font-18 text-success me-1 align-middle"></i>' +
            ticket_data.SourceUrl
          );
  
          fetchComment(ticket_data.TicketId);
        } else {
          Swal.fire({
            title: "Error!",
            text: response.data,
            icon: "warning",
          });
        }
      },
      error: function (xhr, status, error) {
        alert("Error occurred on edit");
        console.error(xhr, status, error);
      },
    });
  }

  function fetchComment(TicketId) {
    $(".comment_area").html("");
    $(".comment_area").removeClass("comment_scroll");
    $(".load-more-comment").css("display", "block");

    $.ajax({
      url: "fetch/fetch_comment.php",
      type: "POST",
      data: {
        TicketId: TicketId,
      },
      dataType: "json",
      success: function (response) {
        if (response.more_records) {
          $(".comment_area").html(response.html);

          if (response.comment_count > 4) {
            $(".comment_area").addClass("comment_scroll");
          }

          $(".comment_count").text("Comment (" + response.comment_count + ")");
        } else {
          $(".comment_count").text("Comment (" + response.comment_count + ")");
        }
      },
      error: function (xhr, status, error) {
        alert("can't display comments");
        console.error(xhr, status, error);
      },
    });
  }

  function hide() {
    var x = document.getElementsByClassName("hiddenEle");
    for (var i = 0; i < x.length; i++) {
      if (x[i].style.display === "none") {
        x[i].style.display = "flex";
      } else {
        x[i].style.display = "none";
      }
    }
  }

  // Get the TicketId from sessionStorage
  var SessionTicketId = sessionStorage.getItem('TicketId');

  // If there's a TicketId in sessionStorage, show the ticket details
  if (SessionTicketId) {
    $("#ticket_list").addClass("d-none");
    $("#ticket_detail").removeClass("d-none");
    fetch_ticket_details(SessionTicketId);

    // Optionally, clear the stored TicketId after using it
    sessionStorage.removeItem('TicketId');
  }
});
