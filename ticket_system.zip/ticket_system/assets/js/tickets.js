//Page scroll to top
function scrollToTop() {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  });
}

// Select2 Dropdown Menu Button Click Event Handler
(function(t) {
  "use strict";
  
  function e() {}
  
  e.prototype.initSelect2 = function() {
      t('[data-toggle="select2"]').select2();
  };
  
  e.prototype.init = function() {
      this.initSelect2();
  };

  // Instantiate e and initialize
  var e = new e();
  e.init();
  
})(jQuery); 