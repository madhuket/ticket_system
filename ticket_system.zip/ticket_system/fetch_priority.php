<?php

$sql = "SELECT Id,Priority FROM Priorities WHERE (IsDeleted = 0 OR IsDeleted IS NULL);";
$result = sqlsrv_query($conn, $sql);

if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
}

$data = array();
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {

    $data[] = [
        'id' => $row['Id'],
        'Priority' => $row['Priority'],
    ];
}


sqlsrv_free_stmt($result);

header('Content-Type: application/json');
echo json_encode($data);
