<style>
    .file-drop-area {
        position: relative;
        display: flex;
        align-items: center;
        /* width: 450px; */
        width: 100%;
        padding: 25px;
        border: 1px dashed rgba(0, 0, 0, 0.4);
        border-radius: 3px;
        transition: 0.2s;
    }

    .choose-file-button {
        flex-shrink: 0;
        background-color: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 3px;
        padding: 8px 15px;
        margin-right: 10px;
        font-size: 12px;
        text-transform: uppercase;
    }

    .file-message {
        font-size: small;
        font-weight: 300;
        line-height: 1.4;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .file-input {
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
        width: 100%;
        cursor: pointer;
        opacity: 0;
    }

    .last_draft_label label {
        white-space: nowrap;
    }
</style>

<div class="content d-none" id="edit_ticket">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right me-4">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Ticket Managements</a></li>
                            <li class="breadcrumb-item"><a href="view_ticket.php">Tickets</a></li>
                            <li class="breadcrumb-item active">Edit Ticket</li>
                        </ol>
                    </div>

                    <div class="page-title-right last_draft_div">
                        <div class="row bg-white me-2 rounded-3">
                            <div class="col-md-4 last_draft_label">
                                <label class="col col-form-label text-dark">Last Draft</label>
                            </div>
                            <div class="col-md-8">
                                <label class="col col-form-label text-dark draft_date"></label>
                            </div>
                        </div>
                    </div>
                    <h4 class="page-title ps-5">Edit Ticket</h4>
                </div>
            </div>
        </div>

        <div class="row bg-white mb-2 rounded-3 d-md-none w-100 m-auto last_draft_div">
            <div class="col-3 last_draft_label">
                <label class="col col-form-label text-dark">Last Draft</label>
            </div>
            <div class="col-9">
                <label class="col col-form-label text-dark draft_date"></label>
            </div>
        </div>

        <div class="row">
            <div class="col-12 px-0">
                <div class="card">
                    <div class="card-body">
                        <form method="POST" id="edit_ticket_form" enctype="multipart/form-data">
                            <input type='hidden' name="type" value="ticket">
                            <input type="hidden" id="ed_ticket_id" name="ticket_id" value="">
                            <input type="hidden" id="source_url" name="source_url" value="">
                            <input type="hidden" id="tenant_id" name="tenant_id" value="">
                            <input type="hidden" name="csrf_token" id="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                            <div class="row mb-3 border p-2 pb-0 px-0 mt-4 mx-0 mt-lg-0 rounded">
                                <div class="col-md-6">
                                    <p class="header-title mb-2" id="ed_source"></p>
                                </div>
                                <div class="col-md-6">
                                    <p class="header-title" id="ed_source_url"></p>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="ed_ticket_title" class="form-label">Title<span style="color: red;"> *</span></label>
                                        <input type="text" id="ed_ticket_title" class="form-control" name="ticket_title" placeholder="Enter title" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="ed_reported_by" class="form-label">Reported By</label>
                                        <input type="text" id="ed_reported_by" class="form-control" name="reported_by" placeholder="Enter name of person who reported this">
                                    </div>

                                    <div class="mb-3">
                                        <label for="ed_select_status" class="form-label">Status</label>
                                        <select class="form-select" id="ed_select_status" name="select_status">
                                            <?php include 'select_status.php'; ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="ed_priority" class="form-label">Priority<span style="color: red;"> *</span></label>
                                        <select class="form-select" id="ed_priority" name="priority" required>
                                            <option value="" selected>Select Ticket Priority</option>
                                            <?php include 'select_priority.php'; ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="ed_department" class="form-label">Department<span class="error"> *</span></label>
                                        <select class="form-select" id="ed_department" name="department" required></select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="ed_parent" class="form-label">Parent<span class="error"> *</span></label>
                                        <select class="form-select" id="ed_parent" name="parent" required>
                                            <option value="" selected>Select Parent</option>
                                        </select>
                                    </div>

                                    <div class="mb-3 child_div d-none">
                                        <label for="ed_child" class="form-label">Child</label>
                                        <select class="form-select" id="ed_child" name="child">
                                            <option value="" selected>Select Child</option>
                                        </select>
                                    </div>

                                    <div class="mb-3 sub_child_1_div d-none">
                                        <label for="ed_sub_child_1" class="form-label">Sub Child 1</label>
                                        <select class="form-select" id="ed_sub_child_1" name="sub_child_1">
                                            <option value="" selected>Select Sub Child 1</option>
                                        </select>
                                    </div>

                                    <div class="mb-3 sub_child_2_div d-none">
                                        <label for="ed_sub_child_2" class="form-label">Sub Child 2</label>
                                        <select class="form-select" id="ed_sub_child_2" name="sub_child_2">
                                            <option value="" selected>Select Sub Child 2</option>
                                        </select>
                                    </div>

                                    <div class="mb-3 sub_child_3_div d-none">
                                        <label for="ed_sub_child_3" class="form-label">Sub Child 3</label>
                                        <select class="form-select" id="ed_sub_child_3" name="sub_child_3">
                                            <option value="" selected>Select Sub Child 3</option>
                                        </select>
                                    </div>

                                    <div class="mb-3 sub_child_4_div d-none">
                                        <label for="ed_sub_child_4" class="form-label">Sub Child 4</label>
                                        <select class="form-select" id="ed_sub_child_4" name="sub_child_4">
                                            <option value="" selected>Select Sub Child 4</option>
                                        </select>
                                    </div>

                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="ed_select_source" class="form-label">Source<span style="color: red;"> *</span></label>
                                        <select class="form-select" id="ed_select_source" name="select_source" required disabled>
                                            <option value="" selected>Select Source</option>
                                            <?php include 'select_source.php'; ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="ed_follow_up_at" class="form-label">Follow Up At</label>
                                        <input class="form-control" id="ed_follow_up_at" type="text" name="ed_follow_up_at" placeholder="Enter email address or mobile number on which follow up is to be done">
                                    </div>

                                    <div class="mb-3">
                                        <label for="next_follow_up_date" class="form-label">Next Follow Up Date</label>
                                        <input type="text" id="ed_next_follow_up_date" class="form-control" name="next_follow_up_date" data-provide="datepicker" placeholder="Select next follow up date">
                                    </div>

                                    <div class="mb-3">
                                        <label for="ed_case_details" class="form-label">Case Details</label>
                                        <textarea class="form-control" id="ed_case_details" name="case_details" rows="5"></textarea>
                                    </div>

                                    <div class="mb-3">
                                        <label for="ed_immediate_action_taken" class="form-label">Immediate Action Taken</label>
                                        <textarea class="form-control" id="ed_immediate_action_taken" name="immediate_action_taken" rows="5"></textarea>
                                    </div>

                                    <div class="mb-3">
                                        <label class="col-sm-2 form-label">Upload File</label>
                                        <div class="file-drop-area">
                                            <span class="choose-file-button">Choose files</span>
                                            <span class="file-message">or drag and drop files here</span>
                                            <input class="file-input" name="attachments[]" type="file" multiple>
                                        </div>
                                        <label id="attachments-error" class="text-danger d-none"></label>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="text-center d-flex justify-content-center">
                                        <div class="mt-3">
                                            <button type="submit" class="btn btn-primary" id="submit_form">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end row-->
                        </form>
                    </div>
                </div> <!-- end card-->
            </div> <!-- end col -->
        </div>

        <div class="row">
            <div class="col-xl-8 col-lg-7 px-0">
                <!-- Comment Start -->
                <div class="card">
                    <div class="card-body">
                        <div class="float-end">
                            <select class="form-select form-select-sm comment_sort">
                                <option value="1" selected="">Recent</option>
                                <option value="0">Old</option>
                            </select>
                        </div> <!-- end dropdown-->

                        <h4 class="mb-4 mt-0 font-16 comment_count">Comment</h4>

                        <div class="clerfix"></div>

                        <div class="comment_area"> </div>


                        <div class="text-center mt-2"></div>

                        <div class="border rounded mt-4">
                            <form class="comment-area-box" id="ed_comment-form">
                                <input type="hidden" name="ed_csrf_token" id="ed_csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                                <textarea rows="3" class="form-control border-0 resize-none" placeholder="Your comment..." id="ed_comment" name="comment" required></textarea>
                                <div class="p-2 bg-light d-flex justify-content-between align-items-center">
                                    <button type="submit" class="btn btn-sm btn-primary ed_add-comment"><i class="mdi mdi-send me-1"></i>Submit</button>
                                </div>
                            </form>
                        </div> <!-- end .border-->

                    </div> <!-- end card-body-->
                </div>
                <!-- Comment end-->
            </div>
            <div class="col-xl-4 col-lg-5 pe-0">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title font-16 mb-3">Attachments</h5>
                        <div class="edit_attachments_list"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>