<?php
$_SERVER['REQUEST_URI_PATH'] = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$segments = explode('/', $_SERVER['REQUEST_URI_PATH']);
$base_url = implode('/', array_slice($segments, 0, -1));

session_start();
?>

<!DOCTYPE html>
<html lang="en" data-layout-mode="detached" data-topbar-color="dark" data-sidenav-user="true">

<head>
    <meta charset="utf-8" />
    <title>Ticket Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Ticket Management" name="description" />
    <meta content="TicketManagement" name="author" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/customer-support.png">

    <!-- Theme Config Js -->
    <script src="<?php echo $base_url ?>/assets/js/head.js"></script>

    <!-- Bootstrap css -->
    <link href="<?php echo $base_url ?>/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="app-style" />

    <!-- App css -->
    <link href="<?php echo $base_url ?>/assets/css/app.min.css" rel="stylesheet" type="text/css" />

    <!-- Icons css -->
    <link href="<?php echo $base_url ?>/assets/css/icons.min.css" rel="stylesheet" type="text/css" />

    <!-- jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Plugins css -->
    <link href="<?php echo $base_url ?>/assets/css/selectize.bootstrap3.css" rel="stylesheet" type="text/css" />
</head>

<?php
include "connection.php";

$referrer_url = $_GET['referrer'] ?? '';
$tenant_user_id = $_GET['user_id'] ?? '';
$tenant_first_name = $_GET['first_name'] ?? '';
$tenant_last_name = $_GET['last_name'] ?? '';

if($referrer_url != ''){
    $referrer = htmlspecialchars(urldecode($referrer_url));
}

$license_key = $_GET['license_key'] ?? '';
$license_data = "SELECT * FROM License WHERE LicenseKey = ? AND IsActive = ? AND IsDeleted = ?";
$params = array($license_key, 1, 0);
$result = sqlsrv_query($conn, $license_data, $params);

if ($result && sqlsrv_has_rows($result)) {
    $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
    $license_id = $row['Id'];
    $license_key = $row['LicenseKey'];
    $tenant_name = $row['TenantName'];
    $tenant_url = $row['TenantURL'];
    $tenant_id = $row['TenantID'];
    $expiry_date = $row['ExpiryDate'];
    $tenant_host = parse_url($tenant_url, PHP_URL_HOST);

    // Validate the referrer URL
    if (!(($referrer !== '') && $referrer === $tenant_host)) {
        setcookie('isValidateUrl', '', -1, '/', '', false, true);
        setcookie("AuthToken", '', -1, '/', '', false, true);

        unset($_SESSION['tenant_name']);
        unset($_SESSION['tenant_url']);
        unset($_SESSION['tenant_id']);
        unset($_SESSION['license_id']);
        unset($_SESSION['AuthToken']);
        session_destroy();
        
        echo "<div class='alert alert-danger' role='alert'>
                Invalid Referrer URL!
            </div>";
        exit();
    } else {
        setcookie('isValidateUrl', '1', 0, "/", '', false, true);
    }

    // Check if license key is valid
    $current_date = date('Y-m-d H:i:s');
    if ($license_key != '' && ($expiry_date >= $current_date)) {
        //generate 6 digit random alphanumeric
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        $randomString = '';
        for ($i = 0; $i < 6; $i++) {
            $randomString.= $characters[rand(0, strlen($characters) - 1)];
        }
        $AuthToken = $randomString;

        setcookie('AuthToken', $AuthToken, 0, "/", '', false, true);
        $_SESSION['AuthToken'] = $AuthToken;

        $_SESSION['tenant_name'] = $tenant_name;
        $_SESSION['tenant_url'] = $tenant_url;
        $_SESSION['tenant_id'] = $tenant_id;
        $_SESSION['license_id'] = $license_id;
        $_SESSION['user_login'] = false;

        //check user_id already exist in TenantUser table
        $tenant_user_check = "SELECT Id FROM TenantUser WHERE UserId =?";
        $params = array($tenant_user_id);
        $result = sqlsrv_prepare($conn, $tenant_user_check, $params);

        if (sqlsrv_execute($result) && sqlsrv_has_rows($result)) {
            $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);

            $_SESSION['tenant_user_id'] = $row['Id'];
            header('Location: index.php');
            exit();
        } else {
            //save user_id, tenant_first_name, tenant_last_name in TenantUser table
            $tenant_user_data = "INSERT INTO TenantUser (UserId, FirstName, LastName) VALUES (?,?,?)";
            $params = array($tenant_user_id, $tenant_first_name, $tenant_last_name);
            $result = sqlsrv_prepare($conn, $tenant_user_data, $params);

            if (sqlsrv_execute($result)) {
                //get last inserted id from TenantUser table
                $sql_last_id = "SELECT TOP 1 Id AS LastInsertedID FROM TenantUser ORDER BY Id DESC";
                $stmt_last_id = sqlsrv_prepare($conn, $sql_last_id);
                if (sqlsrv_execute($stmt_last_id)) {
                    $row = sqlsrv_fetch_array($stmt_last_id, SQLSRV_FETCH_ASSOC);
                    $last_inserted_id = $row['LastInsertedID'];
                }

                $_SESSION['tenant_user_id'] = $last_inserted_id;
                header('Location: index.php');
                exit();
            } else {
                //print sqlsrv error
                $errors = sqlsrv_errors();
                print_r($errors);
                echo "<div class='alert alert-danger' role='alert'>
                        Failed to save user details!
                    </div>";
                exit();
            }
        }
    } else {
        unset($_SESSION['tenant_name']);
        unset($_SESSION['tenant_url']);
        unset($_SESSION['tenant_id']);
        unset($_SESSION['AuthToken']);
        unset($_SESSION['license_id']);
        unset($_SESSION['user_login']);
        unset($_SESSION['tenant_user_id']);

        setcookie("AuthToken", '', -1, '/', '', false, true);
        setcookie('isValidateUrl', '', -1, '/', '', false, true);

        echo "<div class='alert alert-danger' role='alert'>
                Unauthorized User!
            </div>";
        exit();
    }
} else {
    unset($_SESSION['tenant_name']);
    unset($_SESSION['tenant_url']);
    unset($_SESSION['tenant_id']);
    unset($_SESSION['AuthToken']);
    unset($_SESSION['license_id']);
    unset($_SESSION['user_login']);

    setcookie("AuthToken", '', -1, '/', '', false, true);
    setcookie('isValidateUrl', '', -1, '/', '', false, true);

    echo "<div class='alert alert-danger' role='alert'>
            Unauthorized User!
        </div>";
    exit();
}
?>