<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div>
                    <?php echo date("Y"); ?> © Ticket Management System - <a href="https://www.electronicpayments.com/" target="_blank" class="footer_link">ISOInterface</a>
                </div>
            </div>
            <div class="col-md-6">
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->

</div>

<!-- ============================================================== -->
<!-- End Page content -->
<!-- ============================================================== -->

</div>
<!-- END wrapper -->

<!-- Vendor js -->
<script src="<?php echo $base_url ?>/assets/js/vendor.min.js"></script>

<!-- App js -->
<script src="<?php echo $base_url ?>/assets/js/app.min.js"></script>

<!-- For Alert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- For Toaster -->
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<!-- For Datatable -->
<script src="<?php echo $base_url ?>/assets/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $base_url ?>/assets/js/dataTables.bootstrap5.min.js"></script>
<script src="<?php echo $base_url ?>/assets/js/dataTables.responsive.min.js"></script>
<script src="<?php echo $base_url ?>/assets/js/dataTables.buttons.min.js"></script>

<script src="<?php echo $base_url ?>/assets/js/responsive.bootstrap5.min.js"></script>


<!-- For Flatpicker -->
<script src="<?php echo $base_url ?>/assets/js/flatpickr.min.js"></script>
<script src="<?php echo $base_url ?>/assets/js/flatpickr-master/plugins/monthSelect/index.js"></script>

<!-- For Datepicker -->
<script src="<?php echo $base_url ?>/assets/js/bootstrap-datepicker.min.js"></script>

<!-- For Selectize -->
<!-- <script src="<?php echo $base_url ?>/assets/js/selectize.min.js"></script> -->

<!-- For jQuery Validator -->
<script src="<?php echo $base_url ?>/assets/js/jquery.validate.min.js"></script>
<script src="<?php echo $base_url ?>/assets/js/additional-methods.min.js"></script>

<!-- Datatables init -->
<script src="<?php echo $base_url ?>/assets/js/datatables.init.js"></script>

<!-- Select2 JS -->
<script src="<?php echo $base_url ?>/assets/js/select2.min.js"></script> 

<script src="<?php echo $base_url ?>/assets/js/tickets.js"></script>

<script>
    // Function to update the body class based on the HTML class
    // function updateBodyClass() {
    //     // Select the HTML tag
    //     const htmlTag = document.querySelector('html');

    //     // Check if the HTML tag has the 'sidebar-enable' class
    //     if (htmlTag.classList.contains('sidebar-enable')) {
    //         // Add the 'sidebar-enable' class to the body tag
    //         document.body.classList.add('sidebar-enable');
    //     } else {
    //         // Remove the 'sidebar-enable' class from the body tag
    //         document.body.classList.remove('sidebar-enable');
    //     }
    // }

    // Call the function when the document is loaded
    // document.addEventListener('DOMContentLoaded', () => {
    //     updateBodyClass();

    //     // Select the HTML tag
    //     const htmlTag = document.querySelector('html');

    //     // Create a MutationObserver to monitor changes to the class attribute
    //     const observer = new MutationObserver(updateBodyClass);

    //     // Configure the observer to watch for attribute changes
    //     const config = {
    //         attributes: true,
    //         attributeFilter: ['class']
    //     };

    //     // Start observing the HTML tag
    //     observer.observe(htmlTag, config);
    // });
</script>


</body>

</html>