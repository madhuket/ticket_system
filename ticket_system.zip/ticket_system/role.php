<?php
include "header.php";

if(!(isset($_SESSION['is_superadmin']) && $_SESSION['is_superadmin'] == true)){
    header("Location: index.php");
    exit();
}
?>

<body>
    <?php include "sider.php"; ?>

    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right me-4">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>">Ticket Management</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/view_ticket.php">Tickets</a></li>
                                <li class="breadcrumb-item active">Role</li>
                            </ol>
                        </div>
                        <h4 class="page-title ps-5">Role</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->


            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" id="RoleForm">
                                <input type='hidden' id="type" name="type" value="role">
                                <input type="hidden" id="id" name="id" value="">
                                <input type="hidden" name="csrf_token" id="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label for="role" class="form-label">Role<span class="req_star"> *</span></label>
                                            <input type="text" id="role" class="form-control" name="role" required>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label class="form-label">Select Permissions<span class="req_star"> *</span></label>

                                            <!-- Select All checkbox -->
                                            <div class="form-check form-check-pink mb-1">
                                                <input type="checkbox" id="selectAllPer" class="form-check-input" />
                                                <label for="selectAllPer"><strong>Select All</strong></label>
                                            </div>
                                            
                                            <div data-simplebar style="max-height: 150px;">
                                                <?php
                                                    include 'select_permissions.php';
                                                ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <div class="form-check form-switch">
                                                <input type="checkbox" class="form-check-input" id="is_superadmin" name="is_superadmin" value="1">
                                                <label class="form-check-label" for="is_superadmin">Is SuperAdmin</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="text-center d-flex justify-content-center">
                                        <div class="mt-3">
                                            <button type="submit" class="btn btn-primary" id="submit_form">Submit</button>
                                        </div>

                                        <div class="mt-3 ms-2">
                                            <button type="reset" class="btn btn-danger" id="reset_form">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">

                            <div class="table-responsive">
                                <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tbl_role">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Role</th>
                                            <th>Assigned Permissions</th>
                                            <th class="hidden-sm">Action</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div><!-- end col -->
            </div>
            <!-- end row -->
        </div> <!-- container -->
    </div>

    <script>
        $(document).ready(function() {
            $("#reset_form").on("click", function () {
                $('#id').val('');
                $('#permission').val('').trigger('change');

                $("#RoleForm").find("label.error").remove();
                $("#RoleForm").find(".error").removeClass("error");
            });

            $("#tbl_role").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                },
                ajax: {
                    url: "fetch/fetch_role.php"
                }
            });

            $('#RoleForm').submit(function(e) {
                e.preventDefault();

                var isvalidForm = $(this).valid();
                if (isvalidForm) {
                    //disable button
                    $('#submit_form').attr('disabled', true);

                    var formData = $(this).serialize();
                    $.ajax({
                        type: 'POST',
                        url: 'store_data.php',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            if (response.success) {
                                $("#tbl_role").DataTable().ajax.reload();
                                Swal.fire({
                                    title: "Good job!",
                                    text: response.message,
                                    icon: "success"
                                });
                                $('#csrf_token').val(response.csrf_token);
                                $('#role').val('');
                                $('#permission').val('').trigger('change');
                            } else {
                                Swal.fire({
                                    title: "Can't insert data",
                                    text: response.message,
                                    icon: "warning"
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            console.error("Error saving status:", error);
                        },
                    });
                }
            });

            $(document).on("click", ".edit_role", function() {
                var role_id = $(this).data('roleid');

                $.ajax({
                    type: 'POST',
                    url: 'fetch/fetch_role_particular.php',
                    data: {
                        'role_id': role_id
                    },
                    dataType: 'json',
                    success: function(response) {
                        $("#RoleForm").find("label.error").remove();
                        $("#RoleForm").find(".error").removeClass("error");

                        // Uncheck all checkboxes
                        $('#selectAllPer, .perm-class').prop('checked', false);

                        scrollToTop();
                        $('#role').val(response.Role);
                        $.each(response.Permission, function(index, value) {
                            //select checkboxes with the matching value and check them
                            $('input[type="checkbox"][value="' + value + '"]').prop('checked', true);
                        });

                        if ($('.perm-class:checked').length === $('.perm-class').length) {
                            $('#selectAllPer').prop('checked', true);
                        }

                        $('#id').val(response.Id);
                        $('#csrf_token').val(response.CsrfToken);
                        response.IsSuperAdmin == 1 ? $('#is_superadmin').prop('checked', true): $('#is_superadmin').prop('checked', false);
                    }
                });
            });

            $(document).on("click", ".remove_role", function() {
                var role_id = $(this).data('roleid');

                if(role_id !== '' && role_id !== null && role_id !== undefined) {
                    Swal.fire({
                        title: "Are you sure?",
                        text: "You won't be able to revert this!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#3085d6",
                        cancelButtonColor: "#d33",
                        confirmButtonText: "Yes, delete it!"
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: 'delete_row.php',
                                type: 'POST',
                                data: {
                                    type: "role",
                                    id: role_id
                                },
                                dataType: "json",
                                success: function(response) {
                                    if (response.success) {
                                        $('#role').val('');
                                        $('#role_permission').val('');
                                        $('#id').val('');
                                        $("#tbl_role").DataTable().ajax.reload();
                                        Swal.fire({
                                            title: "Deleted!",
                                            text: response.message,
                                            icon: "success"
                                        });
                                    } else {
                                        Swal.fire({
                                            title: "Error!",
                                            text: response.message,
                                            icon: "warning"
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    alert("Error occurred while deleting row");
                                    console.error(xhr, status, error);
                                }
                            });
                        }
                    });
                } else {
                    Swal.fire({
                        title: "Error!",
                        text: "Role Id is required",
                        icon: "warning",
                    });
                }
            });

            $("#RoleForm").validate({
                rules: {
                    role: {
                        noSpecialChars: true,
                        maxlength: 50          // Max length rule
                    },
                    'permission[]': {
                        required: true,
                        minlength: 1  // Ensure at least one checkbox is selected
                    }
                },
                messages: {
                    'permission[]': {
                        required: "Please select at least one permission."
                    }
                },
                errorPlacement: function(error, element) {
                    if (element.attr("name") == "permission[]") {
                        error.insertAfter(element.closest('.mb-3')); // Position the error after the group of checkboxes
                    } else {
                        error.insertAfter(element);
                    }
                }
            });

            // Custom validation method to check for special characters
            $.validator.addMethod("noSpecialChars", function(value, element) {
                return this.optional(element) || /^[a-zA-Z0-9\s]+$/.test(value);
            }, "Please enter only letters, numbers, and spaces.");

            // Select all permission checkboxes
            $(document).on("change", "#selectAllPer", function() {
                $('.perm-class').prop('checked', this.checked);
            });

            // Uncheck "Select All" if any individual checkbox is unchecked
            $('.perm-class').on('change', function() {
                if (!this.checked) {
                    $('#selectAllPer').prop('checked', false);
                }
                
                // Check if all checkboxes are checked, if so, check "Select All"
                if ($('.perm-class:checked').length === $('.perm-class').length) {
                    $('#selectAllPer').prop('checked', true);
                }
            });
        });
    </script>

    <?php include "footer.php" ?>
</body>
</html>