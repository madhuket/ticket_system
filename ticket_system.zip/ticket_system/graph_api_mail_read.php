<?php
include 'connection.php';
function performCurlRequest($url, $headers = [], $postFields = null)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    if ($postFields !== null) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    }

    if (!empty($headers)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        die("cURL Error: " . $error);
    }

    $responseObj = json_decode($response, true);
    return $responseObj;
}

function getAccessToken($tenantId, $clientId, $clientSecret)
{
    $url = "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token";

    $headers = [
        'Content-Type: application/x-www-form-urlencoded'
    ];

    $body = http_build_query([
        'grant_type' => 'client_credentials',
        'client_id' => $clientId,
        'client_secret' => $clientSecret,
        'scope' => 'https://graph.microsoft.com/.default'
    ]);

    $responseObj = performCurlRequest($url, $headers, $body);

    if (isset($responseObj['access_token'])) {
        return $responseObj['access_token'];
    } else {
        die("Error: Could not get access token");
    }
}

function getMailFolders($accessToken, $userId)
{
    $url = "https://graph.microsoft.com/v1.0/users/$userId/mailFolders";

    $headers = [
        'Authorization: Bearer ' . $accessToken,
        'Accept: application/json'
    ];

    $folders = performCurlRequest($url, $headers);

    if (isset($folders['value'])) {
        return $folders['value'];
    } else {
        die("Error: Could not fetch mail folders");
    }
}

function readEmailsFromFolder($accessToken, $folderId, $userId)
{
    $url = 'https://graph.microsoft.com/v1.0/users/' . $userId . '/mailFolders/' . $folderId . '/messages?$top=50';

    $headers = [
        'Authorization: Bearer ' . $accessToken,
        'Accept: application/json'
    ];

    $emails = performCurlRequest($url, $headers);

    if (isset($emails['value'])) {
        return $emails['value'];
    } else {
        die("Error: Could not fetch emails");
    }
}

function getAttachments($accessToken, $userId, $folderId, $messageId)
{
    $url = 'https://graph.microsoft.com/v1.0/users/' . $userId . '/mailFolders/' . $folderId . '/messages/' . $messageId . '/attachments';

    $headers = [
        'Authorization: Bearer ' . $accessToken,
        'Accept: application/json'
    ];

    $attachments = performCurlRequest($url, $headers);

    if (isset($attachments['value'])) {
        return $attachments['value'];
    } else {
        die("Error: Could not fetch attachments");
    }
}

function isExcludedFolder($folderName)
{
    $excludedFolders = ['Deleted Items', 'Drafts', 'Junk Email', 'Outbox'];
    return in_array($folderName, $excludedFolders);
}

$tenantId = '';
$clientId = '';
$clientSecret = '';

$accessToken = getAccessToken($tenantId, $clientId, $clientSecret);
$userId = '';

// Get mail folders
$folders = getMailFolders($accessToken, $userId);

$emailDataArr = [];
$db_response = [];
$db_error = [];

// Read emails from each folder
foreach ($folders as $folder) {
    if (isExcludedFolder($folder['displayName'])) {
        continue; // Skip the excluded folders
    }

    $folderId = $folder['id'];
    $emails = readEmailsFromFolder($accessToken, $folderId, $userId);
    
    if (!empty($emails)) {
        $emailAttachments = [];
        foreach ($emails as $email) {
            $messageId = $email['id'] ?? '';
            $subject = $email['subject'] ?? '';
            $from = $email['from']['emailAddress']['address'] ?? '';
            $toRecipients = $email['toRecipients'] ?? '';
            $ccRecipients = $email['ccRecipients'] ?? '';
            $bccRecipients = $email['bccRecipients'] ?? '';
            $replyTo = $email['replyTo'] ?? '';
            $body_content = $email['body']['content'] ?? '';
            $receivedDateTime = $email['receivedDateTime'] ?? '';

            $toEmail = [];
            if (!empty($toRecipients)) {
                foreach ($toRecipients as $to) {
                    $toEmail[] = $to['emailAddress']['address'];
                }
            }
            $ccEmail = [];
            if (!empty($ccRecipients)) {
                foreach ($ccRecipients as $cc) {
                    $ccEmail[] = $cc['emailAddress']['address'];
                }
            }
            $bccEmail = [];
            if (!empty($bccRecipients)) {
                foreach ($bccRecipients as $bcc) {
                    $bccEmail[] = $bcc['emailAddress']['address'];
                }
            }
            $replyToEmail = [];
            if (!empty($replyTo)) {
                foreach ($replyTo as $reply) {
                    $replyToEmail[] = $reply['emailAddress']['address'];
                }
            }

            if ($email['hasAttachments']) {
                $attachments = getAttachments($accessToken, $userId, $folderId, $messageId);
                if (!empty($attachments)) {
                    foreach ($attachments as $attach) {
                        $attachmentName = $attach['name'] ?? '';
                        $attachmentContentByte = $attach['contentBytes'] ?? '';

                        $emailAttachments[] = array(
                            'filename' => $attachmentName,
                            'content' => $attachmentContentByte
                        );
                    }
                }
            }

            //extarct email_identifier from subject
            $lastHyphenPos = strrpos($subject, '-');

            $emailIdentifier = '';
            if ($lastHyphenPos !== false) {
                $result = substr($subject, $lastHyphenPos + 1);
                $emailIdentifier = trim($result); // Remove any leading or trailing spaces
            }

            $emailDataArr[] = array(
                'from' => $from,
                'toRecipients' => $toEmail,
                'ccRecipients' => $ccEmail,
                'bccRecipients' => $bccEmail,
                'replyTo' => $replyToEmail,
                'subject' => $subject,
                'email_identifier' => $emailIdentifier,
                'body' => $body_content,
                'attachments' => $emailAttachments,
                'receivedDateTime' => $receivedDateTime,
            );

            // Save the email data to the database
            $sql_ticket = "INSERT INTO TicketEmail(EmailIdentifier, FromEmail, ToEmail, CcEmail, BccEmail, ReplyToEmail, Subject, Attachments, Body, ReceivedAt, CreatedBy) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            $ticket_params = array($emailIdentifier, $from, serialize($toEmail), serialize($ccEmail), serialize($bccEmail), serialize($replyToEmail), $subject, serialize($emailAttachments), $body_content, $receivedDateTime, 1);

            $stmt_ticket = sqlsrv_prepare($conn, $sql_ticket, $ticket_params);
            if (sqlsrv_execute($stmt_ticket)) {
                $mail_success[] = $subject.' : Mail Insterted';
            } else {
                $db_error[] = true;
                $mail_failed[] = $subject.' : Insert failed';
            }
        }
    }   
}

if(count($db_error) > 0) {
    foreach ($mail_failed as $mail) {
        echo $mail . "<br>";
    }
    // echo json_encode(["success" => false, "message" => "Error saving mail data: " . print_r(sqlsrv_errors(), true)]);    
} else {
    echo json_encode(["success" => true, "message" => "Mail data saved successfully"]);
}