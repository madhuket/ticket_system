<?php
include "config.php";

$ticket_id = base64_decode($_POST['ticket_id']) ?? '';
$fileName = $_POST['fileName'] ?? '';

$response_array = [];

if ($fileName != '') {

    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if (getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if (getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if (getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if (getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if (getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';

    $ticketfile = isset($_POST['Attachments']) ? serialize($_POST['Attachments']) : serialize(array());

    $oldTicketQuery = "SELECT * FROM Tickets WHERE Id = $ticket_id AND IsDeleted = 0 OR IsDeleted IS NULL;";
    $oldTktData = sqlsrv_prepare($conn, $oldTicketQuery);
    $FileArr = [];
    if (sqlsrv_execute($oldTktData)) {
        $row = sqlsrv_fetch_array($oldTktData, SQLSRV_FETCH_ASSOC);
        $oldHistoryData = $row;
        $historyData = [];
        if ($row['Attachments'] != '') {
            $historyData['Attachments'] = $row['Attachments'];
            $historyData['Action'] = "File Deleted";

            $in_history = "INSERT INTO History(TicketId,CreatedBy,UpdatedData,HistoryData,IPAddress) Values (?,?,?,?,?)";

            $history_params = array($ticket_id, $user, serialize($historyData), serialize($oldHistoryData), $ipaddress);

            $sql_history = sqlsrv_prepare($conn, $in_history, $history_params);

            if (!sqlsrv_execute($sql_history)) {
                $response_array['message'] = "Error inserting data into TicketHistory: " . print_r(sqlsrv_errors(), true);
                $response_array['status'] = false;
            }
        }
    }

    $sql_ticket = "UPDATE Tickets SET Attachments = ?, ModifiedBy = ?, ModifiedAt = ? WHERE Id = ?;";
    $ticket_params = array($ticketfile, $user, date("Y-m-d H:i A"), $ticket_id);

    $stmt_ticket = sqlsrv_prepare($conn, $sql_ticket, $ticket_params);
    if (!sqlsrv_execute($stmt_ticket)) {
        $response_array['message'] = "Error while updating data: " . print_r(sqlsrv_errors(), true);
        $response_array['status'] = false; 
    }

    $sql = "SELECT DraftData FROM Draft WHERE TicketId = $ticket_id AND IsDeleted = 0 OR IsDeleted IS NULL;";
    $result = sqlsrv_query($conn, $sql);

    if ($result === false) {
        $response_array['message'] = "Error: " . print_r(sqlsrv_errors(), true);
        $response_array['status'] = false;
    }

    if (sqlsrv_has_rows($result)) {
        $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
        $draft_data = unserialize($row['DraftData']);
        $draft_data['Data']['Attachments'] = $ticketfile;
        $serialisDraftData = serialize($draft_data);

        $sql_draft = "UPDATE Draft SET DraftData = ?, ModifiedAt = ?, ModifiedBy = ? WHERE TicketId = ?;";
        $draft_para = sqlsrv_prepare($conn, $sql_draft, array(&$serialisDraftData, date("Y-m-d H:i A"), $user, $ticket_id));

        if (sqlsrv_execute($draft_para)) {
            $response_array['message'] = "File Deleted, Draft Updated";
            $response_array['status'] = true;
        } else {
            $response_array['message'] = "Error: " . print_r(sqlsrv_errors(), true);
            $response_array['status'] = false;
        }
    } else {
        $response_array['message'] = "File Deleted";
        $response_array['status'] = true;
    }
} else {
    $response_array['message'] = "No File Selected";
    $response_array['status'] = false;
}

header('Content-type:application/json');
echo json_encode($response_array);
