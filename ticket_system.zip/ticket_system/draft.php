<?php
include "config.php";

function validatePhoneNumber($phoneNumber)
{
    // Remove any non-digit characters from the phone number
    $phoneNumber = preg_replace('/[^0-9]/', '', $phoneNumber);

    // Check if the length of the phone number is between 10 and 15
    $phoneNumberLength = strlen($phoneNumber);
    if ($phoneNumberLength >= 10 && $phoneNumberLength <= 15) {
        return true; // Valid phone number
    } else {
        return false; // Invalid phone number
    }
}

function validateEmail($email)
{
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return true;
    } else {
        return false;
    }
}

function validate($value)
{
    if (isset($value) && $value !== "") {
        if (preg_match("/\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|OR)\b/i", $value)) {
            return false;
        } else if (preg_match("/\b(alert|prompt|confirm|script)\b/i", $value)) {
            return false;
        } else {
            return $value;
        }
    } else {
        return false;
    }
}

function validate_title($value) {
    if (isset($value) && $value !== "") {
        if (preg_match("/\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|OR)\b/i", $value)) {
            return false;
        } else if (preg_match("/\b(alert|prompt|confirm|script)\b/i", $value)) {
            return false;
        } else if (!preg_match('/^[a-zA-Z0-9\s]+$/', $value)) {
            return false;
        }  else if (strlen($value) > 100) {
            return false;
        } else {
            return $value;
        }
    } else {
        return false;
    }
}

//check value only contain   letters and spaces
function ValidateString($value)
{
    if (!preg_match('/^[a-zA-Z\s]+$/', $value)) {
        return false;
    } else {
        return $value;
    }
}

//validate follow up at field
function validate_follow_up_at($value)
{
    if ($value != '') {
        $is_valid_phone = true;
        // Remove any non-digit characters from the phone number
        $mobile = preg_replace('/[^0-9]/', '', $value);

        // Check if the length of the phone number is between 10 and 15
        $phoneNumberLength = strlen($mobile);
        if ($phoneNumberLength >= 10 && $phoneNumberLength <= 15) {
            $is_valid_phone = true; // Valid phone number
        } else {
            $is_valid_phone = false; // Invalid phone number
        }

        $is_valid_email = true;
        if (filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $is_valid_email = true;
        } else {
            $is_valid_email = false;
        }

        if ($is_valid_email || $is_valid_phone) {
            return $value;
        } else {
            return false;
        }
    } else {
        return $value;
    }
}

//validate Reported By field
function validate_reported_by($value){
    //allow only alphabets and spaces
    if ($value != '') {
        if (!preg_match('/^[a-zA-Z\s]+$/', $value)) {
            return false;
        } else if (strlen($value) > 100) {
            return false;
        } else {
            return $value;
        }
    } else {
        return $value;
    }
}

function validate_textarea($value) {
    if (strlen($value) > 255) {
        return false;
    } else {
        return $value;
    }
}


if (!$conn) {
    die("Connection failed: " . print_r(sqlsrv_errors(), true));
} else {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if (getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if (getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if (getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if (getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if (getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';

    $ticket_id = isset($_POST['Id']) ? base64_decode($_POST['Id']) : '';
    $source = base64_decode($_POST['TenantId']);
    $ticket_title = validate_title(htmlspecialchars($_POST['TicketTitle']));
    $select_status = validate(htmlspecialchars(base64_decode($_POST['SelectStatus'])));
    $department = validate(htmlspecialchars($_POST['Department']));
    $parent = validate(htmlspecialchars($_POST['Parent']));
    $child = htmlspecialchars($_POST['Child']);
    $sub_child_1 = htmlspecialchars($_POST['Sub_Child_1']);
    $sub_child_2 = htmlspecialchars($_POST['Sub_Child_2']);
    $sub_child_3 = htmlspecialchars($_POST['Sub_Child_3']);
    $sub_child_4 = htmlspecialchars($_POST['Sub_Child_4']);
    // $source = validate(htmlspecialchars(base64_decode($_POST['Source'])));
    $reported_by = validate_reported_by(htmlspecialchars($_POST['ReportedBy']));
    $follow_up_at = validate_follow_up_at(htmlspecialchars($_POST['FollowUpAt']));
    $next_follow_up_date = htmlspecialchars($_POST['NextFollowUpDate']);
    $case_details = validate_textarea(htmlspecialchars($_POST['CaseDetails']));
    $immediate_action_taken = validate_textarea(htmlspecialchars($_POST['ImmediateActionTaken']));
    $priority = validate(htmlspecialchars(base64_decode($_POST['Priority'])));

    $attachments = $_POST['Attachments'];
    $curr_date = date('Y-m-d H:i A');

    $category_where = '';
    $params = [];

    if ($department != '') {
        $category_where .= " Department = ?";
        $params[] = $department;
    }
    if ($parent != '') {
        $category_where .= " AND Parent = ?";
        $params[] = $parent;
    }
    if ($child != '') {
        $category_where .= " AND Child = ?";
        $params[] = $child;
    }
    if ($sub_child_1 != '') {
        $category_where .= " AND Sub_Child_1 = ?";
        $params[] = $sub_child_1;
    }
    if ($sub_child_2 != '') {
        $category_where .= " AND Sub_Child_2 = ?";
        $params[] = $sub_child_2;
    }
    if ($sub_child_3 != '') {
        $category_where .= " AND Sub_Child_3 = ?";
        $params[] = $sub_child_3;
    }
    if ($sub_child_4 != '') {
        $category_where .= " AND Sub_Child_4 = ?";
        $params[] = $sub_child_4;
    }

    // fetch category id
    $category_id = false;
    if ($category_where != '') {
        $cate_sql = "SELECT ID FROM Ticketing_Categories WHERE" . $category_where;
        $stmt = sqlsrv_prepare($conn, $cate_sql, $params);

        $result = sqlsrv_execute($stmt);

        // Fetch the result
        if ($result && sqlsrv_has_rows($stmt)) {
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            $category_id = $row['ID'];
        }
    }

    $sql = "SELECT DraftData FROM Draft WHERE TicketId = ? AND IsDeleted = 0 OR IsDeleted IS NULL;";
    $result = sqlsrv_query($conn, $sql, array(&$ticket_id));

    if ($result === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $data = array();
    $date_time = '';
    
    $TitleDraft = $SelectStatusDraft = $CategoryDraft = $SourceDraft = $ReportedByDraft = $FollowUpAtDraft = $NextFollowUpDateDraft = $CaseDetailsDraft = $ImmediateActionTakenDraft = $PriorityDraft = '';
    if (sqlsrv_has_rows($result)) {
        $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
        $row = stdToArray($row);
        $DraftDataArr = unserialize($row['DraftData']);
        $DraftData = $DraftDataArr['Data'];
        $FollowUpATDraft = $DraftData['FollowUpAt'];
        $TitleDraft = $DraftData['Title'];
        $SelectStatusDraft = $DraftData['SelectStatus'];
        $CategoryDraft = $DraftData['Category'];
        // $SourceDraft = $DraftData['Source'];
        $ReportedByDraft = $DraftData['ReportedBy'];
        $FollowUpAtDraft = $DraftData['FollowUpAt'];
        $NextFollowUpDateDraft = $DraftData['NextFollowUpDate'];
        $CaseDetailsDraft = $DraftData['CaseDetails'];
        $ImmediateActionTakenDraft = $DraftData['ImmediateActionTaken'];
        $PriorityDraft = $DraftData['Priority'];

        if($follow_up_at == false){
            $follow_up_at = $FollowUpATDraft;
        }
        if($ticket_title == false){
            $ticket_title = $TitleDraft;
        }
        if($select_status == false){
            $select_status = $SelectStatusDraft;
        }
        if($priority == false){
            $priority = $PriorityDraft;
        }
        if($reported_by == false){
            $reported_by = $ReportedByDraft;
        }
        if($department == false || $parent == false){
            $category_id = $CategoryDraft;
        }
        if($case_details == false){
            $case_details = $CaseDetailsDraft;
        }
        if($immediate_action_taken == false){
            $immediate_action_taken = $ImmediateActionTakenDraft;
        }
    }

    //Check ticket title already exists
    $is_exist_query = "SELECT Id FROM Tickets WHERE Title = ? And Source = ? AND Id <> ? AND (IsDeleted = 0 OR IsDeleted IS NULL)";
    $params = array($ticket_title, $source, $ticket_id);

    $result = sqlsrv_query($conn, $is_exist_query, $params);

    if (sqlsrv_has_rows($result)) {
        $ticket_title = $TitleDraft;   
    }

    $is_update_draft = false;
    if($TitleDraft != $ticket_title ||
        $SelectStatusDraft != $select_status || 
        $CategoryDraft != $category_id ||
        // $SourceDraft != $source ||
        $ReportedByDraft != $reported_by || 
        $FollowUpAtDraft != $follow_up_at || 
        $NextFollowUpDateDraft != $next_follow_up_date || 
        $CaseDetailsDraft != $case_details || 
        $ImmediateActionTakenDraft != $immediate_action_taken || 
        $PriorityDraft != $priority
    ){
        $is_update_draft = true;
    }

    $response_arr = [];
    // if ($ticket_title && $select_status && $priority && $category_id && $source && $is_update_draft) {
    if ($ticket_title && $select_status && $priority && $category_id && $is_update_draft) {
        $dataArray = array(
            'Title' => $ticket_title,
            'SelectStatus' => $select_status,
            'Category' => $category_id,
            'Source' => $source,
            'ReportedBy' => $reported_by,
            'FollowUpAt' => $follow_up_at,
            'NextFollowUpDate' => $next_follow_up_date,
            'CaseDetails' => $case_details,
            'ImmediateActionTaken' => $immediate_action_taken,
            'Priority' => $priority,
            'UserId' => $user,
            'Attachments' => $attachments,
            'IpAddress' => $ipaddress
        );

        $response = array(
            'Data' => $dataArray
        );

        $exe_update = false;
        $serialisedResponse = serialize($response);
        $sql = "SELECT TicketId FROM Draft WHERE TicketId = ? AND IsDeleted = 0 OR IsDeleted IS NULL;";

        $result = sqlsrv_query($conn, $sql, array($ticket_id));

        if ($result === false) {
            $response_arr = array('success' => false, 'message' => "Error: " . print_r(sqlsrv_errors(), true));
        }

        if (sqlsrv_has_rows($result)) {
            $exe_update = true;
            while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
                if ($ticket_id == $row['TicketId']) {
                    $sql_in = "UPDATE Draft SET DraftData = ?, ModifiedAt = ?, ModifiedBy = ? WHERE TicketId = ?;";
                    $draft_para = sqlsrv_prepare($conn, $sql_in, array(&$serialisedResponse, $curr_date, $user, $ticket_id));

                    if (sqlsrv_execute($draft_para)) {
                        //get last draft
                        $sql = "SELECT ModifiedAt FROM Draft WHERE TicketId = ?;";
                        $result = sqlsrv_query($conn, $sql, array(&$ticket_id));

                        if ($result === false) {
                            die(print_r(sqlsrv_errors(), true));
                        }

                        $date_time = '';
                        if (sqlsrv_has_rows($result)) {
                            $draft_row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
                            $draft_row = stdToArray($draft_row);

                            $date = date_create($draft_row['ModifiedAt']['date']);
                            $date_time = date_format($date, "m/d/Y H:i A");
                        }
                        $response_arr = array('success' => true, 'message' => "Draft Successfully Updated", 'ModifiedAt' => $date_time);
                    } else {
                        $response_arr = array('success' => false, 'message' => "Error: " . print_r(sqlsrv_errors(), true));
                    }
                }
            }
        } else if (!$exe_update) {
            $in_draft = "INSERT INTO Draft(TicketId, CreatedBy, DraftData) values (?,?,?);";
            $sql_draft = sqlsrv_prepare($conn, $in_draft, array(&$ticket_id, $user,  $serialisedResponse));

            if (sqlsrv_execute($sql_draft)) {
                //get last draft
                $sql = "SELECT CreatedAt FROM Draft WHERE TicketId = ?;";
                $result = sqlsrv_query($conn, $sql, array(&$ticket_id));

                if ($result === false) {
                    die(print_r(sqlsrv_errors(), true));
                }

                $date_time = '';
                if (sqlsrv_has_rows($result)) {
                    $draft_row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
                    $draft_row = stdToArray($draft_row);


                    $date = date_create($draft_row['CreatedAt']['date']);
                    $date_time = date_format($date, "m/d/Y H:i A");
                }

                $response_arr = array('success' => true, 'message' => "Draft Successfully Inserted", 'ModifiedAt' => $date_time);
            } else {
                $response_arr = array('success' => false, 'message' => "Error: " . print_r(sqlsrv_errors(), true));
            }
        }
    }

    header('Content-Type: application/json');
    echo json_encode($response_arr);
}
