<body>

  <!-- Begin page -->
  <div id="wrapper">
    <!-- ========== Menu ========== -->
    <div class="app-menu">

      <!-- Brand Logo -->
      <div class="logo-box">
        <!-- Brand Logo Light -->
        <!-- <a href="<?php echo $base_url; ?>" class="logo-light">
          <img src="assets/images/EPI_HORIZ_LOGO_WEB.gif" alt="logo" class="logo-lg">
          <img src="assets/images/logo-small.png" alt="small logo" class="logo-sm">
        </a> -->

        <!-- Brand Logo Dark -->
        <a href="<?php echo $base_url; ?>" class="logo-dark">
          <img src="assets/images/EPI_HORIZ_LOGO_WEB.gif" alt="dark logo" class="logo-lg">
          <img src="assets/images/logo-small.png" alt="small logo" class="logo-sm">
        </a>
      </div>

      <!-- menu-left -->
      <div class="scrollbar">
        <!--- Menu -->
        <ul class="menu">

          <li class="menu-item">
            <a href="index.php" class="menu-link">
              <span class="menu-icon"><i class="mdi mdi-view-dashboard"></i></span>
              <span class="menu-text"> Dashboard </span>
            </a>
          </li>

          <?php
          if ((isset($_SESSION['user_permissions']) && $_SESSION['user_permissions'] !== '') && in_array('MANAGE_TICKET', $_SESSION['user_permissions'])) {
          ?>
            <li class="menu-item">
              <a href="create_ticket.php" class="menu-link">
                <span class="menu-icon"><i class="mdi mdi-ticket"></i></span>
                <span class="menu-text"> Create Ticket </span>
              </a>
            </li>

            <li class="menu-item">
              <a href="view_ticket.php" class="menu-link">
                <span class="menu-icon"><i class="mdi mdi-view-list"></i></span>
                <span class="menu-text"> View Ticket </span>
              </a>
            </li>
          <?php
          } else if (isset($_SESSION['tenant_name']) && $_SESSION['tenant_name'] !== '') {
          ?>
            <li class="menu-item">
              <a href="create_ticket.php" class="menu-link">
                <span class="menu-icon"><i class="mdi mdi-ticket"></i></span>
                <span class="menu-text"> Create Ticket </span>
              </a>
            </li>

            <li class="menu-item">
              <a href="view_ticket.php" class="menu-link">
                <span class="menu-icon"><i class="mdi mdi-view-list"></i></span>
                <span class="menu-text"> View Ticket </span>
              </a>
            </li>
          <?php
          }
          ?>

          <?php
          if (isset($_SESSION['user_login']) && $_SESSION['user_login'] === true) {
          ?>
            <li class="menu-item">
              <a href="#menuBaseui" data-bs-toggle="collapse" class="menu-link">
                <span class="menu-icon"><i data-feather="pocket"></i></span>
                <span class="menu-text">Master</span>
                <span class="menu-arrow"></span>
              </a>
              <div class="collapse collapse-md" id="menuBaseui">
                <ul class="sub-menu">

                  <?php
                  if (in_array('MANAGE_STATUS', $_SESSION['user_permissions'])) {
                  ?>
                    <li class="menu-item">
                      <a href="ticket_status.php" class="menu-link">
                        <span class="menu-text">Ticket Status</span>
                      </a>
                    </li>
                  <?php
                  }

                  if (in_array('MANAGE_PRIORITY', $_SESSION['user_permissions'])) {
                  ?>
                    <li class="menu-item">
                      <a href="ticket_priority.php" class="menu-link">
                        <span class="menu-text">Ticket Priority</span>
                      </a>
                    </li>
                  <?php
                  }

                  if (in_array('MANAGE_SOURCE', $_SESSION['user_permissions'])) {
                  ?>
                    <li class="menu-item">
                      <a href="ticket_source.php" class="menu-link">
                        <span class="menu-text">Ticket Source</span>
                      </a>
                    </li>
                  <?php
                  }

                  if (in_array('MANAGE_LICENSE', $_SESSION['user_permissions'])) {
                  ?>
                    <li class="menu-item">
                      <a href="ticket_license.php" class="menu-link">
                        <span class="menu-text">Ticket License</span>
                      </a>
                    </li>
                  <?php
                  }

                  if (in_array('MANAGE_PERMISSION', $_SESSION['user_permissions']) && (isset($_SESSION['is_superadmin']) && $_SESSION['is_superadmin'] == true)) {
                  ?>
                    <li class="menu-item">
                      <a href="permission.php" class="menu-link">
                        <span class="menu-text">Permission</span>
                      </a>
                    </li>
                  <?php
                  }

                  if (in_array('MANAGE_ROLE', $_SESSION['user_permissions']) && (isset($_SESSION['is_superadmin']) && $_SESSION['is_superadmin'] == true)) {
                  ?>
                    <li class="menu-item">
                      <a href="role.php" class="menu-link">
                        <span class="menu-text">Role</span>
                      </a>
                    </li>
                  <?php
                  }

                  if (in_array('MANAGE_USER', $_SESSION['user_permissions']) && (isset($_SESSION['is_superadmin']) && $_SESSION['is_superadmin'] == true)) {
                  ?>
                    <li class="menu-item">
                      <a href="user.php" class="menu-link">
                        <span class="menu-text">User</span>
                      </a>
                    </li>
                  <?php
                  }
                  ?>

                </ul>
              </div>
            </li>
          <?php
          }

          if (isset($_SESSION['user_login']) && $_SESSION['user_login'] === true) {
          ?>
            <li class="menu-item logout_li">
              <a href="admin_logout.php" class="menu-link logout_btn" style="color: #fff;">
                <span class="menu-icon"><i class="mdi mdi-logout"></i></span>
                <span class="menu-text"> Logout </span>
              </a>
            </li>
          <?php
          }
          ?>
        </ul>
        <!--- End Menu -->
        <div class="clearfix"></div>
      </div>
    </div>
    <!-- ========== Left menu End ========== -->

    <!-- ============================================================== -->
    <!-- Start Page Content here -->
    <!-- ============================================================== -->

    <div class="content-page">

      <!-- ========== Topbar Start ========== -->
      <div class="navbar-custom">
        <div class="topbar">
          <div class="topbar-menu d-flex align-items-center gap-1">

            <!-- Sidebar Menu Toggle Button -->
            <button class="button-toggle-menu">
              <i class="mdi mdi-menu"></i>
            </button>
          </div>


        </div>
      </div>
      <!-- ========== Topbar End ========== -->