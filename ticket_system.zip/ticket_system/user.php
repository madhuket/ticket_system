<?php
include "header.php";

if(!(isset($_SESSION['is_superadmin']) && $_SESSION['is_superadmin'] == true)){
    header("Location: index.php");
    exit();
}

// $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()';
// $password = $chars[rand(0, 25)] . $chars[rand(26, 51)] . $chars[rand(52, 61)] . $chars[rand(62, strlen($chars) - 1)];

// while (strlen($password) < 8) {
//     $password .= $chars[rand(0, strlen($chars) - 1)];
// }

// $password = str_shuffle($password);
?>

<body>
    <?php include "sider.php"; ?>

    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right me-4">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>">Ticket Management</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/view_ticket.php">Tickets</a></li>
                                <li class="breadcrumb-item active">User</li>
                            </ol>
                        </div>
                        <h4 class="page-title ps-5">User</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" id="UserForm">
                                <input type='hidden' id="type" name="type" value="user">
                                <input type="hidden" id="id" name="id" value="">
                                <input type="hidden" name="csrf_token" id="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="username" class="form-label">Username<span class="req_star"> *</span></label>
                                            <input type="text" id="username" class="form-control" name="username" required>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="email" class="form-label">Email<span class="req_star"> *</span></label>
                                            <input type="text" id="email" class="form-control" name="email" required>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="password" class="form-label">Password<span class="req_star"> *</span></label>
                                            <input type="password" id="password" class="form-control" name="password" required>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="select_role" class="form-label">Select Role<span class="req_star"> *</span></label>
                                            <select class="form-select" id="select_role" name="select_role" required>
                                                <option value="" selected>Select Role</option>
                                                <?php include 'select_role.php'; ?>
                                            </select>
                                        </div>
                                    </div>   

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="select_source" class="form-label">Source<span class="req_star"> *</span></label>
                                            <select class="form-select" id="select_source" name="select_source" required>
                                                <option value="" selected>Select Source</option>
                                                <?php include 'select_source.php'; ?>
                                            </select>
                                        </div>
                                    </div>    

                                    <div class="col-lg-6">
                                        <div class="mb-3 mb-md-0 mt-0 mt-md-4">
                                            <div class="form-check form-switch">
                                                <input type="checkbox" class="form-check-input" id="is_active" name="is_active" value="1" checked>
                                                <label class="form-check-label" for="is_active">Is Active</label>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                                <div class="mb-3">
                                    <div class="text-center d-flex justify-content-center">
                                        <div class="mt-3">
                                            <button type="submit" class="btn btn-primary" id="submit_form">Submit</button>
                                        </div>

                                        <div class="mt-3 ms-2">
                                            <button type="reset" class="btn btn-danger" id="reset_form">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">

                            <div class="table-responsive">
                                <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tbl_user">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Username</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                            <th>Source</th>
                                            <th>IsActive</th>
                                            <th class="hidden-sm">Action</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div><!-- end col -->
            </div>
            <!-- end row -->
        </div> <!-- container -->
    </div>

    <script>
        $(document).ready(function() {
            $("#reset_form").on("click", function () {
                $('#id').val('');

                $("#UserForm").find("label.error").remove();
                $("#UserForm").find(".error").removeClass("error");
            });

            $("#tbl_user").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                },
                ajax: {
                    url: "fetch/fetch_user.php"
                }
            });

            $('#UserForm').submit(function(e) {
                e.preventDefault();

                var isvalidForm = $(this).valid();
                if (isvalidForm) {
                    //disable button
                    $('#submit_form').attr('disabled', true);

                    var formData = $(this).serialize();
                    $.ajax({
                        type: 'POST',
                        url: 'store_data.php',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            if (response.success) {
                                $("#tbl_user").DataTable().ajax.reload();
                                Swal.fire({
                                    title: "Good job!",
                                    text: response.message,
                                    icon: "success"
                                });
                                
                                $('#reset_form').trigger('click');
                                $('#csrf_token').val(response.csrf_token);
                            } else {
                                Swal.fire({
                                    title: "Can't insert data",
                                    text: response.message,
                                    icon: "warning"
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            //remove disable
                            $('#submit_form').attr('disabled', false);
                            console.error("Error saving status:", error);
                        },
                    });
                }
            });

            $(document).on("click", ".edit_user", function() {
                var user_id = $(this).data('userid');

                $.ajax({
                    type: 'POST',
                    url: 'fetch/fetch_user_particular.php',
                    data: {
                        'user_id': user_id
                    },
                    dataType: 'json',
                    success: function(response) {

                        $("#UserForm").find("label.error").remove();
                        $("#UserForm").find(".error").removeClass("error");

                        scrollToTop();
                        $('#username').val(response.Username);
                        $('#password').val(response.Password);
                        $('#email').val(response.Email);
                        $('#select_role').val(response.Role);
                        $('#select_source').val(response.Source);
                        response.IsActive == 1 ? $('#is_active').prop('checked', true): $('#is_active').prop('checked', false);
                        $('#id').val(response.Id);
                        $('#csrf_token').val(response.CsrfToken);
                    }
                });
            });

            $(document).on("click", ".remove_user", function() {
                var user_id = $(this).data('userid');

                if(user_id !== '' && user_id !== null && user_id !== undefined) {
                    Swal.fire({
                        title: "Are you sure?",
                        text: "You won't be able to revert this!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#3085d6",
                        cancelButtonColor: "#d33",
                        confirmButtonText: "Yes, delete it!"
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: 'delete_row.php',
                                type: 'POST',
                                data: {
                                    type: "user",
                                    id: user_id
                                },
                                dataType: "json",
                                success: function(response) {
                                    if (response.success) {
                                        $('#reset_form').trigger('click');
                                        $("#tbl_user").DataTable().ajax.reload();
                                        Swal.fire({
                                            title: "Deleted!",
                                            text: response.message,
                                            icon: "success"
                                        });
                                    } else {
                                        Swal.fire({
                                            title: "Error!",
                                            text: response.message,
                                            icon: "warning"
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    alert("Error occurred while deleting row");
                                    console.error(xhr, status, error);
                                }
                            });
                        }
                    });
                } else {
                    Swal.fire({
                        title: "Error!",
                        text: "User Id is required",
                        icon: "warning",
                    });
                }
            });

            $("#UserForm").validate({
                rules: {
                    email: {
                        required: true,
                        email: true
                    },
                    username: {
                        required: true,
                        minlength: 5,
                        maxlength: 15,
                        alphanumeric: true // Custom rule for alphanumeric characters
                    },
                    password: {
                        required: true,
                        minlength: 8,
                        pwcheck: true // Custom rule for password complexity
                    }
                },
                messages: {
                    username: {
                        required: "Please enter a username",
                        minlength: "Username must be at least 5 characters long",
                        maxlength: "Username cannot exceed 15 characters",
                        alphanumeric: "Username must contain only letters and numbers"
                    },
                    password: {
                        required: "Please enter a password",
                        minlength: "Password must be at least 8 characters long",
                        pwcheck: "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character"
                    }
                }
            });

            // Custom alphanumeric method
            $.validator.addMethod("alphanumeric", function(value, element) {
                return this.optional(element) || /^[a-zA-Z0-9]+$/.test(value);
            }, "Only letters and numbers are allowed.");

            // Custom method for password complexity
            $.validator.addMethod("pwcheck", function(value, element) {
                return this.optional(element) || 
                    /[A-Z]/.test(value) &&    // Must contain an uppercase letter
                    /[a-z]/.test(value) &&    // Must contain a lowercase letter
                    /[0-9]/.test(value) &&    // Must contain a digit
                    /[\W]/.test(value);       // Must contain a special character
            }, "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character.");
        });
    </script>

    <?php include "footer.php" ?>
</body>
</html>