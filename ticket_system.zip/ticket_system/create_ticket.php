<?php
include "header.php";

$tenant_name = $_SESSION['tenant_name'] ?? '';
$tenant_url = $_SESSION['tenant_url'] ?? '';
?>
<style>
    .file-drop-area {
        position: relative;
        display: flex;
        align-items: center;
        /* width: 450px; */
        width: 100%;
        padding: 25px;
        border: 1px dashed rgba(0, 0, 0, 0.4);
        border-radius: 3px;
        transition: 0.2s;
    }

    .choose-file-button {
        flex-shrink: 0;
        background-color: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 3px;
        padding: 8px 15px;
        margin-right: 10px;
        font-size: 12px;
        text-transform: uppercase;
    }

    .file-message {
        font-size: small;
        font-weight: 300;
        line-height: 1.4;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .file-input {
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
        width: 100%;
        cursor: pointer;
        opacity: 0;
    }
</style>

<body>
    <?php include "sider.php" ?>

    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right me-4">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>">Ticket Management</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/view_ticket.php">Tickets</a></li>
                                <li class="breadcrumb-item active">Create Ticket</li>
                            </ol>
                        </div>
                        <h4 class="page-title ps-5">Create Ticket</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12 px-0">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" id="create_ticket_form" enctype="multipart/form-data">
                                <input type='hidden' name="type" value="ticket">
                                <input type="hidden" id="ticket_id" name="ticket_id" value="">
                                <input type="hidden" id="source_url" name="source_url" value="<?php echo $tenant_url; ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                                <div class="row mb-3 border p-2 pb-0 px-0 mt-4 mx-0 mt-lg-0 rounded">
                                    <div class="col-md-6">
                                        <p class="header-title mb-2"><span class="h5">Source:</span> <?php echo $tenant_name; ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="header-title"><span class="h5">Source URL:</span> <?php echo $tenant_url; ?></p>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="ticket_title" class="form-label">Title<span style="color: red;"> *</span></label>
                                            <input type="text" id="ticket_title" class="form-control" name="ticket_title" placeholder="Enter title" required>
                                        </div>

                                        <div class="mb-3">
                                            <label for="reported_by" class="form-label">Reported By</label>
                                            <input type="text" id="reported_by" class="form-control" name="reported_by" placeholder="Enter name of person who reported this">
                                        </div>

                                        <div class="mb-3">
                                            <label for="select_status" class="form-label">Status</label>
                                            <select class="form-select" id="select_status" name="select_status" disabled>
                                                <?php include 'select_status_open.php'; ?>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="priority" class="form-label">Priority<span style="color: red;"> *</span></label>
                                            <select class="form-select" id="priority" name="priority" required>
                                                <option value="" selected>Select Priority</option>
                                                <?php include 'select_priority.php'; ?>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="department" class="form-label">Department<span class="error"> *</span></label>
                                            <select class="form-select" id="department" name="department" required>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="parent" class="form-label">Parent<span class="error"> *</span></label>
                                            <select class="form-select" id="parent" name="parent" required>
                                                <option value="" selected>Select Parent</option>
                                            </select>
                                        </div>

                                        <div class="mb-3 child_div d-none">
                                            <label for="child" class="form-label">Child</label>
                                            <select class="form-select" id="child" name="child">
                                                <option value="" selected>Select Child</option>
                                            </select>
                                        </div>

                                        <div class="mb-3 sub_child_1_div d-none">
                                            <label for="sub_child_1" class="form-label">Sub Child 1</label>
                                            <select class="form-select" id="sub_child_1" name="sub_child_1">
                                                <option value="" selected>Select Sub Child 1</option>
                                            </select>
                                        </div>

                                        <div class="mb-3 sub_child_2_div d-none">
                                            <label for="sub_child_2" class="form-label">Sub Child 2</label>
                                            <select class="form-select" id="sub_child_2" name="sub_child_2">
                                                <option value="" selected>Select Sub Child 2</option>
                                            </select>
                                        </div>

                                        <div class="mb-3 sub_child_3_div d-none">
                                            <label for="sub_child_3" class="form-label">Sub Child 3</label>
                                            <select class="form-select" id="sub_child_3" name="sub_child_3">
                                                <option value="" selected>Select Sub Child 3</option>
                                            </select>
                                        </div>

                                        <div class="mb-3 sub_child_4_div d-none">
                                            <label for="sub_child_4" class="form-label">Sub Child 4</label>
                                            <select class="form-select" id="sub_child_4" name="sub_child_4">
                                                <option value="" selected>Select Sub Child 4</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="select_source" class="form-label">Source<span style="color: red;"> *</span></label>
                                            <select class="form-select" id="select_source" name="select_source" required>
                                                <option value="" selected>Select Source</option>
                                                <?php include 'select_source.php'; ?>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="follow_up_at" class="form-label">Follow Up At</label>
                                            <input class="form-control" id="follow_up_at" type="text" name="follow_up_at" placeholder="Enter email address or mobile number on which follow up is to be done">
                                        </div>

                                        <div class="mb-3">
                                            <label for="next_follow_up_date" class="form-label">Next Follow Up Date</label>
                                            <input type="text" id="next_follow_up_date" class="form-control" name="next_follow_up_date" data-provide="datepicker" placeholder="Select next follow up date">
                                        </div>
                                        <div class="mb-3">
                                            <label for="case_details" class="form-label">Case Details</label>
                                            <textarea class="form-control" id="case_details" name="case_details" rows="5" placeholder="Enter case details"></textarea>
                                        </div>

                                        <div class="mb-3">
                                            <label for="immediate_action_taken" class="form-label">Immediate Action Taken</label>
                                            <textarea class="form-control" id="immediate_action_taken" name="immediate_action_taken" rows="5" placeholder="Enter immediate action taken"></textarea>
                                        </div>

                                        <div class="mb-3">
                                            <label class="col-sm-2 form-label">Upload File</label>
                                            <div class="file-drop-area">
                                                <span class="choose-file-button">Choose files</span>
                                                <span class="file-message">or drag and drop files here</span>
                                                <input class="file-input" name="attachments[]" type="file" multiple>
                                            </div>
                                            <label id="attachments-error" class="text-danger d-none"></label>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="mb-3">
                                        <div class="text-center d-flex justify-content-center">
                                            <div class="mt-3">
                                                <button type="submit" class="btn btn-primary" id="submit_form">Submit</button>
                                            </div>
                                            <div class="mt-3 ms-2">
                                                <button type="reset" class="btn btn-danger" id="reset_form">Reset</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- end row-->
                            </form>
                        </div>
                    </div> <!-- end card-->
                </div> <!-- end col -->
            </div>
        </div>

        <?php include "footer.php" ?>
        <script src="assets/js/pages/add_ticket.js"></script>
</body>
</html>